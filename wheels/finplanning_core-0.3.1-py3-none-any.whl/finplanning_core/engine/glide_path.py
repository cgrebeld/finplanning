from finplanning_core.models.accounts import Account, AccountType, AssetClass
from finplanning_core.models.assumptions import GlidePath


def _target_equity_for_age(target_age: int, glide_path: GlidePath) -> float:
    points = sorted(glide_path.equity_by_age.items())
    if not points:
        return 0.0

    first_age, first_target = points[0]
    if target_age <= first_age:
        return first_target

    last_age, last_target = points[-1]
    if target_age >= last_age:
        return last_target

    for (left_age, left_target), (right_age, right_target) in zip(points, points[1:], strict=False):
        if left_age <= target_age <= right_age:
            age_span = float(right_age - left_age)
            offset = float(target_age - left_age)
            blend = offset / age_span
            return left_target + (right_target - left_target) * blend

    return last_target


def apply_glide_path(
    accounts: list[Account],
    target_age: int,
    glide_path: GlidePath,
    capital_gains_inclusion_rate: float = 0.5,
) -> tuple[float, float]:
    """Rebalance account mixes and return realized/taxable gains from non-registered rebalancing."""
    target_equity = _target_equity_for_age(target_age, glide_path)
    tolerance = glide_path.rebalance_tolerance_pct
    total_realized_capital_gains: float = 0.0
    total_taxable_capital_gains: float = 0.0

    for account in accounts:
        prior_mix = dict(account.asset_mix)
        current_equity = account.asset_mix.get(AssetClass.EQUITY, 0.0)
        if abs(current_equity - target_equity) < tolerance:
            continue

        non_equity_total = 1.0 - current_equity
        new_mix = dict(account.asset_mix)

        if target_equity > current_equity:
            shift = target_equity - current_equity
            if non_equity_total <= 0:
                continue
            for asset_class, weight in account.asset_mix.items():
                if asset_class is AssetClass.EQUITY:
                    continue
                reduction = shift * (weight / non_equity_total)
                new_mix[asset_class] = weight - reduction
            new_mix[AssetClass.EQUITY] = target_equity
        else:
            shift = current_equity - target_equity
            for asset_class, weight in account.asset_mix.items():
                if asset_class is AssetClass.EQUITY:
                    continue
                if non_equity_total > 0:
                    increase = shift * (weight / non_equity_total)
                    new_mix[asset_class] = weight + increase
            if non_equity_total <= 0:
                new_mix[AssetClass.FIXED_INCOME] = shift
            new_mix[AssetClass.EQUITY] = target_equity

        if account.account_type is AccountType.NON_REGISTERED and account.balance > 0:
            sell_fraction = sum(
                max(weight - new_mix.get(asset_class, 0.0), 0.0) for asset_class, weight in prior_mix.items()
            )
            if sell_fraction > 0:
                sell_amount = account.balance * sell_fraction
                acb_ratio = account.cost_basis / account.balance if account.balance > 0 else 0.0
                acb_reduction = sell_amount * acb_ratio
                realized_capital_gains = sell_amount - acb_reduction
                taxable_capital_gains = realized_capital_gains * capital_gains_inclusion_rate

                # Rebalancing sells are reinvested within the same account.
                account.cost_basis = account.cost_basis - acb_reduction + sell_amount
                total_realized_capital_gains += realized_capital_gains
                total_taxable_capital_gains += taxable_capital_gains

        account.asset_mix = new_mix

    return total_realized_capital_gains, total_taxable_capital_gains
