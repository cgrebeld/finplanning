from finplanning_core.engine.projection import Withdrawal
from finplanning_core.models.accounts import Account, AccountType
from finplanning_core.tax.loader import RrifParameters


def rrif_minimum_factor(age: int, prescribed_factors: dict[int, float]) -> float:
    """Return the RRIF minimum withdrawal factor for a given age.

    - Age <= 70: 1 / (90 - age)
    - Age 71-94: CRA prescribed factor from table
    - Age >= 95: 20%
    """
    if age >= 95:
        return 0.20
    if age >= 71:
        factor = prescribed_factors.get(age)
        if factor is None:
            raise ValueError(f"Missing RRIF prescribed factor for age {age}")
        return factor
    if age >= 1:
        return 1.0 / (90 - age)
    raise ValueError(f"Invalid age for RRIF minimum factor: {age}")


def convert_rrsp_to_rrif(account: Account, conversion_age: int, owner_age: int) -> bool:
    """Convert an RRSP account to RRIF if the owner has passed the conversion age.

    Conversion happens by Dec 31 of the year the holder turns conversion_age (71).
    So the RRIF exists starting the *following* year (owner_age > conversion_age).
    Returns True if conversion occurred.
    """
    if account.account_type is AccountType.RRSP and owner_age > conversion_age:
        account.account_type = AccountType.RRIF
        return True
    return False


def apply_rrif_minimums(
    accounts: list[Account],
    person_age_by_owner: dict[str, int],
    rrif_params: RrifParameters,
) -> list[Withdrawal]:
    """Withdraw the CRA-mandated minimum from each RRIF account.

    Uses the Jan 1 balance (balance at start of year, before returns).
    Returns Withdrawal objects for each RRIF that has a positive balance.
    """
    withdrawals: list[Withdrawal] = []
    for account in accounts:
        if account.account_type is not AccountType.RRIF:
            continue
        owner_age = person_age_by_owner.get(account.owner_id)
        if owner_age is None:
            continue
        if account.balance <= 0:
            continue
        factor = rrif_minimum_factor(owner_age, rrif_params.prescribed_factors)
        minimum = account.balance * factor
        withdrawn = min(minimum, account.balance)
        account.balance -= withdrawn
        withdrawals.append(
            Withdrawal(
                account_id=account.id,
                account_type=AccountType.RRIF,
                amount_withdrawn=withdrawn,
            )
        )
    return withdrawals
