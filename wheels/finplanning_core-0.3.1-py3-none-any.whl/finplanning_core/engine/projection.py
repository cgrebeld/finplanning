from datetime import UTC, datetime

from pydantic import BaseModel, Field

from finplanning_core.models.accounts import AccountType


class Withdrawal(BaseModel):
    account_id: str
    account_type: AccountType
    amount_withdrawn: float
    realized_capital_gains: float = 0.0
    taxable_capital_gains: float = 0.0


class YearlyProjection(BaseModel):
    """Single year of projection output."""

    year: int
    person1_age: int
    person2_age: int | None
    employment_income: float = 0.0
    pension_income: float = 0.0
    cpp_income: float = 0.0
    oas_income: float = 0.0
    oas_clawback: float = 0.0
    investment_income: float = 0.0
    portfolio_dividend_income: float = 0.0
    portfolio_interest_income: float = 0.0
    portfolio_unrealized_growth: float = 0.0
    rebalancing_realized_capital_gains: float = 0.0
    rebalancing_taxable_capital_gains: float = 0.0
    rebalancing_realized_capital_losses: float = 0.0
    rebalancing_taxable_capital_losses: float = 0.0
    realized_capital_gains: float = 0.0
    realized_capital_losses: float = 0.0
    taxable_capital_gains: float = 0.0
    taxable_capital_losses: float = 0.0
    taxable_capital_loss_carryforward: float = 0.0
    other_income: float = 0.0
    total_income: float = 0.0
    federal_tax: float = 0.0
    provincial_tax: float = 0.0
    total_tax: float = 0.0
    marginal_tax_rate: float = 0.0
    average_tax_rate: float = 0.0
    net_income: float = 0.0
    total_expenses: float = 0.0
    cash_flow_gap: float = 0.0
    withdrawal_non_reg: float = 0.0
    withdrawal_rrsp_rrif: float = 0.0
    withdrawal_tfsa: float = 0.0
    total_withdrawals: float = 0.0
    total_non_reg: float = 0.0
    total_rrsp_rrif: float = 0.0
    total_tfsa: float = 0.0
    total_net_worth: float = 0.0
    account_balances: dict[str, float] = Field(default_factory=dict)
    account_returns: dict[str, float] = Field(default_factory=dict)
    account_net_deposits: dict[str, float] = Field(default_factory=dict)
    one_time_income: float = 0.0
    one_time_expense: float = 0.0
    recurring_expense: float = 0.0


class ProjectionResult(BaseModel):
    """Complete projection output."""

    scenario_id: str
    calculation_timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    years: list[YearlyProjection]
    final_net_worth: float
    depletion_age: int | None
    sustainable_spending: float = 0.0
    desired_spending: float = 0.0
    spending_gap: float = 0.0
    warnings: list[str] = Field(default_factory=list)
