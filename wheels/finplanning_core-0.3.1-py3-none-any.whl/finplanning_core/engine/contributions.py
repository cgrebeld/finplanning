from finplanning_core.models.accounts import Account, AccountType


def accrue_contribution_room(
    accounts: list[Account],
    year: int,
    prior_year_earned_income: float,
    tfsa_limit: float,
    rrsp_dollar_limit: float,
    max_pensionable_earnings: float,
    rrsp_contribution_room_by_owner: dict[str, float],
) -> None:
    rrsp_accrual = min(prior_year_earned_income * 0.18, rrsp_dollar_limit)

    for owner_id in rrsp_contribution_room_by_owner:
        rrsp_contribution_room_by_owner[owner_id] = rrsp_contribution_room_by_owner[owner_id] + rrsp_accrual

    for account in accounts:
        if account.account_type is AccountType.TFSA:
            current = account.contribution_room or 0.0
            account.contribution_room = current + tfsa_limit
