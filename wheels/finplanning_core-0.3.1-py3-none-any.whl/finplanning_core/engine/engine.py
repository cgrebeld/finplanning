from __future__ import annotations

import math
from typing import TYPE_CHECKING

from finplanning_core.engine.contributions import accrue_contribution_room
from finplanning_core.engine.glide_path import apply_glide_path
from finplanning_core.engine.inflation import inflate, inflate_by_category
from finplanning_core.engine.projection import ProjectionResult, Withdrawal, YearlyProjection
from finplanning_core.engine.rrif import apply_rrif_minimums, convert_rrsp_to_rrif
from finplanning_core.engine.withdrawals import apply_waterfall
from finplanning_core.models.accounts import Account, AccountType, AssetClass
from finplanning_core.models.assumptions import BlackSwanAssumptions, InvestmentIncomeAssumptions, ReturnAssumptions
from finplanning_core.models.expenses import Expense
from finplanning_core.models.income import IncomeType
from finplanning_core.models.plan import HouseholdPlan
from finplanning_core.tax.benefits import calculate_cpp_benefit, calculate_oas_benefit
from finplanning_core.tax.calculator import TaxCalculator, TaxResult
from finplanning_core.tax.loader import TaxTables, load_tax_tables

if TYPE_CHECKING:
    from finplanning_core.models.income import IncomeSource


def _pension_nominal_amount(source: IncomeSource, year: int, inflation_rate: float) -> float:
    """Return nominal PENSION amount using income-start-relative inflation."""
    if not source.indexed:
        return source.annual_amount
    assert source.start_date is not None, (
        "start_date must be set before calling _pension_nominal_amount; "
        "callers must filter `if source.start_date is None: continue`"
    )
    years_since_start = max(0, year - source.start_date.year)
    return inflate(source.annual_amount, inflation_rate, years_since_start)


class CashFlowEngine:
    """Phase 1 cash-flow projection engine (without tax calculations)."""

    def __init__(self, plan: HouseholdPlan) -> None:
        self.plan = plan

    def run_projection(
        self,
        scenario_id: str,
        start_year: int,
        end_year: int,
        return_overrides: dict[int, ReturnAssumptions] | None = None,
        expense_delta: float | None = None,
        include_spending_analysis: bool = True,
        tax_tables_by_year: dict[int, TaxTables] | None = None,
    ) -> ProjectionResult:
        """Run a year-by-year cash-flow projection.

        Args:
            expense_delta: When set, adds a constant real adjustment
                (in year-1 dollars, inflated by general inflation) to
                the plan's regular expenses each year.  Positive values
                increase spending; negative values decrease it.  Used by
                the gap-analysis binary search.
        """
        accounts = [account.model_copy(deep=True) for account in self.plan.accounts]
        warnings: list[str] = []
        yearly_rows: list[YearlyProjection] = []
        prior_year_earned_income = 0.0
        taxable_capital_loss_carryforward = 0.0
        rrsp_contribution_room_by_owner = dict(
            self.plan.assumptions.contribution_limits.rrsp_contribution_room_by_owner
        )
        tax_projection = self.plan.assumptions.tax_projection.model_dump(mode="python")
        tax_calculator = TaxCalculator(projection_assumptions=tax_projection)
        province = self.plan.household.province.value
        resolved_tax_tables_by_year = tax_tables_by_year or {
            year: load_tax_tables(year, province, projection_assumptions=tax_projection)
            for year in range(start_year, end_year + 1)
        }
        start_age = start_year - self.plan.household.person1.birth_date.year
        expenditure_target = self._get_expenditure_target_for_spending_curve(start_year)

        for year in range(start_year, end_year + 1):
            tax_tables = resolved_tax_tables_by_year[year]
            accrue_contribution_room(
                accounts=accounts,
                year=year,
                prior_year_earned_income=prior_year_earned_income,
                tfsa_limit=tax_tables.federal.tfsa_annual_limit,
                rrsp_dollar_limit=self.plan.assumptions.contribution_limits.rrsp_dollar_limit,
                max_pensionable_earnings=tax_tables.federal.cpp.max_pensionable_earnings,
                rrsp_contribution_room_by_owner=rrsp_contribution_room_by_owner,
            )
            years_from_start = year - start_year
            person1_age = year - self.plan.household.person1.birth_date.year
            person2_age = (
                year - self.plan.household.person2.birth_date.year if self.plan.household.person2 is not None else None
            )
            rebalancing_realized_capital_gains_total = 0.0
            rebalancing_taxable_capital_gains_total = 0.0
            rebalancing_realized_capital_gains = 0.0
            rebalancing_taxable_capital_gains = 0.0
            rebalancing_realized_capital_losses = 0.0
            rebalancing_taxable_capital_losses = 0.0
            if self.plan.assumptions.glide_path is not None:
                (
                    rebalancing_realized_capital_gains_total,
                    rebalancing_taxable_capital_gains_total,
                ) = apply_glide_path(
                    accounts,
                    person1_age,
                    self.plan.assumptions.glide_path,
                    self.plan.assumptions.investment_income_model.capital_gains_inclusion_rate,
                )
                rebalancing_realized_capital_gains = max(rebalancing_realized_capital_gains_total, 0.0)
                rebalancing_realized_capital_losses = max(-rebalancing_realized_capital_gains_total, 0.0)
                rebalancing_taxable_capital_gains = max(rebalancing_taxable_capital_gains_total, 0.0)
                rebalancing_taxable_capital_losses = max(-rebalancing_taxable_capital_gains_total, 0.0)

            person_age_by_owner: dict[str, int] = {}
            for person in self.plan.persons:
                person_age_by_owner[person.id] = year - person.birth_date.year

            start_of_year_balances = {account.id: account.balance for account in accounts}

            rrif_params = tax_tables.federal.rrif
            for account in accounts:
                convert_rrsp_to_rrif(
                    account,
                    conversion_age=rrif_params.conversion_age,
                    owner_age=person_age_by_owner.get(account.owner_id, 0),
                )
            rrif_minimums = apply_rrif_minimums(accounts, person_age_by_owner, rrif_params)

            income_totals = self._calculate_income_for_year(year, years_from_start)
            non_benefit_income = sum(income_totals.values(), 0.0)
            income_by_person = self._calculate_income_by_person_for_year(year, years_from_start)
            cpp_by_person = self._calculate_cpp_by_person_for_year(year, province=province)
            cpp_income = sum(cpp_by_person.values(), 0.0)
            # One-time events are in nominal dollars for their year (not inflated)
            one_time_income, one_time_expense = self._apply_one_time_events(year)
            total_income = non_benefit_income + cpp_income + one_time_income

            expenses = self._active_expenses_for_year(year)
            inflated_expenses = inflate_by_category(
                expenses,
                self.plan.assumptions.inflation,
                target_year=year,
                base_year=start_year,
                base_age=start_age,
                target_age=person1_age,
                expenditure_target=expenditure_target,
            )
            regular_expenses = sum(inflated_expenses.values(), 0.0)
            if expense_delta is not None:
                regular_expenses += inflate(expense_delta, self.plan.assumptions.inflation.general, years_from_start)
            recurring_expense_total = self._apply_recurring_expenses(year, start_year)
            total_expenses = regular_expenses + one_time_expense + recurring_expense_total

            black_swan = self.plan.assumptions.black_swan
            black_swan_shocks: dict[str, float] = {}
            if black_swan is not None and return_overrides is None:
                black_swan_shocks = self._apply_black_swan_shock(accounts, year, black_swan)

            if return_overrides is not None and year in return_overrides:
                effective_returns = return_overrides[year]
            else:
                effective_returns = self._get_effective_returns(
                    year, self.plan.assumptions.returns, black_swan if return_overrides is None else None
                )

            (
                account_returns,
                portfolio_dividend_income,
                portfolio_interest_income,
                portfolio_unrealized_growth,
            ) = self._apply_returns(
                accounts,
                effective_returns,
                self.plan.assumptions.investment_income_model,
            )
            for acc_id, shock in black_swan_shocks.items():
                account_returns[acc_id] = account_returns.get(acc_id, 0.0) + shock

            minimum_capital_gains_withdrawals = self._apply_minimum_capital_gains_events(
                accounts=accounts,
                year=year,
                capital_gains_inclusion_rate=self.plan.assumptions.investment_income_model.capital_gains_inclusion_rate,
                warnings=warnings,
            )

            portfolio_taxable_income = portfolio_dividend_income + portfolio_interest_income
            base_income_before_oas = non_benefit_income + cpp_income + one_time_income + portfolio_taxable_income
            waterfall_by_account: dict[str, Withdrawal] = {}
            withdrawal_non_reg = 0.0
            withdrawal_rrsp_rrif = 0.0
            withdrawal_tfsa = 0.0
            total_withdrawals = 0.0
            realized_capital_gains = 0.0
            realized_capital_losses = 0.0
            taxable_capital_gains = 0.0
            taxable_capital_losses = 0.0
            taxable_capital_gains_before_losses = 0.0
            taxable_capital_losses_available = 0.0
            taxable_capital_loss_carryforward_end = taxable_capital_loss_carryforward
            total_income = base_income_before_oas
            oas_income = 0.0
            oas_clawback = 0.0
            tax_result = tax_calculator.calculate_tax(
                taxable_income=0.0,
                tax_year=year,
                province=province,
            )
            net_income = 0.0
            cash_flow_gap = 0.0
            settle_tolerance = 1.0

            for _ in range(12):
                all_withdrawals = (
                    rrif_minimums + minimum_capital_gains_withdrawals + list(waterfall_by_account.values())
                )
                withdrawal_non_reg = sum(
                    (
                        entry.amount_withdrawn
                        for entry in all_withdrawals
                        if entry.account_type == AccountType.NON_REGISTERED
                    ),
                    0.0,
                )
                withdrawal_rrsp_rrif = sum(
                    (
                        entry.amount_withdrawn
                        for entry in all_withdrawals
                        if entry.account_type in {AccountType.RRSP, AccountType.RRIF}
                    ),
                    0.0,
                )
                withdrawal_tfsa = sum(
                    (entry.amount_withdrawn for entry in all_withdrawals if entry.account_type == AccountType.TFSA),
                    0.0,
                )
                total_withdrawals = withdrawal_non_reg + withdrawal_rrsp_rrif + withdrawal_tfsa
                withdrawal_realized_capital_gains = sum(
                    (max(entry.realized_capital_gains, 0.0) for entry in all_withdrawals),
                    0.0,
                )
                withdrawal_realized_capital_losses = sum(
                    (max(-entry.realized_capital_gains, 0.0) for entry in all_withdrawals),
                    0.0,
                )
                withdrawal_taxable_capital_gains = sum(
                    (max(entry.taxable_capital_gains, 0.0) for entry in all_withdrawals),
                    0.0,
                )
                withdrawal_taxable_capital_losses = sum(
                    (max(-entry.taxable_capital_gains, 0.0) for entry in all_withdrawals),
                    0.0,
                )
                realized_capital_gains = rebalancing_realized_capital_gains + withdrawal_realized_capital_gains
                realized_capital_losses = rebalancing_realized_capital_losses + withdrawal_realized_capital_losses
                taxable_capital_gains_before_losses = (
                    rebalancing_taxable_capital_gains + withdrawal_taxable_capital_gains
                )
                taxable_capital_losses = rebalancing_taxable_capital_losses + withdrawal_taxable_capital_losses
                taxable_capital_losses_available = taxable_capital_loss_carryforward + taxable_capital_losses
                taxable_capital_gains = max(
                    taxable_capital_gains_before_losses - taxable_capital_losses_available,
                    0.0,
                )
                taxable_capital_loss_carryforward_end = max(
                    taxable_capital_losses_available - taxable_capital_gains_before_losses,
                    0.0,
                )

                taxable_income_for_oas = base_income_before_oas + withdrawal_rrsp_rrif + taxable_capital_gains
                oas_income_by_person = self._build_oas_income_by_person(
                    income_by_person=income_by_person,
                    cpp_by_person=cpp_by_person,
                    one_time_income=one_time_income,
                    portfolio_taxable_income=portfolio_taxable_income,
                    all_withdrawals=all_withdrawals,
                    taxable_capital_gains=taxable_capital_gains,
                    accounts=accounts,
                )
                oas_income, oas_clawback = self._calculate_oas_for_year(
                    year=year,
                    net_income=taxable_income_for_oas,
                    province=province,
                    income_by_person=oas_income_by_person,
                )
                total_income = base_income_before_oas + oas_income
                taxable_income = total_income + withdrawal_rrsp_rrif + taxable_capital_gains
                tax_result = tax_calculator.calculate_tax(
                    taxable_income=taxable_income,
                    tax_year=year,
                    province=province,
                    taxpayer_age=person1_age,
                    eligible_dividends=portfolio_dividend_income,
                )
                split_result = self._try_pension_income_splitting(
                    tax_calculator=tax_calculator,
                    oas_income_by_person=oas_income_by_person,
                    year=year,
                    years_from_start=years_from_start,
                    province=province,
                    portfolio_dividend_income=portfolio_dividend_income,
                    all_withdrawals=all_withdrawals,
                    accounts=accounts,
                )
                if split_result is not None and split_result.total_tax < tax_result.total_tax:
                    tax_result = split_result
                net_income = total_income + total_withdrawals - tax_result.total_tax - oas_clawback
                cash_flow_gap = net_income - total_expenses

                if cash_flow_gap >= -settle_tolerance:
                    break

                additional_withdrawals = apply_waterfall(
                    accounts=accounts,
                    amount_needed=abs(cash_flow_gap),
                    order_config=self.plan.assumptions.withdrawal_assumptions().order,
                    capital_gains_inclusion_rate=self.plan.assumptions.investment_income_model.capital_gains_inclusion_rate,
                )
                if not additional_withdrawals:
                    break
                self._merge_withdrawals(waterfall_by_account, additional_withdrawals)

            taxable_capital_loss_carryforward = taxable_capital_loss_carryforward_end

            if cash_flow_gap > 0:
                self._allocate_surplus(accounts, cash_flow_gap, rrsp_contribution_room_by_owner)

            account_net_deposits = {
                account.id: account.balance - start_of_year_balances[account.id] - account_returns.get(account.id, 0.0)
                for account in accounts
            }

            total_non_reg = sum(
                (account.balance for account in accounts if account.account_type is AccountType.NON_REGISTERED),
                0.0,
            )
            total_rrsp_rrif = sum(
                (
                    account.balance
                    for account in accounts
                    if account.account_type in {AccountType.RRSP, AccountType.RRIF}
                ),
                0.0,
            )
            total_tfsa = sum(
                (account.balance for account in accounts if account.account_type is AccountType.TFSA),
                0.0,
            )
            total_net_worth = sum((account.balance for account in accounts), 0.0)
            account_balances = {account.id: account.balance for account in accounts}

            yearly_rows.append(
                YearlyProjection(
                    year=year,
                    person1_age=person1_age,
                    person2_age=person2_age,
                    employment_income=income_totals.get("employment", 0.0),
                    pension_income=income_totals.get("pension", 0.0),
                    cpp_income=cpp_income,
                    oas_income=oas_income,
                    oas_clawback=oas_clawback,
                    investment_income=income_totals.get("investment", 0.0),
                    portfolio_dividend_income=portfolio_dividend_income,
                    portfolio_interest_income=portfolio_interest_income,
                    portfolio_unrealized_growth=portfolio_unrealized_growth,
                    rebalancing_realized_capital_gains=rebalancing_realized_capital_gains,
                    rebalancing_taxable_capital_gains=rebalancing_taxable_capital_gains,
                    rebalancing_realized_capital_losses=rebalancing_realized_capital_losses,
                    rebalancing_taxable_capital_losses=rebalancing_taxable_capital_losses,
                    realized_capital_gains=realized_capital_gains,
                    realized_capital_losses=realized_capital_losses,
                    taxable_capital_gains=taxable_capital_gains,
                    taxable_capital_losses=taxable_capital_losses,
                    taxable_capital_loss_carryforward=taxable_capital_loss_carryforward,
                    other_income=income_totals.get("other", 0.0),
                    total_income=total_income,
                    federal_tax=tax_result.federal_tax,
                    provincial_tax=tax_result.provincial_tax,
                    total_tax=tax_result.total_tax,
                    marginal_tax_rate=tax_result.marginal_tax_rate,
                    average_tax_rate=tax_result.average_rate,
                    net_income=net_income,
                    total_expenses=total_expenses,
                    cash_flow_gap=cash_flow_gap,
                    withdrawal_non_reg=withdrawal_non_reg,
                    withdrawal_rrsp_rrif=withdrawal_rrsp_rrif,
                    withdrawal_tfsa=withdrawal_tfsa,
                    total_withdrawals=total_withdrawals,
                    total_non_reg=total_non_reg,
                    total_rrsp_rrif=total_rrsp_rrif,
                    total_tfsa=total_tfsa,
                    total_net_worth=total_net_worth,
                    account_balances=account_balances,
                    account_returns=account_returns,
                    account_net_deposits=account_net_deposits,
                    one_time_income=one_time_income,
                    one_time_expense=one_time_expense,
                    recurring_expense=recurring_expense_total,
                )
            )
            prior_year_earned_income = income_totals.get("employment", 0.0)

        final_net_worth = yearly_rows[-1].total_net_worth if yearly_rows else 0.0
        depletion_age = None
        for row in yearly_rows:
            if not math.isnan(row.total_net_worth) and row.total_net_worth <= 0:
                depletion_age = row.person1_age
                break

        # Spending-gap search is expensive and unnecessary for MC path generation.
        # We skip it when include_spending_analysis=False or during binary-search iterations.
        if include_spending_analysis and expense_delta is None:
            desired_spending = yearly_rows[0].total_expenses if yearly_rows else 0.0
            spending_gap = self._find_spending_gap(
                scenario_id=scenario_id,
                start_year=start_year,
                end_year=end_year,
                return_overrides=return_overrides,
                tax_tables_by_year=resolved_tax_tables_by_year,
            )
            sustainable_spending = desired_spending + spending_gap
        else:
            desired_spending = 0.0
            sustainable_spending = 0.0
            spending_gap = 0.0

        return ProjectionResult(
            scenario_id=scenario_id,
            years=yearly_rows,
            final_net_worth=final_net_worth,
            depletion_age=depletion_age,
            sustainable_spending=sustainable_spending,
            desired_spending=desired_spending,
            spending_gap=spending_gap,
            warnings=warnings,
        )

    def _find_spending_gap(
        self,
        scenario_id: str,
        start_year: int,
        end_year: int,
        return_overrides: dict[int, ReturnAssumptions] | None,
        tax_tables_by_year: dict[int, TaxTables],
    ) -> float:
        """Binary search for the maximum constant real spending adjustment.

        Returns the largest annual delta (year-1 dollars) that can be added
        to the plan's actual expenses without causing depletion.  A positive
        result means there is room to spend more; a negative result means
        spending must be cut.
        """
        lo = -500000.0
        hi = 500000.0
        tolerance = 100.0

        for _ in range(50):
            mid = (lo + hi) / 2
            result = self.run_projection(
                scenario_id=scenario_id,
                start_year=start_year,
                end_year=end_year,
                return_overrides=return_overrides,
                expense_delta=mid,
                tax_tables_by_year=tax_tables_by_year,
            )
            if result.depletion_age is not None:
                hi = mid
            else:
                lo = mid
            if hi - lo < tolerance:
                break

        return round(lo)

    def _apply_recurring_expenses(self, year: int, start_year: int) -> float:
        """Return total recurring expenses for the given year, inflated from start_year.

        Amount is in current dollars (same convention as regular expenses) and is
        inflated from the projection start_year using the general inflation rate.
        """
        total = 0.0
        for rec in self.plan.recurring_expenses:
            if year < rec.start_year:
                continue
            if rec.end_year is not None and year > rec.end_year:
                continue
            if (year - rec.start_year) % rec.period_years != 0:
                continue
            years_elapsed = year - start_year
            total += inflate(rec.amount, self.plan.assumptions.inflation.general, years_elapsed)
        return total

    def _get_expenditure_target_for_spending_curve(self, start_year: int) -> float:
        """Approximate retiree expenditure target from active plan expenses at projection start."""
        active_expenses = self._active_expenses_for_year(start_year)
        target = sum((expense.annual_amount for expense in active_expenses), 0.0)
        if target <= 0:
            return 1.0
        return target

    def _apply_one_time_events(self, year: int) -> tuple[float, float]:
        """Return (one_time_income, one_time_expense) for the given year."""
        income = 0.0
        expenses = 0.0
        for event in self.plan.one_time_events:
            if not event.applies_to_year(year):
                continue
            if event.event_type == "income":
                income += event.amount
            elif event.event_type == "expense":
                expenses += event.amount
        return income, expenses

    def _apply_minimum_capital_gains_events(
        self,
        accounts: list[Account],
        year: int,
        capital_gains_inclusion_rate: float,
        warnings: list[str],
    ) -> list[Withdrawal]:
        target_gain = sum(
            (
                event.amount
                for event in self.plan.one_time_events
                if event.event_type == "minimum-capgain" and event.applies_to_year(year)
            ),
            0.0,
        )
        if target_gain <= 0:
            return []

        candidates = [account for account in accounts if account.account_type is AccountType.NON_REGISTERED]
        if not candidates:
            warnings.append(
                f"minimum-capgain event in {year} requires non-registered accounts, but none were found. "
                f"No capital gains were realized."
            )
            return []

        account_gain_ratio: dict[str, float] = {}
        max_realizable_gains = 0.0
        for account in candidates:
            if account.balance <= 0:
                continue
            unrealized_gain = max(account.balance - account.cost_basis, 0.0)
            if unrealized_gain <= 0:
                continue
            gain_ratio = unrealized_gain / account.balance
            account_gain_ratio[account.id] = gain_ratio
            max_realizable_gains += unrealized_gain

        if max_realizable_gains < target_gain:
            warnings.append(
                f"minimum-capgain target of ${target_gain:,.0f} in {year} exceeds available unrealized gains "
                f"(${max_realizable_gains:,.0f}). Clamped to ${max_realizable_gains:,.0f}."
            )
            target_gain = max_realizable_gains

        remaining_gain = target_gain
        withdrawals: list[Withdrawal] = []
        ordered_candidates = sorted(
            (account for account in candidates if account.id in account_gain_ratio),
            key=lambda account: account_gain_ratio[account.id],
            reverse=True,
        )

        for account in ordered_candidates:
            if remaining_gain <= 0.0:
                break
            gain_ratio = account_gain_ratio[account.id]
            if gain_ratio <= 0 or account.balance <= 0:
                continue

            required_sale = remaining_gain / gain_ratio
            withdrawn = min(required_sale, account.balance)
            if withdrawn <= 0:
                continue

            opening_balance = account.balance
            acb_ratio = account.cost_basis / opening_balance if opening_balance > 0 else 0.0
            acb_reduction = min(account.cost_basis, withdrawn * acb_ratio)
            realized_gain = withdrawn - acb_reduction

            account.balance -= withdrawn
            account.cost_basis -= acb_reduction
            remaining_gain -= realized_gain

            withdrawals.append(
                Withdrawal(
                    account_id=account.id,
                    account_type=account.account_type,
                    amount_withdrawn=withdrawn,
                    realized_capital_gains=realized_gain,
                    taxable_capital_gains=realized_gain * capital_gains_inclusion_rate,
                )
            )

        return withdrawals

    def _active_expenses_for_year(self, year: int) -> list[Expense]:
        start = f"{year}-01-01"
        end = f"{year}-12-31"
        active: list[Expense] = []
        for expense in self.plan.expenses:
            if expense.start_date is None:
                continue
            if expense.start_date.isoformat() > end:
                continue
            if expense.end_date is not None and expense.end_date.isoformat() < start:
                continue
            active.append(expense)
        return active

    def _calculate_income_for_year(self, year: int, years_from_start: int) -> dict[str, float]:
        totals = {
            "employment": 0.0,
            "pension": 0.0,
            "investment": 0.0,
            "other": 0.0,
        }
        start = f"{year}-01-01"
        end = f"{year}-12-31"

        for source in self.plan.income:
            if source.start_date is None:
                continue
            if source.start_date.isoformat() > end:
                continue
            if source.end_date is not None and source.end_date.isoformat() < start:
                continue

            if source.income_type is IncomeType.PENSION:
                amount = _pension_nominal_amount(source, year, self.plan.assumptions.inflation.income)
            else:
                rate = self.plan.assumptions.inflation.income if source.indexed else 0.0
                amount = inflate(source.annual_amount, rate, years_from_start)
            if source.income_type in {IncomeType.EMPLOYMENT, IncomeType.SELF_EMPLOYMENT}:
                totals["employment"] += amount
            elif source.income_type is IncomeType.PENSION:
                totals["pension"] += amount
            elif source.income_type is IncomeType.RENTAL:
                totals["investment"] += amount
            else:
                totals["other"] += amount

        return totals

    def _calculate_cpp_income_for_year(self, year: int, province: str) -> float:
        return sum(self._calculate_cpp_by_person_for_year(year, province).values(), 0.0)

    def _calculate_cpp_by_person_for_year(self, year: int, province: str) -> dict[str, float]:
        by_person: dict[str, float] = {}
        for person in self.plan.persons:
            age = year - person.birth_date.year
            if age < person.cpp_start_age:
                by_person[person.id] = 0.0
                continue
            contribution_years = max(min(person.cpp_start_age - 18, 39), 0)
            by_person[person.id] = calculate_cpp_benefit(
                start_age=person.cpp_start_age,
                contribution_years=contribution_years,
                average_earnings=999999.0,
                tax_year=year,
                province=province,
                projection_assumptions=self.plan.assumptions.tax_projection.model_dump(mode="python"),
            )
        return by_person

    def _calculate_income_by_person_for_year(self, year: int, years_from_start: int) -> dict[str, float]:
        """Return per-person taxable income from income sources (excl CPP/OAS)."""
        by_person: dict[str, float] = {person.id: 0.0 for person in self.plan.persons}
        person_ids = set(by_person.keys())
        n_persons = float(max(len(self.plan.persons), 1))
        start = f"{year}-01-01"
        end = f"{year}-12-31"

        for source in self.plan.income:
            if source.start_date is None:
                continue
            if source.start_date.isoformat() > end:
                continue
            if source.end_date is not None and source.end_date.isoformat() < start:
                continue
            if source.income_type is IncomeType.PENSION:
                amount = _pension_nominal_amount(source, year, self.plan.assumptions.inflation.income)
            else:
                rate = self.plan.assumptions.inflation.income if source.indexed else 0.0
                amount = inflate(source.annual_amount, rate, years_from_start)
            if source.owner_id in person_ids:
                by_person[source.owner_id] += amount
            else:
                per_person = amount / n_persons
                for pid in by_person:
                    by_person[pid] += per_person
        return by_person

    def _build_oas_income_by_person(
        self,
        income_by_person: dict[str, float],
        cpp_by_person: dict[str, float],
        one_time_income: float,
        portfolio_taxable_income: float,
        all_withdrawals: list[Withdrawal],
        taxable_capital_gains: float,
        accounts: list[Account],
    ) -> dict[str, float]:
        """Build per-person taxable income for OAS clawback calculation."""
        person_ids = {person.id for person in self.plan.persons}
        n_persons = float(max(len(self.plan.persons), 1))
        account_owner = {account.id: account.owner_id for account in accounts}
        # Also include owners from withdrawals that reference accounts already removed from the list
        for w in all_withdrawals:
            if w.account_id not in account_owner:
                account_owner[w.account_id] = ""

        result: dict[str, float] = {}
        for pid in person_ids:
            result[pid] = income_by_person.get(pid, 0.0) + cpp_by_person.get(pid, 0.0)

        # Attribute RRSP/RRIF withdrawals by account owner
        for w in all_withdrawals:
            if w.account_type not in {AccountType.RRSP, AccountType.RRIF}:
                continue
            owner = account_owner.get(w.account_id, "")
            if owner in person_ids:
                result[owner] += w.amount_withdrawn
            else:
                per_person = w.amount_withdrawn / n_persons
                for pid in result:
                    result[pid] += per_person

        # Split one-time income, portfolio income, and capital gains evenly
        shared = (one_time_income + portfolio_taxable_income + taxable_capital_gains) / n_persons
        for pid in result:
            result[pid] += shared

        return result

    def _try_pension_income_splitting(
        self,
        tax_calculator: TaxCalculator,
        oas_income_by_person: dict[str, float],
        year: int,
        years_from_start: int,
        province: str,
        portfolio_dividend_income: float,
        all_withdrawals: list[Withdrawal],
        accounts: list[Account],
    ) -> TaxResult | None:
        """Try 50% pension income splitting; return TaxResult if it reduces tax."""
        if len(self.plan.persons) < 2:
            return None
        person_by_id = {p.id: p for p in self.plan.persons}
        start = f"{year}-01-01"
        end = f"{year}-12-31"

        eligible: dict[str, float] = {p.id: 0.0 for p in self.plan.persons}
        for source in self.plan.income:
            if not source.is_eligible_for_splitting:
                continue
            if source.start_date is None or source.start_date.isoformat() > end:
                continue
            if source.end_date is not None and source.end_date.isoformat() < start:
                continue
            person = person_by_id.get(source.owner_id)
            if person is None:
                continue
            age = year - person.birth_date.year
            if age < 65:
                continue
            if source.income_type is IncomeType.PENSION:
                amount = _pension_nominal_amount(source, year, self.plan.assumptions.inflation.income)
            else:
                raise AssertionError(f"Unexpected eligible-for-splitting income type: {source.income_type}")
            eligible[source.owner_id] += amount

        # RRIF/LIF withdrawals are eligible for splitting when owner is 65+
        account_owner = {account.id: account.owner_id for account in accounts}
        for w in all_withdrawals:
            if w.account_id not in account_owner:
                account_owner[w.account_id] = ""
        for w in all_withdrawals:
            if w.account_type not in {AccountType.RRIF, AccountType.LIF}:
                continue
            owner_id = account_owner.get(w.account_id, "")
            person = person_by_id.get(owner_id)
            if person is None:
                continue
            age = year - person.birth_date.year
            if age < 65:
                continue
            eligible[owner_id] += w.amount_withdrawn

        if sum(eligible.values()) <= 0:
            return None

        oas_gross: dict[str, float] = {}
        for person in self.plan.persons:
            age = year - person.birth_date.year
            if age >= person.oas_start_age:
                gross, _ = calculate_oas_benefit(
                    start_age=person.oas_start_age,
                    net_income=oas_income_by_person.get(person.id, 0.0),
                    tax_year=year,
                    province=province,
                    projection_assumptions=self.plan.assumptions.tax_projection.model_dump(mode="python"),
                )
                oas_gross[person.id] = gross
            else:
                oas_gross[person.id] = 0.0

        taxable: dict[str, float] = {
            p.id: oas_income_by_person.get(p.id, 0.0) + oas_gross.get(p.id, 0.0) for p in self.plan.persons
        }

        p1, p2 = self.plan.persons[0], self.plan.persons[1]
        higher, lower = (p1, p2) if taxable[p1.id] >= taxable[p2.id] else (p2, p1)
        transfer = eligible.get(higher.id, 0.0) * 0.5
        if transfer <= 0:
            return None

        split = dict(taxable)
        split[higher.id] -= transfer
        split[lower.id] += transfer

        n = float(len(self.plan.persons))
        per_div = portfolio_dividend_income / n
        combined_federal = 0.0
        combined_provincial = 0.0
        combined_total = 0.0
        max_marginal = 0.0
        for person in self.plan.persons:
            r = tax_calculator.calculate_tax(
                taxable_income=split[person.id],
                tax_year=year,
                province=province,
                taxpayer_age=year - person.birth_date.year,
                eligible_dividends=per_div,
            )
            combined_federal += r.federal_tax
            combined_provincial += r.provincial_tax
            combined_total += r.total_tax
            if r.marginal_tax_rate > max_marginal:
                max_marginal = r.marginal_tax_rate

        total_income = sum(split.values())
        return TaxResult(
            federal_tax=combined_federal,
            provincial_tax=combined_provincial,
            total_tax=combined_total,
            marginal_tax_rate=max_marginal,
            average_rate=combined_total / total_income if total_income > 0 else 0.0,
        )

    def _calculate_oas_for_year(
        self,
        year: int,
        net_income: float,
        province: str,
        income_by_person: dict[str, float] | None = None,
    ) -> tuple[float, float]:
        eligible_persons = [
            person for person in self.plan.persons if (year - person.birth_date.year) >= person.oas_start_age
        ]
        if not eligible_persons:
            return 0.0, 0.0

        gross_total = 0.0
        clawback_total = 0.0
        for person in eligible_persons:
            if income_by_person is not None:
                person_income = income_by_person.get(person.id, 0.0)
            else:
                person_income = net_income / float(len(eligible_persons))
            gross, clawback = calculate_oas_benefit(
                start_age=person.oas_start_age,
                net_income=person_income,
                tax_year=year,
                province=province,
                projection_assumptions=self.plan.assumptions.tax_projection.model_dump(mode="python"),
            )
            gross_total += gross
            clawback_total += clawback
        return gross_total, clawback_total

    def _apply_returns(
        self,
        accounts: list[Account],
        assumptions: ReturnAssumptions,
        investment_income_model: InvestmentIncomeAssumptions,
    ) -> tuple[dict[str, float], float, float, float]:
        account_returns: dict[str, float] = {}
        portfolio_dividend_income = 0.0
        portfolio_interest_income = 0.0
        portfolio_unrealized_growth = 0.0
        for account in accounts:
            weighted_return = 0.0
            weighted_dividend_yield = 0.0
            weighted_interest_yield = 0.0
            for asset_class, weight in account.asset_mix.items():
                match asset_class:
                    case AssetClass.EQUITY:
                        weighted_return += assumptions.equity_return * weight
                        weighted_dividend_yield += investment_income_model.equity_dividend_yield * weight
                    case AssetClass.FIXED_INCOME:
                        weighted_return += assumptions.fixed_income_return * weight
                        weighted_interest_yield += investment_income_model.fixed_income_distribution_yield * weight
                    case AssetClass.CASH:
                        weighted_return += assumptions.cash_return * weight
                        weighted_interest_yield += investment_income_model.cash_interest_yield * weight
                    case _:
                        weighted_return += assumptions.real_estate_return * weight
            return_amount = account.balance * weighted_return
            estimated_dividend_income = account.balance * weighted_dividend_yield
            estimated_interest_income = account.balance * weighted_interest_yield
            estimated_unrealized_growth = return_amount - estimated_dividend_income - estimated_interest_income
            account.balance = account.balance + return_amount
            account_returns[account.id] = return_amount
            if account.account_type is AccountType.NON_REGISTERED:
                portfolio_dividend_income += estimated_dividend_income
                portfolio_interest_income += estimated_interest_income
                portfolio_unrealized_growth += estimated_unrealized_growth
        return account_returns, portfolio_dividend_income, portfolio_interest_income, portfolio_unrealized_growth

    def _merge_withdrawals(self, aggregate: dict[str, Withdrawal], additions: list[Withdrawal]) -> None:
        for addition in additions:
            existing = aggregate.get(addition.account_id)
            if existing is None:
                aggregate[addition.account_id] = addition
                continue
            aggregate[addition.account_id] = Withdrawal(
                account_id=addition.account_id,
                account_type=addition.account_type,
                amount_withdrawn=existing.amount_withdrawn + addition.amount_withdrawn,
                realized_capital_gains=existing.realized_capital_gains + addition.realized_capital_gains,
                taxable_capital_gains=existing.taxable_capital_gains + addition.taxable_capital_gains,
            )

    def _allocate_surplus(
        self,
        accounts: list[Account],
        surplus: float,
        rrsp_contribution_room_by_owner: dict[str, float],
    ) -> None:
        preferred_types = [
            AccountType.RRSP,
            AccountType.TFSA,
            AccountType.NON_REGISTERED,
            AccountType.LIRA,
            AccountType.LIF,
        ]
        for preferred in preferred_types:
            for account in accounts:
                if account.account_type is preferred:
                    if preferred is AccountType.RRSP:
                        room = rrsp_contribution_room_by_owner.get(account.owner_id, 0.0)
                        if room <= 0:
                            continue
                        contribution = min(surplus, room)
                        account.balance += contribution
                        rrsp_contribution_room_by_owner[account.owner_id] = room - contribution
                        surplus -= contribution
                        if surplus <= 0:
                            return
                    elif preferred is AccountType.TFSA:
                        room = account.contribution_room or 0.0
                        if room <= 0:
                            continue
                        contribution = min(surplus, room)
                        account.balance += contribution
                        account.contribution_room = room - contribution
                        surplus -= contribution
                        if surplus <= 0:
                            return
                    else:
                        if preferred is AccountType.NON_REGISTERED:
                            account.cost_basis += surplus
                        account.balance += surplus
                        return
        if accounts and surplus > 0:
            if accounts[0].account_type is AccountType.NON_REGISTERED:
                accounts[0].cost_basis += surplus
            accounts[0].balance += surplus

    def _apply_black_swan_shock(
        self, accounts: list[Account], year: int, black_swan: BlackSwanAssumptions
    ) -> dict[str, float]:
        """In the trigger year, reduce each account's balance by equity_weight * balance * shock_pct.

        Returns a dict of account_id → shock_amount (negative) so the loss is
        tracked as an investment return, not a net deposit.
        """
        shocks: dict[str, float] = {}
        if year != black_swan.trigger_year:
            return shocks
        for account in accounts:
            equity_weight = account.asset_mix.get(AssetClass.EQUITY, 0.0)
            if equity_weight > 0:
                shock_amount = account.balance * equity_weight * black_swan.equity_shock_pct
                account.balance += shock_amount  # shock_pct is negative, so this reduces balance
                shocks[account.id] = shock_amount
        return shocks

    def _get_effective_returns(
        self,
        year: int,
        base_returns: ReturnAssumptions,
        black_swan: BlackSwanAssumptions | None,
    ) -> ReturnAssumptions:
        """During the flat period after a black swan shock, return equity_return=0."""
        if black_swan is None:
            return base_returns
        flat_start = black_swan.trigger_year + 1
        flat_end = black_swan.trigger_year + black_swan.flat_return_years
        if flat_start <= year <= flat_end:
            return ReturnAssumptions(
                equity=0.0,
                fixed_income=base_returns.fixed_income_return,
                cash=base_returns.cash_return,
                real_estate=base_returns.real_estate_return,
            )
        return base_returns
