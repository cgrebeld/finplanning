from math import log

from finplanning_core.models.assumptions import InflationAssumptions
from finplanning_core.models.expenses import Expense, ExpenseCategory


def inflate(base_amount: float, rate: float, years: int) -> float:
    """Compound an amount by an annual rate for a number of years."""
    if years <= 0:
        return base_amount
    return base_amount * (1.0 + rate) ** years


def inflate_by_category(
    expenses: list[Expense],
    inflation_assumptions: InflationAssumptions,
    target_year: int,
    base_year: int,
    *,
    base_age: int | None = None,
    target_age: int | None = None,
    expenditure_target: float | None = None,
) -> dict[str, float]:
    """Inflate expenses by category rate for the target year."""
    years = max(0, target_year - base_year)
    real_adjustment_factor: float = 1.0
    if base_age is not None and target_age is not None and expenditure_target is not None:
        real_adjustment_factor = blanchett_real_spending_factor(
            base_age=base_age,
            target_age=target_age,
            expenditure_target=expenditure_target,
        )

    result: dict[str, float] = {}
    for expense in expenses:
        match expense.category:
            case ExpenseCategory.ESSENTIAL:
                rate = inflation_assumptions.essential
            case ExpenseCategory.DISCRETIONARY:
                rate = inflation_assumptions.discretionary
            case ExpenseCategory.HEALTHCARE:
                rate = inflation_assumptions.healthcare
            case _:
                rate = inflation_assumptions.general
        result[expense.id] = inflate(expense.annual_amount, rate, years) * real_adjustment_factor
    return result


def blanchett_real_spending_change(age: int, expenditure_target: float) -> float:
    """Return annual real spending change using Blanchett's 2014 curve model.

    Equation (1), lines 468-469 from the paper:
    Annual Real Spending Change =
      0.00008*(Age^2) - 0.0125*Age - 0.0066*ln(ExpTar) + 0.546

    Paper adjustment (lines 501-502): add 0.5% for expenditure_target > $85,000.
    Model is applied for ages 60..95; outside that range returns 0.
    """
    if age < 60 or age > 95:
        return 0.0

    safe_target = expenditure_target if expenditure_target > 0 else 1.0
    log_target = log(safe_target)

    change = 0.00008 * (age**2) - 0.0125 * age - 0.0066 * log_target + 0.546
    if safe_target > 85000:
        change += 0.005
    return change


def blanchett_real_spending_factor(base_age: int, target_age: int, expenditure_target: float) -> float:
    """Return cumulative real spending multiplier from base_age to target_age."""
    if target_age <= base_age:
        return 1.0

    factor = 1.0
    for age in range(base_age + 1, target_age + 1):
        factor *= 1.0 + blanchett_real_spending_change(age=age, expenditure_target=expenditure_target)
    return factor
