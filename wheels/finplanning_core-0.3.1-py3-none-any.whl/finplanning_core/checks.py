import argparse
import importlib.util
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
NATIVE_CRATE_DIR = PROJECT_ROOT / "native" / "finplanning_core_native"


@dataclass(frozen=True)
class CommandSpec:
    args: list[str]
    cwd: Path | None = None


CHECK_COMMANDS: dict[str, CommandSpec] = {
    "format": CommandSpec(["ruff", "format", "finplanning_core/", "tests/"]),
    "lint": CommandSpec(["ruff", "check", "finplanning_core/", "tests/", "--fix"]),
    "lint-strict": CommandSpec(["ruff", "check", "finplanning_core/", "tests/"]),
    "type": CommandSpec([sys.executable, "-m", "mypy", "finplanning_core/"]),
    "rust-format": CommandSpec(["cargo", "fmt", "--all", "--", "--check"], cwd=NATIVE_CRATE_DIR),
    "rust-lint": CommandSpec(
        ["cargo", "clippy", "--all-targets", "--all-features", "--", "-D", "warnings"], cwd=NATIVE_CRATE_DIR
    ),
    "test": CommandSpec([sys.executable, "-m", "pytest", "tests/", "-v"]),
    "native-test": CommandSpec(
        [
            sys.executable,
            "-m",
            "pytest",
            "tests/unit/test_native_module.py",
            "tests/unit/test_monte_carlo_native_switch.py",
            "tests/unit/test_native_kernel_conversion.py",
            "tests/integration/test_monte_carlo_rust_fast.py",
            "-v",
        ]
    ),
}


def _benchmark_commands() -> list[CommandSpec]:
    base = [
        sys.executable,
        "-m",
        "finplanning_core.tools._impl.monte_carlo_benchmark",
        "--plan",
        "tests/testdata/sample-plan.yaml",
        "--repeat",
        "1",
        "--workers",
        "1",
        "--fidelity",
        "full",
    ]
    commands: list[CommandSpec] = []
    for iterations in ("500", "2000"):
        args = base + ["--iterations", iterations]
        commands.append(CommandSpec(args + ["--kernel", "python"]))
        commands.append(CommandSpec(args + ["--kernel", "rust"]))
    return commands


def build_command_plan(check: str, extra_args: list[str]) -> list[CommandSpec]:
    if check == "native-build":
        if extra_args:
            raise ValueError("Extra tool args are not supported with 'native-build'.")
        if sys.version_info[:2] != (3, 12):
            raise ValueError("native-build requires running finplan-check with Python 3.12.")
        if importlib.util.find_spec("maturin") is None:
            raise ValueError("maturin is not installed in the active environment. Run dependency sync first.")
        return [CommandSpec([sys.executable, "-m", "maturin", "develop"], cwd=NATIVE_CRATE_DIR)]
    if check == "precommit":
        steps = ["format", "lint", "type", "rust-format", "rust-lint"]
        return [CommandSpec(CHECK_COMMANDS[step].args + extra_args, cwd=CHECK_COMMANDS[step].cwd) for step in steps]
    if check == "all":
        steps = ["format", "lint", "type", "test"]
        return [CommandSpec(CHECK_COMMANDS[step].args + extra_args, cwd=CHECK_COMMANDS[step].cwd) for step in steps]
    if check == "benchmark":
        if extra_args:
            raise ValueError("Extra tool args are not supported with 'benchmark'.")
        return _benchmark_commands()
    if check == "parity-trace":
        return [
            CommandSpec([sys.executable, "-m", "finplanning_core.tools._impl.monte_carlo_parity_trace"] + extra_args)
        ]
    if check == "ci":
        if extra_args:
            raise ValueError("Extra tool args are not supported with 'ci'.")
        plan = [
            CHECK_COMMANDS["format"],
            CHECK_COMMANDS["lint-strict"],
            CHECK_COMMANDS["type"],
            CHECK_COMMANDS["rust-format"],
            CHECK_COMMANDS["rust-lint"],
        ]
        plan.extend(build_command_plan("native-build", []))
        plan.append(CHECK_COMMANDS["test"])
        plan.append(CHECK_COMMANDS["native-test"])
        return plan
    if check not in CHECK_COMMANDS:
        raise ValueError(f"Unknown check: {check}")
    spec = CHECK_COMMANDS[check]
    return [CommandSpec(spec.args + extra_args, cwd=spec.cwd)]


def run_command(command: CommandSpec) -> int:
    completed = subprocess.run(command.args, cwd=command.cwd, check=False)
    return completed.returncode


def main() -> None:
    parser = argparse.ArgumentParser(description="Run project quality checks.")
    parser.add_argument(
        "check",
        choices=[
            "format",
            "lint",
            "lint-strict",
            "type",
            "rust-format",
            "rust-lint",
            "precommit",
            "test",
            "all",
            "native-build",
            "native-test",
            "benchmark",
            "parity-trace",
            "ci",
        ],
        help="Which check to run",
    )
    parser.add_argument(
        "tool_args",
        nargs=argparse.REMAINDER,
        help="Extra args passed to the selected tool (prefix with --)",
    )
    args = parser.parse_args()

    extra_args = args.tool_args
    if extra_args and extra_args[0] == "--":
        extra_args = extra_args[1:]

    if args.check in {"precommit", "all"} and extra_args:
        parser.error("Extra tool args are not supported with 'precommit' or 'all'. Run each check separately.")
    if args.check in {"benchmark", "ci"} and extra_args:
        parser.error(f"Extra tool args are not supported with '{args.check}'.")

    try:
        plan = build_command_plan(args.check, extra_args)
    except ValueError as exc:
        parser.error(str(exc))

    for command in plan:
        cwd_note = f" (cwd={command.cwd})" if command.cwd is not None else ""
        print(f"$ {' '.join(command.args)}{cwd_note}")
        exit_code = run_command(command)
        if exit_code != 0:
            sys.exit(exit_code)


if __name__ == "__main__":
    main()
