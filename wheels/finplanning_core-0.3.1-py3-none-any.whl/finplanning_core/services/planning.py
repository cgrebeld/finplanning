from __future__ import annotations

from collections.abc import Callable
from datetime import date
from pathlib import Path

from finplanning_core.engine.engine import CashFlowEngine
from finplanning_core.engine.projection import ProjectionResult
from finplanning_core.loader.user_data import load_user_data, load_user_data_from_string
from finplanning_core.models.plan import HouseholdPlan
from finplanning_core.risk.monte_carlo import MonteCarloConfig, MonteCarloEngine, MonteCarloResult
from finplanning_core.scenarios.comparison import ComparisonResult, compare_scenarios
from finplanning_core.scenarios.manager import ScenarioManager


class PlanningService:
    """Application-layer facade over the engine, loader, and scenario modules.

    This is the single entry point for all consumers (CLI, Streamlit UI,
    notebooks, tests).
    """

    def __init__(self, plan: HouseholdPlan) -> None:
        self._plan = plan
        self._manager = ScenarioManager(plan)

    @classmethod
    def from_yaml(cls, file_path: str | Path) -> PlanningService:
        """Load a plan from a YAML file and return a ready-to-use service."""
        plan = load_user_data(str(file_path))
        return cls(plan)

    @classmethod
    def from_yaml_string(cls, yaml_content: str) -> PlanningService:
        """Parse a YAML string and return a ready-to-use service."""
        plan = load_user_data_from_string(yaml_content)
        return cls(plan)

    @property
    def plan(self) -> HouseholdPlan:
        return self._plan

    @property
    def manager(self) -> ScenarioManager:
        return self._manager

    def run_projection(
        self,
        scenario_id: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> ProjectionResult:
        """Run a projection for a single scenario.

        Args:
            scenario_id: defaults to plan.base_scenario_id
            start_year: defaults to current year
            end_year: defaults to youngest person's birth year + max life expectancy
        """
        sid = scenario_id or self._plan.base_scenario_id
        plan = self._manager.get_plan(sid)
        engine = CashFlowEngine(plan)
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)
        return engine.run_projection(scenario_id=sid, start_year=sy, end_year=ey)

    def compare_scenarios(
        self,
        scenario_ids: list[str] | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> ComparisonResult:
        """Run projections for multiple scenarios and return a comparison."""
        ids = scenario_ids or self._manager.scenario_ids
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)
        return compare_scenarios(
            manager=self._manager,
            scenario_ids=ids,
            start_year=sy,
            end_year=ey,
        )

    def run_monte_carlo(
        self,
        scenario_id: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
        config: MonteCarloConfig | None = None,
        progress_callback: Callable[[float], object] | None = None,
    ) -> MonteCarloResult:
        """Run a Monte Carlo simulation for a single scenario."""
        sid = scenario_id or self._plan.base_scenario_id
        plan = self._manager.get_plan(sid)
        mc_engine = MonteCarloEngine(plan)
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)
        return mc_engine.run_simulation(
            scenario_id=sid,
            start_year=sy,
            end_year=ey,
            config=config,
            progress_callback=progress_callback,
        )

    def clone_scenario(self, source_id: str, new_name: str) -> str:
        """Clone a scenario and return the new scenario ID."""
        scenario = self._manager.clone_scenario(source_id, new_name)
        return scenario.id

    def apply_override(self, scenario_id: str, path: str, value: object) -> None:
        """Apply a single leaf override to a scenario."""
        self._manager.apply_override(scenario_id, path, value)

    def remove_override(self, scenario_id: str, path: str) -> None:
        """Remove a single leaf override from a scenario."""
        self._manager.remove_override(scenario_id, path)


def _default_start_year() -> int:
    return date.today().year


def _default_end_year(plan: HouseholdPlan) -> int:
    max_age = max(p.life_expectancy_age for p in plan.persons)
    youngest_birth_year = max(p.birth_date.year for p in plan.persons)
    return youngest_birth_year + max_age
