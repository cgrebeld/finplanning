import re
from datetime import date
from typing import Literal, Self

from pydantic import BaseModel, Field, field_validator, model_validator

from finplanning_core.models.accounts import Account
from finplanning_core.models.assumptions import (
    BlackSwanAssumptions,
    ContributionLimitAssumptions,
    GlidePath,
    InflationAssumptions,
    InvestmentIncomeAssumptions,
    ReturnAssumptions,
    TaxProjectionAssumptions,
    WithdrawalAssumptions,
)
from finplanning_core.models.expenses import Expense
from finplanning_core.models.household import Household, Person, Province
from finplanning_core.models.income import IncomeSource
from finplanning_core.models.scenarios import ScenarioOverrides

YEAR_ONLY_PATTERN = re.compile(r"^\d{4}$")


class ScenarioDefinition(BaseModel):
    id: str
    name: str
    is_base_case: bool = False


class OneTimeEvent(BaseModel):
    id: str
    name: str
    event_type: Literal["income", "expense", "minimum-capgain"] = Field(alias="type")
    amount: float = Field(ge=0)
    year: int
    repeat_for_years: int = Field(default=0, ge=0)

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def normalize_amount_alias(cls, data: object) -> object:
        if isinstance(data, dict) and "amount" not in data and "value" in data:
            normalized = dict(data)
            normalized["amount"] = normalized["value"]
            return normalized
        return data

    def applies_to_year(self, year: int) -> bool:
        return self.year <= year <= (self.year + self.repeat_for_years)


class RecurringExpense(BaseModel):
    """Expense that repeats on a fixed period, indexed to inflation.

    Amount is in current dollars (same as regular expenses) and gets inflated
    from the projection start year using the general inflation rate.

    Example: buying a new car every 6 years starting 2026, base amount $40,000.
    """

    id: str
    name: str
    amount: float = Field(ge=0)
    start_year: int
    period_years: int = Field(ge=1)
    end_year: int | None = Field(default=None, description="Last year this expense can occur (inclusive)")

    @model_validator(mode="after")
    def validate_end_after_start(self) -> Self:
        if self.end_year is not None and self.end_year < self.start_year:
            raise ValueError(f"end_year ({self.end_year}) must be >= start_year ({self.start_year})")
        return self


class PlanAssumptions(BaseModel):
    returns: ReturnAssumptions = Field(default_factory=ReturnAssumptions)
    inflation: InflationAssumptions = Field(default_factory=InflationAssumptions)
    withdrawal_order: list[str] = Field(default_factory=lambda: ["NON_REGISTERED", "RRSP", "TFSA"])
    investment_income_model: InvestmentIncomeAssumptions = Field(default_factory=InvestmentIncomeAssumptions)
    contribution_limits: ContributionLimitAssumptions = Field(default_factory=ContributionLimitAssumptions)
    tax_projection: TaxProjectionAssumptions = Field(default_factory=TaxProjectionAssumptions)
    glide_path: GlidePath | None = None
    black_swan: BlackSwanAssumptions | None = None

    def withdrawal_assumptions(self) -> WithdrawalAssumptions:
        return WithdrawalAssumptions(order={key: idx + 1 for idx, key in enumerate(self.withdrawal_order)})


class HouseholdPlan(BaseModel):
    schema_version: int = 1
    household: Household
    persons: list[Person]
    accounts: list[Account]
    income: list[IncomeSource]
    expenses: list[Expense]
    assumptions: PlanAssumptions = Field(default_factory=PlanAssumptions)
    scenarios: list[ScenarioDefinition] = Field(default_factory=list)
    scenario_overrides: dict[str, ScenarioOverrides] = Field(default_factory=dict)
    one_time_events: list[OneTimeEvent] = Field(default_factory=list)
    recurring_expenses: list[RecurringExpense] = Field(default_factory=list)

    @field_validator("schema_version")
    @classmethod
    def validate_schema_version(cls, value: int) -> int:
        if value != 1:
            raise ValueError("Unsupported schema_version; expected 1")
        return value

    @model_validator(mode="after")
    def validate_references(self) -> Self:
        person_ids = {person.id for person in self.persons}
        person_ids.add("joint")
        for account in self.accounts:
            if account.owner_id not in person_ids:
                raise ValueError(f"account owner_id not found: {account.owner_id}")
        for source in self.income:
            if source.owner_id not in person_ids:
                raise ValueError(f"income owner_id not found: {source.owner_id}")
        for expense in self.expenses:
            if expense.household_id is None:
                expense.household_id = self.household.id
            if expense.start_date is None:
                expense.start_date = self.household.created_at
        scenario_ids = {scenario.id for scenario in self.scenarios}
        scenario_ids.add(self.base_scenario_id)
        for scenario_id in self.scenario_overrides:
            if scenario_id not in scenario_ids:
                raise ValueError(f"scenario_override id not found in scenarios: {scenario_id}")
        return self

    @property
    def base_scenario_id(self) -> str:
        for scenario in self.scenarios:
            if scenario.is_base_case:
                return scenario.id
        if self.scenarios:
            return self.scenarios[0].id
        return "base"


def build_household_model(raw_household: dict[str, object], persons: list[Person]) -> Household:
    person1 = persons[0]
    person2 = persons[1] if len(persons) > 1 else None
    created_raw = raw_household.get("created_at", "2000")
    updated_raw = raw_household.get("updated_at", created_raw)

    def _parse_year_date(value: object, *, field_name: str) -> date:
        if isinstance(value, int) and not isinstance(value, bool):
            return date(value, 1, 1)
        if isinstance(value, str) and YEAR_ONLY_PATTERN.match(value):
            return date(int(value), 1, 1)
        raise ValueError(f"{field_name} must be year-only (YYYY), got: {value!r}")

    created_at = _parse_year_date(created_raw, field_name="household.created_at")
    updated_at = _parse_year_date(updated_raw, field_name="household.updated_at")
    return Household(
        id=str(raw_household.get("id", "household-1")),
        name=str(raw_household["name"]),
        province=Province(str(raw_household["province"])),
        person1=person1,
        person2=person2,
        created_at=created_at,
        updated_at=updated_at,
    )
