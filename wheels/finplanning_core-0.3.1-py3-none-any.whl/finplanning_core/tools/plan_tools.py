"""Tool function implementations for LLM agent consumption.

Each function accepts a Pydantic input model and returns a plain dict
suitable for JSON serialization.  All plan data flows as YAML strings,
not file paths, so the tools are fully filesystem-agnostic.
"""

from __future__ import annotations

import re
from typing import Any

import yaml

from finplanning_core.loader.user_data import load_user_data_from_string
from finplanning_core.risk.monte_carlo import MonteCarloConfig
from finplanning_core.scenarios.manager import deep_merge
from finplanning_core.services.planning import PlanningService
from finplanning_core.tools.schemas import (
    AccountSummary,
    AddScenarioInput,
    AddScenarioOutput,
    AssumptionsSummary,
    CollectionModification,
    CompareInput,
    CompareOutput,
    CreatePlanVariantInput,
    CreatePlanVariantOutput,
    DeltaRow,
    ExpenseSummary,
    IncomeSummary,
    LoadPlanInput,
    LoadPlanOutput,
    MonteCarloInput,
    MonteCarloOutput,
    PersonSummary,
    ProjectionDetailInput,
    ProjectionDetailOutput,
    ProjectionMetrics,
    RunProjectionInput,
    RunProjectionOutput,
    ScenarioComparisonMetrics,
    ScenarioSummary,
    YearlySummaryRow,
    _round,
)

# ── helpers ───────────────────────────────────────────────────────

_MAX_YAML_SIZE = 1_000_000  # 1 MB guard against YAML bombs


def _check_yaml_size(plan_yaml: str) -> None:
    if len(plan_yaml) > _MAX_YAML_SIZE:
        raise ValueError(f"YAML input exceeds {_MAX_YAML_SIZE:,} byte limit ({len(plan_yaml):,} bytes)")


def _service_from_yaml(plan_yaml: str) -> PlanningService:
    _check_yaml_size(plan_yaml)
    return PlanningService.from_yaml_string(plan_yaml)


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower().strip()).strip("-")
    return slug or "scenario"


def _validate_yaml_string(yaml_content: str) -> list[str]:
    """Validate a YAML string by attempting to load it as a HouseholdPlan."""
    try:
        load_user_data_from_string(yaml_content)
    except Exception as exc:  # noqa: BLE001
        return [str(exc)]
    return []


# ── 1. load_plan ──────────────────────────────────────────────────


def load_plan(params: LoadPlanInput) -> dict[str, Any]:
    """Load a YAML plan and return a structured summary."""
    try:
        service = _service_from_yaml(params.plan_yaml)
        plan = service.plan

        persons = [
            PersonSummary(
                id=p.id,
                name=p.name,
                birth_year=p.birth_date.year,
                cpp_start_age=p.cpp_start_age,
                oas_start_age=p.oas_start_age,
            )
            for p in plan.persons
        ]

        accounts = [
            AccountSummary(
                id=a.id,
                owner_id=a.owner_id,
                name=a.name,
                account_type=a.account_type.value,
                balance=_round(a.balance),
            )
            for a in plan.accounts
        ]

        income = [
            IncomeSummary(
                id=i.id,
                owner_id=i.owner_id,
                name=i.name,
                income_type=i.income_type.value,
                annual_amount=_round(i.annual_amount),
                start_date=i.start_date.isoformat() if i.start_date else None,
                end_date=i.end_date.isoformat() if i.end_date else None,
            )
            for i in plan.income
        ]

        expenses = [
            ExpenseSummary(
                id=e.id,
                name=e.name,
                category=e.category.value,
                annual_amount=_round(e.annual_amount),
            )
            for e in plan.expenses
        ]

        scenarios = [ScenarioSummary(id=s.id, name=s.name, is_base_case=s.is_base_case) for s in plan.scenarios]

        assumptions = AssumptionsSummary(
            equity_return=_round(plan.assumptions.returns.equity_return),
            fixed_income_return=_round(plan.assumptions.returns.fixed_income_return),
            cash_return=_round(plan.assumptions.returns.cash_return),
            inflation=_round(plan.assumptions.inflation.general),
            withdrawal_order=plan.assumptions.withdrawal_order,
            has_glide_path=plan.assumptions.glide_path is not None,
            has_black_swan=plan.assumptions.black_swan is not None,
        )

        one_time = [
            {
                "id": e.id,
                "name": e.name,
                "type": e.event_type,
                "amount": _round(e.amount),
                "year": e.year,
            }
            for e in plan.one_time_events
        ]

        recurring = [
            {
                "id": r.id,
                "name": r.name,
                "amount": _round(r.amount),
                "start_year": r.start_year,
                "period_years": r.period_years,
                "end_year": r.end_year,
            }
            for r in plan.recurring_expenses
        ]

        output = LoadPlanOutput(
            household_name=plan.household.name,
            province=plan.household.province.value,
            persons=persons,
            accounts=accounts,
            total_portfolio_value=_round(sum((a.balance for a in plan.accounts), 0.0)),
            income=income,
            expenses=expenses,
            total_annual_expenses=_round(sum((e.annual_amount for e in plan.expenses), 0.0)),
            scenarios=scenarios,
            assumptions=assumptions,
            one_time_events=one_time,
            recurring_expenses=recurring,
        )
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return LoadPlanOutput(
            household_name="",
            province="",
            persons=[],
            accounts=[],
            total_portfolio_value=0.0,
            income=[],
            expenses=[],
            total_annual_expenses=0.0,
            scenarios=[],
            assumptions=AssumptionsSummary(
                equity_return=0,
                fixed_income_return=0,
                cash_return=0,
                inflation=0,
                withdrawal_order=[],
                has_glide_path=False,
                has_black_swan=False,
            ),
            one_time_events=[],
            recurring_expenses=[],
            error=str(exc),
        ).model_dump(mode="json")


# ── 2. run_projection ────────────────────────────────────────────


def run_projection(params: RunProjectionInput) -> dict[str, Any]:
    """Run a projection and return key metrics plus condensed yearly data."""
    try:
        service = _service_from_yaml(params.plan_yaml)
        result = service.run_projection(
            scenario_id=params.scenario_id,
            start_year=params.start_year,
            end_year=params.end_year,
        )

        metrics = ProjectionMetrics(
            scenario_id=result.scenario_id,
            final_net_worth=_round(result.final_net_worth),
            depletion_age=result.depletion_age,
            sustainable_spending=_round(result.sustainable_spending),
            desired_spending=_round(result.desired_spending),
            spending_gap=_round(result.spending_gap),
            warnings=result.warnings,
        )

        yearly = [
            YearlySummaryRow(
                year=yr.year,
                person1_age=yr.person1_age,
                person2_age=yr.person2_age,
                total_income=_round(yr.total_income),
                total_tax=_round(yr.total_tax),
                marginal_tax_rate=_round(yr.marginal_tax_rate),
                total_expenses=_round(yr.total_expenses),
                total_withdrawals=_round(yr.total_withdrawals),
                total_net_worth=_round(yr.total_net_worth),
                cash_flow_gap=_round(yr.cash_flow_gap),
            )
            for yr in result.years
        ]

        output = RunProjectionOutput(metrics=metrics, yearly_summary=yearly)
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return RunProjectionOutput(
            metrics=ProjectionMetrics(
                scenario_id="",
                final_net_worth=0,
                depletion_age=None,
                sustainable_spending=0,
                desired_spending=0,
                spending_gap=0,
                warnings=[],
            ),
            yearly_summary=[],
            error=str(exc),
        ).model_dump(mode="json")


# ── 3. compare_scenarios ─────────────────────────────────────────


def compare_scenarios(params: CompareInput) -> dict[str, Any]:
    """Compare scenarios side-by-side with delta analysis."""
    try:
        service = _service_from_yaml(params.plan_yaml)
        comparison = service.compare_scenarios(
            scenario_ids=params.scenario_ids,
            start_year=params.start_year,
            end_year=params.end_year,
        )

        metrics = [
            ScenarioComparisonMetrics(
                scenario_id=m.scenario_id,
                final_net_worth=_round(m.final_net_worth),
                depletion_age=m.depletion_age,
                sustainable_spending=_round(m.sustainable_spending),
            )
            for m in comparison.metrics
        ]

        base = metrics[0] if metrics else None
        deltas: list[DeltaRow] = []
        for m in metrics[1:]:
            dep_delta = None
            if base is not None and m.depletion_age is not None and base.depletion_age is not None:
                dep_delta = m.depletion_age - base.depletion_age
            deltas.append(
                DeltaRow(
                    scenario_id=m.scenario_id,
                    final_net_worth_delta=(round(m.final_net_worth - base.final_net_worth, 2) if base else 0.0),
                    sustainable_spending_delta=(
                        round(m.sustainable_spending - base.sustainable_spending, 2) if base else 0.0
                    ),
                    depletion_age_delta=dep_delta,
                )
            )

        output = CompareOutput(metrics=metrics, deltas=deltas)
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return CompareOutput(metrics=[], deltas=[], error=str(exc)).model_dump(mode="json")


# ── 4. add_scenario ──────────────────────────────────────────────


def add_scenario(params: AddScenarioInput) -> dict[str, Any]:
    """Add a scenario with overrides and return the updated YAML string."""
    try:
        _check_yaml_size(params.plan_yaml)
        raw: dict[str, Any] = yaml.safe_load(params.plan_yaml)
        if not isinstance(raw, dict):
            raise ValueError("YAML content must be a mapping at the top level")

        scenario_ids = {s["id"] for s in raw.get("scenarios", [])}

        # Generate slug id
        slug = _slugify(params.new_scenario_name)
        if slug in scenario_ids:
            for i in range(2, 100):
                candidate = f"{slug}-{i}"
                if candidate not in scenario_ids:
                    slug = candidate
                    break
            else:
                raise ValueError(f"Cannot generate unique scenario ID for '{params.new_scenario_name}'")

        # Add scenario definition
        raw.setdefault("scenarios", []).append(
            {
                "id": slug,
                "name": params.new_scenario_name,
                "is_base_case": False,
            }
        )

        # Build override payload from dot-path overrides
        if params.overrides:
            assumptions_overrides: dict[str, Any] = {}
            collection_overrides: dict[str, list[dict[str, Any]]] = {}

            for dot_path, value in params.overrides.items():
                parts = dot_path.split(".")
                if parts[0] == "assumptions" and len(parts) >= 2:
                    cursor: dict[str, Any] = assumptions_overrides
                    for part in parts[1:-1]:
                        cursor = cursor.setdefault(part, {})
                    cursor[parts[-1]] = value
                elif len(parts) >= 3:
                    collection_name = parts[0]
                    item_id = parts[1]
                    field_path = parts[2:]
                    items = collection_overrides.setdefault(collection_name, [])
                    item_entry: dict[str, Any] | None = None
                    for entry in items:
                        if entry.get("id") == item_id:
                            item_entry = entry
                            break
                    if item_entry is None:
                        item_entry = {"id": item_id}
                        items.append(item_entry)
                    cursor = item_entry
                    for part in field_path[:-1]:
                        cursor = cursor.setdefault(part, {})
                    cursor[field_path[-1]] = value

            override_payload: dict[str, Any] = {}
            if assumptions_overrides:
                override_payload["assumptions"] = assumptions_overrides
            for coll_name, items in collection_overrides.items():
                override_payload[coll_name] = items

            raw.setdefault("scenario_overrides", {})[slug] = override_payload

        updated_yaml = yaml.safe_dump(raw, sort_keys=False, allow_unicode=True)

        # Validate the result parses correctly
        warnings = _validate_yaml_string(updated_yaml)
        if warnings:
            raise ValueError(f"Validation errors: {'; '.join(warnings)}")

        output = AddScenarioOutput(
            updated_plan_yaml=updated_yaml,
            new_scenario_id=slug,
            overrides_applied=len(params.overrides),
        )
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return AddScenarioOutput(
            updated_plan_yaml="",
            new_scenario_id="",
            overrides_applied=0,
            error=str(exc),
        ).model_dump(mode="json")


# ── 5. create_plan_variant ───────────────────────────────────────


_COLLECTION_YAML_KEYS = ("accounts", "income", "expenses", "one_time_events", "recurring_expenses")


def create_plan_variant(params: CreatePlanVariantInput) -> dict[str, Any]:
    """Create a plan variant by applying structured modifications."""
    try:
        _check_yaml_size(params.plan_yaml)
        raw: dict[str, Any] = yaml.safe_load(params.plan_yaml)
        if not isinstance(raw, dict):
            raise ValueError("YAML content must be a mapping at the top level")

        changes: list[str] = []
        mods = params.modifications

        # 1. Deep-merge assumptions
        if mods.assumptions:
            raw["assumptions"] = deep_merge(raw.get("assumptions", {}), mods.assumptions)
            changes.append(f"Updated assumptions: {list(mods.assumptions.keys())}")

        # 2. Apply collection modifications
        for yaml_key in _COLLECTION_YAML_KEYS:
            coll_mod: CollectionModification = getattr(mods, yaml_key)
            items: list[dict[str, Any]] = list(raw.get(yaml_key, []))

            # Remove
            if coll_mod.remove:
                remove_set = set(coll_mod.remove)
                before_count = len(items)
                items = [item for item in items if item.get("id") not in remove_set]
                removed_count = before_count - len(items)
                if removed_count > 0:
                    changes.append(f"Removed {removed_count} {yaml_key}: {coll_mod.remove}")

            # Modify
            for mod_item in coll_mod.modify:
                item_id = mod_item.get("id")
                if not item_id:
                    continue
                found = False
                for existing in items:
                    if existing.get("id") == item_id:
                        for k, v in mod_item.items():
                            if k != "id":
                                existing[k] = v
                        changes.append(f"Modified {yaml_key}.{item_id}")
                        found = True
                        break
                if not found:
                    changes.append(f"Warning: {yaml_key}.{item_id} not found for modification")

            # Add
            for new_item in coll_mod.add:
                items.append(dict(new_item))
                changes.append(f"Added {yaml_key}: {new_item.get('id', '?')}")

            raw[yaml_key] = items

        # 3. Reset scenarios to a single base case
        raw["scenarios"] = [{"id": "base", "name": "Base Case", "is_base_case": True}]
        raw.pop("scenario_overrides", None)

        variant_yaml = yaml.safe_dump(raw, sort_keys=False, allow_unicode=True)

        # 4. Validate
        validation_warnings = _validate_yaml_string(variant_yaml)

        output = CreatePlanVariantOutput(
            variant_plan_yaml=variant_yaml,
            changes_summary=changes,
            validation_warnings=validation_warnings,
        )
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return CreatePlanVariantOutput(
            variant_plan_yaml="",
            changes_summary=[],
            validation_warnings=[],
            error=str(exc),
        ).model_dump(mode="json")


# ── 6. run_monte_carlo ───────────────────────────────────────────


def run_monte_carlo(params: MonteCarloInput) -> dict[str, Any]:
    """Run Monte Carlo simulation and return risk summary."""
    try:
        service = _service_from_yaml(params.plan_yaml)
        config = MonteCarloConfig(
            n_iterations=params.n_iterations,
            n_workers=1,
            sample_path_count=0,
        )

        result = service.run_monte_carlo(
            scenario_id=params.scenario_id,
            start_year=params.start_year,
            end_year=params.end_year,
            config=config,
        )

        dep_pct = float(result.depletion_probability) * 100
        p50 = _round(result.percentiles.get(50, 0.0))

        if dep_pct < 5:
            risk_level = "Very Low"
        elif dep_pct < 15:
            risk_level = "Low"
        elif dep_pct < 30:
            risk_level = "Moderate"
        elif dep_pct < 50:
            risk_level = "High"
        else:
            risk_level = "Very High"

        risk_summary = (
            f"{risk_level} risk: {dep_pct:.1f}% depletion probability over "
            f"{params.n_iterations} simulations. "
            f"Median final net worth: ${p50:,.0f}."
        )
        if result.median_depletion_age is not None:
            risk_summary += f" Median depletion age: {result.median_depletion_age}."

        percentiles_out = {f"p{k}": _round(v) for k, v in result.percentiles.items()}

        output = MonteCarloOutput(
            scenario_id=result.scenario_id,
            n_iterations=result.n_iterations,
            depletion_probability=round(float(result.depletion_probability), 4),
            percentiles=percentiles_out,
            median_depletion_age=result.median_depletion_age,
            risk_summary=risk_summary,
        )
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return MonteCarloOutput(
            scenario_id="",
            n_iterations=0,
            depletion_probability=0,
            percentiles={},
            median_depletion_age=None,
            risk_summary="",
            error=str(exc),
        ).model_dump(mode="json")


# ── 7. get_projection_detail ─────────────────────────────────────


def get_projection_detail(params: ProjectionDetailInput) -> dict[str, Any]:
    """Get full YearlyProjection data for specific years."""
    try:
        service = _service_from_yaml(params.plan_yaml)

        start = params.start_year or min(params.years)
        end = params.end_year or max(params.years)
        start = min(start, min(params.years))
        end = max(end, max(params.years))

        result = service.run_projection(
            scenario_id=params.scenario_id,
            start_year=start,
            end_year=end,
        )

        requested = set(params.years)
        year_details: list[dict[str, Any]] = []
        available_fields: list[str] = []

        for yr in result.years:
            if yr.year not in requested:
                continue
            row = yr.model_dump(mode="python")
            for key, val in list(row.items()):
                if isinstance(val, float):
                    row[key] = _round(val)
                elif isinstance(val, dict):
                    row[key] = {k: _round(v) if isinstance(v, float) else v for k, v in val.items()}

            if params.fields:
                allowed = set(params.fields)
                allowed.add("year")
                row = {k: v for k, v in row.items() if k in allowed}

            if not available_fields:
                available_fields = list(yr.model_dump(mode="python").keys())

            year_details.append(row)

        output = ProjectionDetailOutput(
            scenario_id=result.scenario_id,
            year_details=year_details,
            available_fields=available_fields,
        )
        return output.model_dump(mode="json")

    except Exception as exc:  # noqa: BLE001
        return ProjectionDetailOutput(
            scenario_id="",
            year_details=[],
            available_fields=[],
            error=str(exc),
        ).model_dump(mode="json")
