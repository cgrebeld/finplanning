"""Pydantic input/output models for LLM tool functions."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


def _round(value: float) -> float:
    """Round a float to 2dp for JSON serialization."""
    return round(value, 2)


# ── helpers for concise yearly summaries ──────────────────────────


class YearlySummaryRow(BaseModel):
    """Condensed yearly data suitable for LLM context windows."""

    year: int
    person1_age: int
    person2_age: int | None = None
    total_income: float
    total_tax: float
    marginal_tax_rate: float
    total_expenses: float
    total_withdrawals: float
    total_net_worth: float
    cash_flow_gap: float


# ── 1. load_plan ──────────────────────────────────────────────────


class LoadPlanInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")


class PersonSummary(BaseModel):
    id: str
    name: str
    birth_year: int
    cpp_start_age: int
    oas_start_age: int


class AccountSummary(BaseModel):
    id: str
    owner_id: str
    name: str
    account_type: str
    balance: float


class IncomeSummary(BaseModel):
    id: str
    owner_id: str
    name: str
    income_type: str
    annual_amount: float
    start_date: str | None = None
    end_date: str | None = None


class ExpenseSummary(BaseModel):
    id: str
    name: str
    category: str
    annual_amount: float


class ScenarioSummary(BaseModel):
    id: str
    name: str
    is_base_case: bool


class AssumptionsSummary(BaseModel):
    equity_return: float
    fixed_income_return: float
    cash_return: float
    inflation: float
    withdrawal_order: list[str]
    has_glide_path: bool
    has_black_swan: bool


class LoadPlanOutput(BaseModel):
    household_name: str
    province: str
    persons: list[PersonSummary]
    accounts: list[AccountSummary]
    total_portfolio_value: float
    income: list[IncomeSummary]
    expenses: list[ExpenseSummary]
    total_annual_expenses: float
    scenarios: list[ScenarioSummary]
    assumptions: AssumptionsSummary
    one_time_events: list[dict[str, Any]]
    recurring_expenses: list[dict[str, Any]]
    error: str | None = None


# ── 2. run_projection ────────────────────────────────────────────


class RunProjectionInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")
    scenario_id: str | None = Field(
        default=None,
        description="Scenario to project. Defaults to the base scenario.",
    )
    start_year: int | None = Field(
        default=None,
        description="Projection start year. Defaults to current year.",
    )
    end_year: int | None = Field(
        default=None,
        description="Projection end year. Defaults to youngest person's birth year + life expectancy.",
    )


class ProjectionMetrics(BaseModel):
    scenario_id: str
    final_net_worth: float
    depletion_age: int | None
    sustainable_spending: float
    desired_spending: float
    spending_gap: float
    warnings: list[str]


class RunProjectionOutput(BaseModel):
    metrics: ProjectionMetrics
    yearly_summary: list[YearlySummaryRow]
    error: str | None = None


# ── 3. compare_scenarios ─────────────────────────────────────────


class CompareInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")
    scenario_ids: list[str] | None = Field(
        default=None,
        description="Scenarios to compare. Defaults to all scenarios in the plan.",
    )
    start_year: int | None = Field(default=None, description="Start year.")
    end_year: int | None = Field(default=None, description="End year.")


class ScenarioComparisonMetrics(BaseModel):
    scenario_id: str
    final_net_worth: float
    depletion_age: int | None
    sustainable_spending: float


class DeltaRow(BaseModel):
    """Difference between a scenario and the base scenario."""

    scenario_id: str
    final_net_worth_delta: float
    sustainable_spending_delta: float
    depletion_age_delta: int | None = None


class CompareOutput(BaseModel):
    metrics: list[ScenarioComparisonMetrics]
    deltas: list[DeltaRow]
    error: str | None = None


# ── 4. add_scenario ──────────────────────────────────────────────


class AddScenarioInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")
    base_scenario_id: str = Field(
        description="Existing scenario to clone from.",
    )
    new_scenario_name: str = Field(
        description="Human-readable name for the new scenario.",
    )
    overrides: dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Dot-path overrides to apply. "
            "Example: {'assumptions.returns.equity_return': 0.05, "
            "'expenses.essential.annual_amount': 100000}"
        ),
    )


class AddScenarioOutput(BaseModel):
    updated_plan_yaml: str
    new_scenario_id: str
    overrides_applied: int
    error: str | None = None


# ── 5. create_plan_variant ───────────────────────────────────────


class CollectionModification(BaseModel):
    """Structured modification for a plan collection (accounts, income, etc.)."""

    add: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Items to add. Each must include a unique 'id' field.",
    )
    modify: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "Items to modify. Each must include 'id' matching an existing item, plus only the fields to change."
        ),
    )
    remove: list[str] = Field(
        default_factory=list,
        description="IDs of items to remove.",
    )


class PlanModifications(BaseModel):
    """Full modification spec for create_plan_variant."""

    accounts: CollectionModification = Field(default_factory=CollectionModification)
    income: CollectionModification = Field(default_factory=CollectionModification)
    expenses: CollectionModification = Field(default_factory=CollectionModification)
    one_time_events: CollectionModification = Field(default_factory=CollectionModification)
    recurring_expenses: CollectionModification = Field(default_factory=CollectionModification)
    assumptions: dict[str, Any] = Field(
        default_factory=dict,
        description=("Deep-merged into the existing assumptions. Example: {'returns': {'equity': 0.04}}"),
    )


class CreatePlanVariantInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the source plan.")
    modifications: PlanModifications = Field(
        description="Structured modifications to apply.",
    )


class CreatePlanVariantOutput(BaseModel):
    variant_plan_yaml: str
    changes_summary: list[str]
    validation_warnings: list[str]
    error: str | None = None


# ── 6. run_monte_carlo ───────────────────────────────────────────


class MonteCarloInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")
    scenario_id: str | None = Field(default=None, description="Scenario to simulate.")
    n_iterations: int = Field(
        default=1000,
        ge=100,
        le=10000,
        description="Number of Monte Carlo iterations.",
    )
    start_year: int | None = Field(default=None, description="Start year.")
    end_year: int | None = Field(default=None, description="End year.")


class MonteCarloOutput(BaseModel):
    scenario_id: str
    n_iterations: int
    depletion_probability: float
    percentiles: dict[str, float]
    median_depletion_age: int | None
    risk_summary: str
    error: str | None = None


# ── 7. get_projection_detail ─────────────────────────────────────


class ProjectionDetailInput(BaseModel):
    plan_yaml: str = Field(description="YAML content of the plan file.")
    scenario_id: str | None = Field(default=None, description="Scenario to project.")
    years: list[int] = Field(description="Specific years to retrieve detailed data for.")
    fields: list[str] | None = Field(
        default=None,
        description=("Optional filter: only return these fields per year. If omitted, all fields are returned."),
    )
    start_year: int | None = Field(default=None, description="Projection start year.")
    end_year: int | None = Field(default=None, description="Projection end year.")


class ProjectionDetailOutput(BaseModel):
    scenario_id: str
    year_details: list[dict[str, Any]]
    available_fields: list[str]
    error: str | None = None
