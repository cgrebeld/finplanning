from __future__ import annotations

from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.tax._impl.loader import TaxTables


def build_native_plan_payload(
    plan: HouseholdPlan,
    start_year: int,
    end_year: int,
    tax_tables_by_year: dict[int, TaxTables],
) -> dict[str, object]:
    years = list(range(start_year, end_year + 1))
    persons = list(plan.persons)
    accounts = list(plan.accounts)
    income = list(plan.income)
    expenses = list(plan.expenses)
    one_time_events = list(plan.one_time_events)
    recurring_expenses = list(plan.recurring_expenses)

    return {
        "schema_version": plan.schema_version,
        "years": years,
        "household": {
            "id": plan.household.id,
            "province": plan.household.province.value,
            "person1_id": plan.household.person1.id,
        },
        "persons": [
            {
                "id": person.id,
                "birth_year": person.birth_date.year,
                "life_expectancy_age": person.life_expectancy_age,
                "cpp_start_age": person.cpp_start_age,
                "oas_start_age": person.oas_start_age,
            }
            for person in persons
        ],
        "accounts": [
            {
                "id": account.id,
                "owner_id": account.owner_id,
                "account_type": account.account_type.value,
                "balance": account.balance,
                "cost_basis": account.cost_basis,
                "contribution_room": account.contribution_room,
                "is_locked": account.is_locked,
                "asset_mix": sorted(((asset_class.value, weight) for asset_class, weight in account.asset_mix.items())),
            }
            for account in accounts
        ],
        "income": [
            {
                "id": source.id,
                "owner_id": source.owner_id,
                "income_type": source.income_type.value,
                "annual_amount": source.annual_amount,
                "start_year": source.start_date.year if source.start_date is not None else None,
                "end_year": source.end_date.year if source.end_date is not None else None,
                "is_taxable": source.is_taxable,
                "is_eligible_for_splitting": source.is_eligible_for_splitting,
                "indexed": source.indexed,
            }
            for source in income
        ],
        "expenses": [
            {
                "id": expense.id,
                "category": expense.category.value,
                "annual_amount": expense.annual_amount,
                "start_year": expense.start_date.year if expense.start_date is not None else None,
                "end_year": expense.end_date.year if expense.end_date is not None else None,
            }
            for expense in expenses
        ],
        "one_time_events": [
            {
                "id": event.id,
                "event_type": event.event_type,
                "amount": event.amount,
                "year": event.year,
                "repeat_for_years": event.repeat_for_years,
            }
            for event in one_time_events
        ],
        "recurring_expenses": [
            {
                "id": expense.id,
                "amount": expense.amount,
                "start_year": expense.start_year,
                "period_years": expense.period_years,
                "end_year": expense.end_year,
            }
            for expense in recurring_expenses
        ],
        "assumptions": {
            "returns": plan.assumptions.returns.model_dump(mode="python"),
            "inflation": plan.assumptions.inflation.model_dump(mode="python"),
            "withdrawal_order": list(plan.assumptions.withdrawal_order),
            "investment_income_model": plan.assumptions.investment_income_model.model_dump(mode="python"),
            "contribution_limits": plan.assumptions.contribution_limits.model_dump(mode="python"),
            "tax_projection": plan.assumptions.tax_projection.model_dump(mode="python"),
            "glide_path": (
                plan.assumptions.glide_path.model_dump(mode="python")
                if plan.assumptions.glide_path is not None
                else None
            ),
        },
        "tax_tables_by_year": {
            str(year): {
                "federal": {
                    "brackets": [{"threshold": b.threshold, "rate": b.rate} for b in tables.federal.brackets],
                    "basic_personal_amount": tables.federal.basic_personal_amount,
                    "age_amount": tables.federal.age_amount,
                    "age_amount_threshold": tables.federal.age_amount_threshold,
                    "eligible_dividend_gross_up_rate": tables.federal.eligible_dividend_gross_up_rate,
                    "eligible_dividend_tax_credit_rate": tables.federal.eligible_dividend_tax_credit_rate,
                    "cpp": {
                        "max_pensionable_earnings": tables.federal.cpp.max_pensionable_earnings,
                        "basic_exemption": tables.federal.cpp.basic_exemption,
                        "contribution_rate": tables.federal.cpp.contribution_rate,
                        "max_benefit_at_65": tables.federal.cpp.max_benefit_at_65,
                        "early_reduction_per_year": tables.federal.cpp.early_reduction_per_year,
                        "deferral_increase_per_year": tables.federal.cpp.deferral_increase_per_year,
                    },
                    "oas": {
                        "max_benefit": tables.federal.oas.max_benefit,
                        "clawback_threshold": tables.federal.oas.clawback_threshold,
                        "full_clawback_threshold": tables.federal.oas.full_clawback_threshold,
                        "clawback_rate": tables.federal.oas.clawback_rate,
                        "deferral_increase_per_year": tables.federal.oas.deferral_increase_per_year,
                    },
                    "rrif": {
                        "conversion_age": tables.federal.rrif.conversion_age,
                        "prescribed_factors": tables.federal.rrif.prescribed_factors,
                    },
                    "tfsa_annual_limit": tables.federal.tfsa_annual_limit,
                },
                "provincial": {
                    "brackets": [{"threshold": b.threshold, "rate": b.rate} for b in tables.provincial.brackets],
                    "basic_personal_amount": tables.provincial.basic_personal_amount,
                    "eligible_dividend_tax_credit_rate": tables.provincial.eligible_dividend_tax_credit_rate,
                },
            }
            for year, tables in sorted(tax_tables_by_year.items())
        },
    }
