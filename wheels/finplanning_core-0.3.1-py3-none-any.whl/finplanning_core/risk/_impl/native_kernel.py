from __future__ import annotations

import importlib
from typing import Any

import numpy as np
from numpy.typing import NDArray

from finplanning_core.engine._impl.projection import ProjectionResult
from finplanning_core.models._impl.assumptions import ReturnAssumptions
from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.risk._impl.native_types import build_native_plan_payload
from finplanning_core.tax._impl.loader import TaxTables, load_tax_tables


def _load_native_module() -> Any:
    try:
        return importlib.import_module("finplanning_core_native")
    except ImportError as exc:  # pragma: no cover - exercised through fallback flow
        raise RuntimeError("finplanning_core_native module is not available") from exc


def run_native_batch(
    *,
    plan: HouseholdPlan,
    scenario_id: str,
    start_year: int,
    end_year: int,
    return_matrix: NDArray[np.float64],
    base_returns: ReturnAssumptions,
    n_iterations: int,
    sample_indices: set[int],
    fidelity: str,
    fixed_income_matrix: NDArray[np.float64] | None = None,
    cash_matrix: NDArray[np.float64] | None = None,
) -> tuple[list[float], list[int | None], list[tuple[int, ProjectionResult]], list[tuple[int, list[float]]]]:
    module = _load_native_module()
    tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
    province = plan.household.province.value
    tax_tables_by_year: dict[int, TaxTables] = {
        year: load_tax_tables(year, province, projection_assumptions=tax_projection)
        for year in range(start_year, end_year + 1)
    }
    plan_payload = build_native_plan_payload(plan, start_year, end_year, tax_tables_by_year)
    response = module.simulate_batch(
        {
            "plan": plan_payload,
            "scenario_id": scenario_id,
            "start_year": start_year,
            "end_year": end_year,
            "n_iterations": n_iterations,
            "sample_indices": sorted(sample_indices),
            "fidelity": fidelity,
            "return_matrix": return_matrix.tolist(),
            "fixed_income_matrix": fixed_income_matrix.tolist() if fixed_income_matrix is not None else None,
            "cash_matrix": cash_matrix.tolist() if cash_matrix is not None else None,
            "base_returns": base_returns.model_dump(mode="python"),
        }
    )

    final_net_worths = [float(value) for value in response["final_net_worths"]]
    depletion_ages = [None if value is None else int(value) for value in response["depletion_ages"]]
    yearly_net_worths = response.get("yearly_net_worths", [])
    indexed_rows: list[tuple[int, list[float]]] = [
        (idx, [float(v) for v in row]) for idx, row in enumerate(yearly_net_worths)
    ]
    indexed_paths: list[tuple[int, ProjectionResult]] = []
    return final_net_worths, depletion_ages, indexed_paths, indexed_rows
