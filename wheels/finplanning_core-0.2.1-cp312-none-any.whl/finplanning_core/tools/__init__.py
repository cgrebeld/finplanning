"""LLM tool layer for the financial planning engine.

Provides seven tool functions that accept and return YAML strings,
plus JSON Schema tool definitions for any LLM integration.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, ValidationError

from finplanning_core.tools.definitions import TOOL_DEFINITIONS
from finplanning_core.tools.plan_tools import (
    add_scenario,
    compare_scenarios,
    create_plan_variant,
    get_projection_detail,
    load_plan,
    run_monte_carlo,
    run_projection,
)
from finplanning_core.tools.schemas import (
    AddScenarioInput,
    CompareInput,
    CreatePlanVariantInput,
    LoadPlanInput,
    MonteCarloInput,
    ProjectionDetailInput,
    RunProjectionInput,
)

TOOL_DISPATCH: dict[str, tuple[Callable[..., dict[str, Any]], type[BaseModel]]] = {
    "load_plan": (load_plan, LoadPlanInput),
    "run_projection": (run_projection, RunProjectionInput),
    "compare_scenarios": (compare_scenarios, CompareInput),
    "add_scenario": (add_scenario, AddScenarioInput),
    "create_plan_variant": (create_plan_variant, CreatePlanVariantInput),
    "run_monte_carlo": (run_monte_carlo, MonteCarloInput),
    "get_projection_detail": (get_projection_detail, ProjectionDetailInput),
}


def dispatch_tool_call(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Parse arguments into the correct Pydantic model and call the tool function."""
    if name not in TOOL_DISPATCH:
        return {"error": f"Unknown tool: {name}"}
    func, model_cls = TOOL_DISPATCH[name]
    try:
        params = model_cls.model_validate(arguments)
    except ValidationError as exc:
        return {"error": f"Invalid arguments for {name}: {exc}"}
    result: dict[str, Any] = func(params)
    return result


__all__ = [
    "TOOL_DEFINITIONS",
    "TOOL_DISPATCH",
    "add_scenario",
    "compare_scenarios",
    "create_plan_variant",
    "dispatch_tool_call",
    "get_projection_detail",
    "load_plan",
    "run_monte_carlo",
    "run_projection",
]
