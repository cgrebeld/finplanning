from datetime import date
from enum import StrEnum

from pydantic import BaseModel, Field


class Province(StrEnum):
    BC = "BC"


class Person(BaseModel):
    """Individual within a household."""

    id: str
    name: str
    birth_date: date
    life_expectancy_age: int = Field(default=95, ge=1, le=130)
    cpp_start_age: int = Field(default=65, ge=60, le=70)
    oas_start_age: int = Field(default=65, ge=65, le=70)


class Household(BaseModel):
    """Planning unit metadata."""

    id: str
    name: str
    province: Province
    person1: Person
    person2: Person | None = None
    created_at: date
    updated_at: date
