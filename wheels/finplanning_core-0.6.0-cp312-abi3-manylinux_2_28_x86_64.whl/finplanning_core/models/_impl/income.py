from datetime import date
from enum import StrEnum
from typing import Self

from pydantic import BaseModel, Field, model_validator


class IncomeType(StrEnum):
    EMPLOYMENT = "EMPLOYMENT"
    SELF_EMPLOYMENT = "SELF_EMPLOYMENT"
    PENSION = "PENSION"
    CPP = "CPP"
    OAS = "OAS"
    RENTAL = "RENTAL"
    OTHER = "OTHER"


class IncomeSource(BaseModel):
    """Recurring income for a person."""

    id: str
    owner_id: str = Field(alias="person_id")
    income_type: IncomeType = Field(alias="type")
    name: str
    annual_amount: float = Field(ge=0)
    start_date: date | None = None
    start_age: int | None = Field(default=None, ge=0, le=120)
    end_date: date | None = None
    is_taxable: bool = True
    is_eligible_for_splitting: bool = False
    indexed: bool = True

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def _pension_defaults_not_indexed(cls, values: object) -> object:
        if not isinstance(values, dict):
            return values
        income_type = values.get("type") or values.get("income_type")
        if income_type == "PENSION" and "indexed" not in values:
            values["indexed"] = False
        return values

    @model_validator(mode="after")
    def validate_start_fields(self) -> Self:
        if self.start_date is None and self.start_age is None:
            raise ValueError("Exactly one of start_date or start_age must be provided")
        if self.start_date is not None and self.start_age is not None:
            raise ValueError("Exactly one of start_date or start_age must be provided")
        return self

    @model_validator(mode="after")
    def validate_splitting_eligibility(self) -> Self:
        if self.is_eligible_for_splitting and self.income_type is not IncomeType.PENSION:
            raise ValueError(f"is_eligible_for_splitting=True is only valid for PENSION income; got {self.income_type}")
        return self
