from datetime import date
from typing import Any

from pydantic import BaseModel, Field


class Scenario(BaseModel):
    """A complete projection configuration."""

    id: str
    household_id: str
    name: str
    description: str | None = None
    is_base_case: bool = False
    cloned_from_id: str | None = None
    created_at: date
    updated_at: date


class ScenarioOverrides(BaseModel):
    """Partial scenario edits applied over the base plan."""

    assumptions: dict[str, Any] = Field(default_factory=dict)
    accounts: list[dict[str, Any]] = Field(default_factory=list)
    income: list[dict[str, Any]] = Field(default_factory=list)
    expenses: list[dict[str, Any]] = Field(default_factory=list)
    one_time_events: list[dict[str, Any]] = Field(default_factory=list)
    recurring_expenses: list[dict[str, Any]] = Field(default_factory=list)
