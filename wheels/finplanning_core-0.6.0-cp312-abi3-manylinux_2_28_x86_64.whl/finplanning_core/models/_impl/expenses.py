from datetime import date
from enum import StrEnum

from pydantic import BaseModel, Field


class ExpenseCategory(StrEnum):
    ESSENTIAL = "ESSENTIAL"
    DISCRETIONARY = "DISCRETIONARY"
    HEALTHCARE = "HEALTHCARE"
    ONE_TIME = "ONE_TIME"


class Expense(BaseModel):
    """Recurring or one-time expense."""

    id: str
    household_id: str | None = None
    category: ExpenseCategory
    name: str
    annual_amount: float = Field(ge=0)
    start_date: date | None = None
    end_date: date | None = None
