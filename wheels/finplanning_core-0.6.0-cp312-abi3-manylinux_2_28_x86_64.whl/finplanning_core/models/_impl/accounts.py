from enum import StrEnum

from pydantic import BaseModel, Field, field_validator


class AccountType(StrEnum):
    RRSP = "RRSP"
    RRIF = "RRIF"
    TFSA = "TFSA"
    NON_REGISTERED = "NON_REGISTERED"
    LIRA = "LIRA"
    LIF = "LIF"


class AssetClass(StrEnum):
    EQUITY = "EQUITY"
    FIXED_INCOME = "FIXED_INCOME"
    CASH = "CASH"
    REAL_ESTATE = "REAL_ESTATE"


class Account(BaseModel):
    """Investment account belonging to a person or joint ownership."""

    id: str
    owner_id: str = Field(alias="person_id")
    name: str
    account_type: AccountType
    balance: float = Field(ge=0)
    cost_basis: float = Field(ge=0)
    contribution_room: float | None = Field(default=None, ge=0)
    asset_mix: dict[AssetClass, float]
    is_locked: bool = False

    model_config = {"populate_by_name": True}

    @field_validator("asset_mix")
    @classmethod
    def validate_asset_mix(cls, value: dict[AssetClass, float]) -> dict[AssetClass, float]:
        total = sum(value.values(), 0.0)
        tolerance = 0.001
        if abs(total - 1.0) > tolerance:
            raise ValueError("asset_mix values must sum to 1.0 (+/- 0.001)")
        return value
