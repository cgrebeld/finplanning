from typing import Self

from pydantic import BaseModel, Field, field_validator, model_validator


class ReturnAssumptions(BaseModel):
    """Expected returns by asset class."""

    equity_return: float = Field(default=0.06, alias="equity")
    fixed_income_return: float = Field(default=0.03, alias="fixed_income")
    cash_return: float = Field(default=0.02, alias="cash")
    real_estate_return: float = Field(default=0.03, alias="real_estate")

    model_config = {"populate_by_name": True}


class SpendingDeclineRate(BaseModel):
    early: float = Field(default=0.02)
    middle: float = Field(default=0.01)
    late: float = Field(default=0.015)


class InflationAssumptions(BaseModel):
    inflation: float | None = Field(default=None, exclude=True)
    healthcare_premium: float = Field(default=0.02)
    general: float = Field(default=0.02)
    income: float = Field(default=0.02)
    essential: float = Field(default=0.02)
    discretionary: float = Field(default=0.02)
    healthcare: float = Field(default=0.04)
    spending_decline: SpendingDeclineRate = Field(default_factory=SpendingDeclineRate)

    @model_validator(mode="after")
    def apply_scalar_inflation(self) -> Self:
        if self.inflation is not None:
            self.general = self.inflation
            self.income = self.inflation
            self.essential = self.inflation
            self.discretionary = self.inflation
            self.healthcare = self.inflation + self.healthcare_premium
        return self

    decline_applies_to: dict[str, float] = Field(
        default_factory=lambda: {
            "general": 1.0,
            "income": 0.0,
            "essential": 0.8,
            "discretionary": 1.5,
            "healthcare": 0.0,
        }
    )


class WithdrawalAssumptions(BaseModel):
    order: dict[str, int] = Field(
        default_factory=lambda: {
            "NON_REGISTERED": 1,
            "RRSP": 2,
            "RRIF": 2,
            "TFSA": 3,
        }
    )


class InvestmentIncomeAssumptions(BaseModel):
    equity_dividend_yield: float = Field(default=0.02, ge=0)
    fixed_income_distribution_yield: float = Field(default=0.035, ge=0)
    cash_interest_yield: float = Field(default=0.02, ge=0)
    capital_gains_inclusion_rate: float = Field(default=0.5, ge=0, le=1)


class GlidePath(BaseModel):
    equity_by_age: dict[int, float] = Field(
        default_factory=lambda: {
            55: 0.70,
            65: 0.60,
            75: 0.50,
            85: 0.40,
            95: 0.30,
        }
    )
    rebalance_tolerance_pct: float = Field(default=0.03, ge=0, le=1)


class BlackSwanAssumptions(BaseModel):
    """Stress-test scenario: sudden equity shock followed by flat returns."""

    equity_shock_pct: float = Field(default=-0.25)  # -0.25 = 25% drop
    flat_return_years: int = Field(default=3, ge=0)
    trigger_year: int

    @field_validator("equity_shock_pct")
    @classmethod
    def validate_equity_shock_pct(cls, value: float) -> float:
        if value > 0:
            raise ValueError("equity_shock_pct must be negative (e.g. -0.25 for a 25% drop)")
        if value < -1.0:
            raise ValueError("equity_shock_pct must be >= -1.0")
        return value


class ContributionLimitAssumptions(BaseModel):
    rrsp_dollar_limit: float = Field(default=32490.0, ge=0)
    rrsp_contribution_room_by_owner: dict[str, float] = Field(default_factory=dict)

    @field_validator("rrsp_contribution_room_by_owner")
    @classmethod
    def validate_rrsp_contribution_room_by_owner(cls, value: dict[str, float]) -> dict[str, float]:
        for owner_id, room in value.items():
            if room < 0:
                raise ValueError(f"RRSP contribution room must be non-negative for owner {owner_id}")
        return value


class TaxProjectionAssumptions(BaseModel):
    bracket_indexation: float = Field(default=0.02, ge=0)
    credit_indexation: float = Field(default=0.02, ge=0)
    cpp_indexation: float = Field(default=0.02, ge=0)
    oas_indexation: float = Field(default=0.02, ge=0)
    oas_threshold_indexation: float = Field(default=0.02, ge=0)
