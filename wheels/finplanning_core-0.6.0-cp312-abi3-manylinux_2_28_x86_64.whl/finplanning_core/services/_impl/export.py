import json
from datetime import date, datetime

import pandas as pd
import xlsxwriter

from finplanning_core.engine._impl.projection import ProjectionResult
from finplanning_core.models._impl.plan import HouseholdPlan


def round_values_for_json(value: object) -> object:
    if isinstance(value, float):
        return round(value, 2)
    if isinstance(value, date | datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: round_values_for_json(val) for key, val in value.items()}
    if isinstance(value, list):
        return [round_values_for_json(item) for item in value]
    return value


def projection_to_json(result: ProjectionResult) -> str:
    """Serialize a ProjectionResult to a JSON string with rounded values."""
    payload = round_values_for_json(result.model_dump(mode="python"))
    return json.dumps(payload, indent=2)


def projection_to_dataframe(result: ProjectionResult, plan: HouseholdPlan) -> pd.DataFrame:
    """Convert a ProjectionResult into a display-ready DataFrame.

    Columns: Year, person age(s), Income, Expenses, Tax, Net Income,
    Cash Flow, Withdrawals, Non-Reg, RRSP/RRIF, TFSA, Net Worth.
    """
    person1_name = plan.household.person1.name.split()[0]
    person2 = plan.household.person2
    person2_name = person2.name.split()[0] if person2 is not None else None

    rows: list[dict[str, object]] = []
    for yr in result.years:
        row: dict[str, object] = {
            "Year": yr.year,
            f"{person1_name} Age": yr.person1_age,
        }
        if person2_name is not None:
            row[f"{person2_name} Age"] = yr.person2_age
        row.update(
            {
                "Income": yr.total_income,
                "Portfolio Dividends": yr.portfolio_dividend_income,
                "Portfolio Interest": yr.portfolio_interest_income,
                "Realized Cap Gains": yr.realized_capital_gains,
                "Taxable Cap Gains": yr.taxable_capital_gains,
                "Expenses": yr.total_expenses,
                "Tax": yr.total_tax,
                "Net Income": yr.net_income,
                "Cash Flow": yr.cash_flow_gap,
                "Withdrawals": yr.total_withdrawals,
                "Non-Reg": yr.total_non_reg,
                "RRSP/RRIF": yr.total_rrsp_rrif,
                "TFSA": yr.total_tfsa,
                "Net Worth": yr.total_net_worth,
            }
        )
        rows.append(row)

    return pd.DataFrame(rows)


def rows_for_summary_output(result: ProjectionResult, plan: HouseholdPlan) -> list[dict[str, object]]:
    """Flatten ProjectionResult into summary dicts matching the UI year grid columns."""
    df = projection_to_dataframe(result, plan)
    return [dict(row) for _, row in df.iterrows()]


def rows_for_tabular_output(result: ProjectionResult, account_ids: list[str]) -> list[dict[str, object]]:
    """Flatten ProjectionResult into dicts suitable for XLSX/CSV export."""
    rows: list[dict[str, object]] = []
    for year in result.years:
        row = year.model_dump(mode="python")
        account_balances = row.pop("account_balances", {})
        account_returns = row.pop("account_returns", {})
        account_net_deposits = row.pop("account_net_deposits", {})
        for account_id in account_ids:
            row[f"{account_id}_balance"] = account_balances.get(account_id, 0.0)
            row[f"{account_id}_return"] = account_returns.get(account_id, 0.0)
            row[f"{account_id}_net_deposit"] = account_net_deposits.get(account_id, 0.0)
        rows.append(row)
    return rows


def header_labels_for_plan(
    field_names: list[str],
    plan: HouseholdPlan,
) -> tuple[dict[str, str], list[tuple[str, str]]]:
    """Build human-readable header labels and chart series from plan metadata.

    Returns (header_labels, balance_chart_series).
    """
    person1_name = plan.household.person1.name
    person2_name = plan.household.person2.name if plan.household.person2 is not None else "person2"
    header_labels = {
        field: field.replace("person1_", f"{person1_name} ").replace("person2_", f"{person2_name} ")
        for field in field_names
    }
    account_name_by_id = {account.id: account.name for account in plan.accounts}
    balance_series: list[tuple[str, str]] = []
    for account in plan.accounts:
        account_name = account_name_by_id.get(account.id, account.id)
        balance_field = f"{account.id}_balance"
        header_labels[balance_field] = f"{account_name} balance"
        header_labels[f"{account.id}_return"] = f"{account_name} return"
        header_labels[f"{account.id}_net_deposit"] = f"{account_name} net deposit"
        balance_series.append((balance_field, account_name))
    return header_labels, balance_series


def write_xlsx(
    rows: list[dict[str, object]],
    output_path: str,
    header_labels: dict[str, str] | None = None,
    chart_series: list[tuple[str, str]] | None = None,
    chart_x_field: str = "year",
    chart_x_label: str = "Year",
) -> None:
    """Write projection rows to an Excel workbook with a chart."""
    if not rows:
        raise ValueError("No yearly rows available to write.")

    fieldnames = list(rows[0].keys())
    header_labels = header_labels or {}
    workbook = xlsxwriter.Workbook(output_path)
    try:
        worksheet = workbook.add_worksheet("projection")
        header_format = workbook.add_format({"bold": True})
        money_format = workbook.add_format({"num_format": "#,##0.00"})
        int_format = workbook.add_format({"num_format": "0"})

        for col_index, field in enumerate(fieldnames):
            worksheet.write(0, col_index, header_labels.get(field, field), header_format)

        for row_index, row in enumerate(rows, start=1):
            for col_index, field in enumerate(fieldnames):
                value = row[field]
                if isinstance(value, float):
                    worksheet.write_number(row_index, col_index, round(value, 2), money_format)
                elif isinstance(value, int):
                    worksheet.write_number(row_index, col_index, value, int_format)
                elif value is None:
                    worksheet.write_blank(row_index, col_index, None)
                else:
                    worksheet.write(row_index, col_index, value)

        worksheet.freeze_panes(1, 0)
        worksheet.autofilter(0, 0, len(rows), len(fieldnames) - 1)
        worksheet.set_column(0, len(fieldnames) - 1, 16)

        x_col = fieldnames.index(chart_x_field)
        chart = workbook.add_chart({"type": "line"})
        if chart_series:
            for field, label in chart_series:
                if field not in fieldnames:
                    continue
                value_col = fieldnames.index(field)
                chart.add_series(
                    {
                        "name": label,
                        "categories": ["projection", 1, x_col, len(rows), x_col],
                        "values": ["projection", 1, value_col, len(rows), value_col],
                    }
                )
            chart.set_title({"name": "Account Balances Over Time"})
        else:
            balance_col = fieldnames.index("total_net_worth")
            chart.add_series(
                {
                    "name": "Balance",
                    "categories": ["projection", 1, x_col, len(rows), x_col],
                    "values": ["projection", 1, balance_col, len(rows), balance_col],
                }
            )
            chart.set_title({"name": "Balance Over Time"})
        chart.set_x_axis({"name": chart_x_label})
        chart.set_y_axis({"name": "Balance"})
        chart.set_legend({"none": not chart_series})
        worksheet.insert_chart(1, len(fieldnames) + 1, chart, {"x_scale": 1.6, "y_scale": 1.3})
    finally:
        workbook.close()
