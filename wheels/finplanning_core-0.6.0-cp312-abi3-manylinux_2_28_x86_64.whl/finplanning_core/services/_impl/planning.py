from collections.abc import Callable
from datetime import date
from pathlib import Path
from typing import Self

from finplanning_core.engine._impl.projection import ProjectionResult
from finplanning_core.loader._impl.user_data import load_user_data, load_user_data_from_string
from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.risk._impl.monte_carlo import MonteCarloConfig, MonteCarloEngine, MonteCarloResult
from finplanning_core.risk._impl.native_kernel import run_native_projection
from finplanning_core.scenarios._impl.comparison import ComparisonResult, ScenarioMetrics
from finplanning_core.scenarios._impl.manager import ScenarioManager
from finplanning_core.tax._impl.loader import TaxTables, load_tax_tables

NATIVE_SPENDING_RESERVE_YEARS = 8.0


class PlanningService:
    """Application-layer facade over the engine, loader, and scenario modules.

    This is the single entry point for all consumers (CLI, Streamlit UI,
    notebooks, tests).
    """

    def __init__(self, plan: HouseholdPlan) -> None:
        self._plan = plan
        self._manager = ScenarioManager(plan)

    @classmethod
    def from_yaml(cls, file_path: str | Path) -> Self:
        """Load a plan from a YAML file and return a ready-to-use service."""
        plan = load_user_data(str(file_path))
        return cls(plan)

    @classmethod
    def from_yaml_string(cls, yaml_content: str) -> Self:
        """Parse a YAML string and return a ready-to-use service."""
        plan = load_user_data_from_string(yaml_content)
        return cls(plan)

    @property
    def plan(self) -> HouseholdPlan:
        return self._plan

    @property
    def manager(self) -> ScenarioManager:
        return self._manager

    def run_projection(
        self,
        scenario_id: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> ProjectionResult:
        """Run a projection for a single scenario.

        Args:
            scenario_id: defaults to plan.base_scenario_id
            start_year: defaults to current year
            end_year: defaults to youngest person's birth year + max life expectancy
        """
        sid = scenario_id or self._plan.base_scenario_id
        plan = self._manager.get_plan(sid)
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)

        tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
        province = plan.household.province.value
        tax_tables_by_year: dict[int, TaxTables] = {
            year: load_tax_tables(year, province, projection_assumptions=tax_projection) for year in range(sy, ey + 1)
        }
        native_result = run_native_projection(
            plan=plan,
            scenario_id=sid,
            start_year=sy,
            end_year=ey,
            tax_tables_by_year=tax_tables_by_year,
        )

        desired_spending = native_result.years[0].total_expenses if native_result.years else 0.0
        spending_gap = self._find_native_spending_gap(
            plan=plan,
            scenario_id=sid,
            start_year=sy,
            end_year=ey,
            tax_tables_by_year=tax_tables_by_year,
            desired_spending=desired_spending,
        )
        native_result.desired_spending = desired_spending
        native_result.spending_gap = spending_gap
        native_result.sustainable_spending = desired_spending + spending_gap
        return native_result

    def _find_native_spending_gap(
        self,
        *,
        plan: HouseholdPlan,
        scenario_id: str,
        start_year: int,
        end_year: int,
        tax_tables_by_year: dict[int, TaxTables],
        desired_spending: float,
    ) -> float:
        lo = -500000.0
        hi = 500000.0
        tolerance = 100.0
        reserve_target = max(desired_spending * NATIVE_SPENDING_RESERVE_YEARS, 0.0)
        for _ in range(50):
            mid = (lo + hi) / 2
            result = run_native_projection(
                plan=plan,
                scenario_id=scenario_id,
                start_year=start_year,
                end_year=end_year,
                expense_delta=mid,
                tax_tables_by_year=tax_tables_by_year,
            )
            if result.depletion_age is not None or result.final_net_worth < reserve_target:
                hi = mid
            else:
                lo = mid
            if hi - lo < tolerance:
                break
        return round(lo)

    def compare_scenarios(
        self,
        scenario_ids: list[str] | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> ComparisonResult:
        """Run projections for multiple scenarios and return a comparison."""
        ids = scenario_ids or self._manager.scenario_ids
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)
        projections = {scenario_id: self.run_projection(scenario_id, sy, ey) for scenario_id in ids}
        metrics = [
            ScenarioMetrics(
                scenario_id=scenario_id,
                final_net_worth=result.final_net_worth,
                depletion_age=result.depletion_age,
                sustainable_spending=result.sustainable_spending,
            )
            for scenario_id, result in projections.items()
        ]
        return ComparisonResult(metrics=metrics, projections=projections)

    def run_monte_carlo(
        self,
        scenario_id: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
        config: MonteCarloConfig | None = None,
        progress_callback: Callable[[float], object] | None = None,
    ) -> MonteCarloResult:
        """Run a Monte Carlo simulation for a single scenario."""
        sid = scenario_id or self._plan.base_scenario_id
        plan = self._manager.get_plan(sid)
        mc_engine = MonteCarloEngine(plan)
        sy = start_year or _default_start_year()
        ey = end_year or _default_end_year(self._plan)
        return mc_engine.run_simulation(
            scenario_id=sid,
            start_year=sy,
            end_year=ey,
            config=config,
            progress_callback=progress_callback,
        )

    def clone_scenario(self, source_id: str, new_name: str) -> str:
        """Clone a scenario and return the new scenario ID."""
        scenario = self._manager.clone_scenario(source_id, new_name)
        return scenario.id

    def apply_override(self, scenario_id: str, path: str, value: object) -> None:
        """Apply a single leaf override to a scenario."""
        self._manager.apply_override(scenario_id, path, value)

    def remove_override(self, scenario_id: str, path: str) -> None:
        """Remove a single leaf override from a scenario."""
        self._manager.remove_override(scenario_id, path)


def _default_start_year() -> int:
    return date.today().year


def _default_end_year(plan: HouseholdPlan) -> int:
    max_age = max(p.life_expectancy_age for p in plan.persons)
    youngest_birth_year = max(p.birth_date.year for p in plan.persons)
    return youngest_birth_year + max_age
