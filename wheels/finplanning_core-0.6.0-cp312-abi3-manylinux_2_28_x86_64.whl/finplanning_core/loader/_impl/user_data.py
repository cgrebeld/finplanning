import re
from datetime import date
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from finplanning_core.models._impl.accounts import Account
from finplanning_core.models._impl.expenses import Expense
from finplanning_core.models._impl.household import Person
from finplanning_core.models._impl.income import IncomeSource
from finplanning_core.models._impl.plan import (
    HouseholdPlan,
    PlanAssumptions,
    ScenarioDefinition,
    build_household_model,
)

YEAR_ONLY_PATTERN = re.compile(r"^\d{4}$")

_TAX_PROJECTION_INDEXATION_FIELDS = (
    "bracket_indexation",
    "credit_indexation",
    "cpp_indexation",
    "oas_indexation",
    "oas_threshold_indexation",
)


def _preprocess_assumptions(raw_assumptions: dict[str, Any]) -> dict[str, Any]:
    """Expand scalar ``inflation`` into per-category and sibling models."""
    inflation_value = raw_assumptions.get("inflation")
    if inflation_value is None or isinstance(inflation_value, dict):
        return raw_assumptions

    result = dict(raw_assumptions)
    healthcare_premium = result.pop("healthcare_premium", 0.02)

    result["inflation"] = {
        "inflation": inflation_value,
        "healthcare_premium": healthcare_premium,
    }

    # Propagate to tax_projection fields not explicitly set
    tp = dict(result.get("tax_projection", {}) or {})
    for field in _TAX_PROJECTION_INDEXATION_FIELDS:
        if field not in tp:
            tp[field] = inflation_value
    result["tax_projection"] = tp

    return result


def _normalize_date_value(value: object, *, is_end: bool) -> date | None:
    """Normalize year-only date values to boundary ISO dates."""
    if value is None:
        return None
    if isinstance(value, int) and not isinstance(value, bool):
        return date(value, 12, 31) if is_end else date(value, 1, 1)
    if isinstance(value, str) and YEAR_ONLY_PATTERN.match(value):
        year = int(value)
        return date(year, 12, 31) if is_end else date(year, 1, 1)
    raise ValueError(f"Date value must be year-only (YYYY), got: {value!r}")


def _normalize_required_date_value(value: object, *, is_end: bool, field_name: str) -> date:
    normalized = _normalize_date_value(value, is_end=is_end)
    if normalized is None:
        raise ValueError(f"{field_name} is required")
    return normalized


def _parse_raw_plan(raw: dict[str, Any]) -> HouseholdPlan:
    """Parse a raw YAML dict into a validated HouseholdPlan."""
    persons = [
        Person(
            id=item["id"],
            name=item["name"],
            birth_date=_normalize_required_date_value(
                item["birth_date"],
                is_end=False,
                field_name=f"persons[{item['id']}].birth_date",
            ),
            life_expectancy_age=item.get("life_expectancy", 95),
            cpp_start_age=item.get("cpp_start_age", 65),
            oas_start_age=item.get("oas_start_age", 65),
        )
        for item in raw.get("persons", [])
    ]
    person_by_id = {person.id: person for person in persons}

    household = build_household_model(raw["household"], persons)

    accounts = [
        Account(
            id=item["id"],
            person_id=item["owner"],
            name=item["name"],
            account_type=item["type"],
            balance=item["balance"],
            cost_basis=item.get("cost_basis", 0),
            contribution_room=item.get("contribution_room"),
            asset_mix={key.upper(): value for key, value in item.get("asset_mix", {}).items()},
            is_locked=item.get("is_locked", False),
        )
        for item in raw.get("accounts", [])
    ]

    income: list[IncomeSource] = []
    for item in raw.get("income", []):
        if item.get("type") == "DIVIDEND":
            raise ValueError(
                "income.type DIVIDEND is not supported. "
                "Use assumptions.investment_income_model to estimate portfolio dividend income."
            )
        owner_id = item["owner"]
        start_date_raw = _normalize_date_value(item.get("start_date"), is_end=False)
        start_age_raw = item.get("start_age")
        end_date_raw = _normalize_date_value(item.get("end_date"), is_end=True)

        if start_date_raw is None and start_age_raw is not None:
            person = person_by_id.get(owner_id)
            if person is None:
                raise ValueError("start_age requires an income owner that references a person")
            turning_year = person.birth_date.year + int(start_age_raw)
            start_date_value: date | None = date(turning_year, 1, 1)
            start_age_value: int | None = None
        else:
            start_date_value = start_date_raw
            start_age_value = start_age_raw

        income_kwargs: dict[str, Any] = {
            "id": item["id"],
            "person_id": owner_id,
            "type": item["type"],
            "name": item["name"],
            "annual_amount": item["annual_amount"],
            "start_date": start_date_value,
            "start_age": start_age_value,
            "end_date": end_date_raw,
            "is_taxable": item.get("is_taxable", True),
            "is_eligible_for_splitting": item.get("is_eligible_for_splitting", False),
        }
        if "indexed" in item:
            income_kwargs["indexed"] = item["indexed"]
        income.append(IncomeSource(**income_kwargs))

    expenses = [
        Expense(
            id=item["id"],
            household_id=household.id,
            category=item["category"],
            name=item["name"],
            annual_amount=item["annual_amount"],
            start_date=_normalize_date_value(item.get("start_date"), is_end=False),
            end_date=_normalize_date_value(item.get("end_date"), is_end=True),
        )
        for item in raw.get("expenses", [])
    ]

    assumptions = PlanAssumptions.model_validate(_preprocess_assumptions(raw.get("assumptions", {})))
    scenarios = [ScenarioDefinition.model_validate(item) for item in raw.get("scenarios", [])]

    return HouseholdPlan(
        schema_version=raw.get("schema_version", 1),
        household=household,
        persons=persons,
        accounts=accounts,
        income=income,
        expenses=expenses,
        assumptions=assumptions,
        scenarios=scenarios,
        scenario_overrides=raw.get("scenario_overrides", {}),
        one_time_events=raw.get("one_time_events", []),
        recurring_expenses=raw.get("recurring_expenses", []),
    )


def load_user_data(file_path: str) -> HouseholdPlan:
    """Load complete household plan data from YAML file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")

    with path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)

    return _parse_raw_plan(raw)


def load_user_data_from_string(yaml_content: str) -> HouseholdPlan:
    """Parse a YAML string into a validated HouseholdPlan."""
    raw = yaml.safe_load(yaml_content)
    if not isinstance(raw, dict):
        raise ValueError("YAML content must be a mapping at the top level")
    return _parse_raw_plan(raw)


def validate_yaml_schema(file_path: str) -> list[str]:
    """Validate YAML by loading into models and returning any errors."""
    try:
        load_user_data(file_path)
    except FileNotFoundError as exc:
        return [str(exc)]
    except ValidationError as exc:
        messages: list[str] = []
        for error in exc.errors():
            loc = ".".join(str(part) for part in error.get("loc", ()))
            msg = str(error.get("msg", "validation error"))
            messages.append(f"{loc}: {msg}" if loc else msg)
        return messages
    except (KeyError, TypeError, ValueError, yaml.YAMLError) as exc:
        return [str(exc)]
    return []
