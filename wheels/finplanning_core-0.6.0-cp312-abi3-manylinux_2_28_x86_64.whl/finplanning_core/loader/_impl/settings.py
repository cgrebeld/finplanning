from pathlib import Path

import yaml
from pydantic import BaseModel, Field


class UiSettings(BaseModel):
    theme: str = "auto"
    chart_height: int = 400


class MonteCarloSettings(BaseModel):
    default_iterations: int = Field(default=1000, ge=1)


class LastSessionSettings(BaseModel):
    data_file: str = ""
    active_scenario: str = "base"


class Settings(BaseModel):
    ui: UiSettings = Field(default_factory=UiSettings)
    monte_carlo: MonteCarloSettings = Field(default_factory=MonteCarloSettings)
    last_session: LastSessionSettings = Field(default_factory=LastSessionSettings)


def load_settings(file_path: str) -> Settings:
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Settings file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    return Settings.model_validate(raw)


def save_settings(settings: Settings, file_path: str) -> None:
    path = Path(file_path)
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(settings.model_dump(mode="json"), handle, sort_keys=False)
