import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from finplanning_core.models._impl.accounts import Account
from finplanning_core.models._impl.expenses import Expense
from finplanning_core.models._impl.income import IncomeSource
from finplanning_core.models._impl.plan import HouseholdPlan, OneTimeEvent, PlanAssumptions, RecurringExpense
from finplanning_core.models._impl.scenarios import Scenario

MAX_SCENARIOS = 5
_COLLECTION_KEYS: dict[str, tuple[str, Any]] = {
    "accounts": ("accounts", Account),
    "income": ("income", IncomeSource),
    "expenses": ("expenses", Expense),
    "one_time_events": ("one_time_events", OneTimeEvent),
    "recurring_expenses": ("recurring_expenses", RecurringExpense),
}


@dataclass
class _ScenarioState:
    name: str
    parent_id: str | None
    overrides: dict[str, Any] = field(default_factory=dict)


def _slugify(name: str) -> str:
    """Convert a scenario name to a URL-friendly slug."""
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    slug = slug.strip("-")
    return slug or "scenario"


def _empty_overrides() -> dict[str, Any]:
    return {
        "assumptions": {},
        "accounts": [],
        "income": [],
        "expenses": [],
        "one_time_events": [],
        "recurring_expenses": [],
    }


def deep_merge(base: dict[str, Any], patch: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge *patch* into *base*, returning a new dict."""
    out = {key: value for key, value in base.items()}
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = value
    return out


# Keep private alias for backward compatibility within this module.
_deep_merge = deep_merge


def _set_nested(mapping: dict[str, Any], parts: list[str], value: Any) -> None:
    cursor = mapping
    for part in parts[:-1]:
        node = cursor.get(part)
        if not isinstance(node, dict):
            node = {}
            cursor[part] = node
        cursor = node
    cursor[parts[-1]] = value


def _remove_nested(mapping: dict[str, Any], parts: list[str]) -> None:
    cursor = mapping
    chain: list[tuple[dict[str, Any], str]] = []
    for part in parts[:-1]:
        node = cursor.get(part)
        if not isinstance(node, dict):
            return
        chain.append((cursor, part))
        cursor = node
    cursor.pop(parts[-1], None)
    for parent, key in reversed(chain):
        child = parent.get(key)
        if isinstance(child, dict) and not child:
            parent.pop(key, None)
        else:
            break


def _upsert_item_override(items: list[dict[str, Any]], item_id: str) -> dict[str, Any]:
    for item in items:
        if item.get("id") == item_id:
            return item
    created = {"id": item_id}
    items.append(created)
    return created


class ScenarioManager:
    """Manages scenario overrides (base + deltas) for a household plan."""

    def __init__(self, plan: HouseholdPlan) -> None:
        self._base_plan = plan.model_copy(deep=True)
        self._base_id = self._base_plan.base_scenario_id
        self._states: dict[str, _ScenarioState] = {}

        for scenario in self._base_plan.scenarios:
            self._states[scenario.id] = _ScenarioState(
                name=scenario.name,
                parent_id=None if scenario.is_base_case else self._base_id,
                overrides=_empty_overrides(),
            )
        if self._base_id not in self._states:
            self._states[self._base_id] = _ScenarioState(
                name=self._base_id, parent_id=None, overrides=_empty_overrides()
            )

        for scenario_id, payload in self._base_plan.scenario_overrides.items():
            if scenario_id not in self._states:
                continue
            self._states[scenario_id].overrides = _deep_merge(_empty_overrides(), payload.model_dump(mode="python"))

    def clone_scenario(self, source_id: str, new_name: str) -> Scenario:
        """Create a scenario shell that inherits from source and starts with no overrides."""
        if len(self._states) >= MAX_SCENARIOS:
            raise ValueError(f"Maximum {MAX_SCENARIOS} scenarios per household")
        if source_id not in self._states:
            raise ValueError(f"Source scenario not found: {source_id}")

        new_id = self._unique_id(new_name)
        self._states[new_id] = _ScenarioState(
            name=new_name,
            parent_id=source_id,
            overrides=_empty_overrides(),
        )

        today = date.today()
        return Scenario(
            id=new_id,
            household_id=self._base_plan.household.id,
            name=new_name,
            is_base_case=False,
            cloned_from_id=source_id,
            created_at=today,
            updated_at=today,
        )

    def apply_override(self, scenario_id: str, path: str, value: Any) -> None:
        """Apply a leaf override.

        Supported paths:
        - assumptions.<nested_field...>
        - expenses.<id>.<field...>
        - accounts.<id>.<field...>
        - income.<id>.<field...>
        - one_time_events.<id>.<field...>
        - recurring_expenses.<id>.<field...>
        """
        state = self._states.get(scenario_id)
        if state is None:
            raise ValueError(f"Scenario not found: {scenario_id}")

        parts = [part for part in path.split(".") if part]
        if len(parts) < 2:
            raise ValueError(f"Invalid override path: {path}")

        root = parts[0]
        if root == "assumptions":
            _set_nested(state.overrides["assumptions"], parts[1:], value)
            return

        collection = state.overrides.get(root)
        if not isinstance(collection, list) or len(parts) < 3:
            raise ValueError(f"Invalid override path: {path}")
        item = _upsert_item_override(collection, parts[1])
        _set_nested(item, parts[2:], value)

    def remove_override(self, scenario_id: str, path: str) -> None:
        """Remove a leaf override if present."""
        state = self._states.get(scenario_id)
        if state is None:
            raise ValueError(f"Scenario not found: {scenario_id}")

        parts = [part for part in path.split(".") if part]
        if len(parts) < 2:
            raise ValueError(f"Invalid override path: {path}")

        root = parts[0]
        if root == "assumptions":
            _remove_nested(state.overrides["assumptions"], parts[1:])
            return

        collection = state.overrides.get(root)
        if not isinstance(collection, list) or len(parts) < 3:
            raise ValueError(f"Invalid override path: {path}")
        item_id = parts[1]
        for item in collection:
            if item.get("id") == item_id:
                _remove_nested(item, parts[2:])
                if list(item.keys()) == ["id"]:
                    collection.remove(item)
                return

    def get_plan(self, scenario_id: str) -> HouseholdPlan:
        """Resolve and return the effective plan for a scenario (base + inherited overrides)."""
        if scenario_id not in self._states:
            raise ValueError(f"Scenario not found: {scenario_id}")

        effective = self._base_plan.model_copy(deep=True)
        for sid in self._inheritance_chain(scenario_id):
            overrides = self._states[sid].overrides
            self._apply_payload(effective, overrides)
        return effective

    def get_overrides(self, scenario_id: str) -> dict[str, Any]:
        """Return a copy of raw override payload for a scenario."""
        state = self._states.get(scenario_id)
        if state is None:
            raise ValueError(f"Scenario not found: {scenario_id}")
        return _deep_merge({}, state.overrides)

    @property
    def scenario_ids(self) -> list[str]:
        """List all registered scenario IDs."""
        return list(self._states.keys())

    @property
    def scenario_count(self) -> int:
        """Number of registered scenarios."""
        return len(self._states)

    def _apply_payload(self, plan: HouseholdPlan, payload: dict[str, Any]) -> None:
        assumptions_patch = payload.get("assumptions")
        if isinstance(assumptions_patch, dict) and assumptions_patch:
            merged = _deep_merge(plan.assumptions.model_dump(mode="python"), assumptions_patch)
            plan.assumptions = PlanAssumptions.model_validate(merged)

        for key, (attr, model_cls) in _COLLECTION_KEYS.items():
            entries = payload.get(key)
            if not isinstance(entries, list):
                continue
            current = getattr(plan, attr)
            current_by_id = {item.id: idx for idx, item in enumerate(current)}
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                item_id = entry.get("id")
                if not isinstance(item_id, str):
                    continue
                idx = current_by_id.get(item_id)
                if idx is None:
                    raise ValueError(f"Override target not found: {key}.{item_id}")
                base_data = current[idx].model_dump(mode="python")
                patch = {k: v for k, v in entry.items() if k != "id"}
                merged = _deep_merge(base_data, patch)
                current[idx] = model_cls.model_validate(merged)

    def _inheritance_chain(self, scenario_id: str) -> list[str]:
        chain: list[str] = []
        current: str | None = scenario_id
        while current is not None:
            chain.append(current)
            current = self._states[current].parent_id
        chain.reverse()
        return chain

    def _unique_id(self, name: str) -> str:
        """Generate a unique scenario ID from the name."""
        base = _slugify(name)
        if base not in self._states:
            return base
        for i in range(2, MAX_SCENARIOS + 2):
            candidate = f"{base}-{i}"
            if candidate not in self._states:
                return candidate
        raise ValueError(f"Cannot generate unique ID for scenario: {name}")
