from pydantic import BaseModel

from finplanning_core.engine._impl.projection import ProjectionResult
from finplanning_core.risk._impl.native_kernel import run_native_projection
from finplanning_core.scenarios._impl.manager import ScenarioManager
from finplanning_core.tax._impl.loader import TaxTables, load_tax_tables


class ScenarioMetrics(BaseModel):
    """Key metrics extracted from a single scenario projection."""

    scenario_id: str
    final_net_worth: float
    depletion_age: int | None
    sustainable_spending: float


class ComparisonResult(BaseModel):
    """Side-by-side metrics for multiple scenarios."""

    metrics: list[ScenarioMetrics]
    projections: dict[str, ProjectionResult]


def compare_scenarios(
    manager: ScenarioManager,
    scenario_ids: list[str],
    start_year: int,
    end_year: int,
) -> ComparisonResult:
    """Run projections for each scenario and return structured comparison."""
    metrics: list[ScenarioMetrics] = []
    projections: dict[str, ProjectionResult] = {}

    for scenario_id in scenario_ids:
        plan = manager.get_plan(scenario_id)
        tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
        province = plan.household.province.value
        tax_tables_by_year: dict[int, TaxTables] = {
            year: load_tax_tables(year, province, projection_assumptions=tax_projection)
            for year in range(start_year, end_year + 1)
        }
        result = run_native_projection(
            plan=plan,
            scenario_id=scenario_id,
            start_year=start_year,
            end_year=end_year,
            tax_tables_by_year=tax_tables_by_year,
        )
        projections[scenario_id] = result
        metrics.append(
            ScenarioMetrics(
                scenario_id=scenario_id,
                final_net_worth=result.final_net_worth,
                depletion_age=result.depletion_age,
                sustainable_spending=result.sustainable_spending,
            )
        )

    return ComparisonResult(metrics=metrics, projections=projections)
