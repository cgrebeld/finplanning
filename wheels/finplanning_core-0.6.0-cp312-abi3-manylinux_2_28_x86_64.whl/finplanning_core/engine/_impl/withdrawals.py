from collections import defaultdict

from finplanning_core.engine._impl.projection import Withdrawal
from finplanning_core.models._impl.accounts import Account, AccountType


def apply_waterfall(
    accounts: list[Account],
    amount_needed: float,
    order_config: dict[str, int],
    capital_gains_inclusion_rate: float = 0.5,
) -> list[Withdrawal]:
    """Withdraw from accounts grouped by type-priority tier, splitting evenly within each tier."""
    if amount_needed <= 0:
        return []

    # Force TFSA to lowest priority (last to withdraw)
    tfsa_priority = max(order_config.values(), default=0) + 1

    def account_priority(account: Account) -> int:
        p = order_config.get(account.account_type, 999)
        if account.account_type is AccountType.TFSA:
            p = max(p, tfsa_priority)
        return p

    # Group accounts by tier
    tiers: dict[int, list[Account]] = defaultdict(list)
    for account in accounts:
        tiers[account_priority(account)].append(account)

    remaining = amount_needed
    withdrawals: dict[str, Withdrawal] = {}

    for _priority in sorted(tiers):
        if remaining <= 0:
            break
        remaining = _withdraw_from_tier(
            tiers[_priority],
            remaining,
            withdrawals,
            capital_gains_inclusion_rate=capital_gains_inclusion_rate,
        )

    return list(withdrawals.values())


def _withdraw_from_tier(
    accounts: list[Account],
    amount: float,
    withdrawals: dict[str, Withdrawal],
    capital_gains_inclusion_rate: float,
) -> float:
    """Split *amount* evenly across accounts in a single tier. Returns the unsatisfied remainder."""
    eligible = [a for a in accounts if a.balance > 0]
    remaining = amount

    while remaining > 0 and eligible:
        share = remaining / len(eligible)
        still_eligible: list[Account] = []

        for account in eligible:
            if remaining <= 0:
                break
            opening_balance = account.balance
            withdrawn = min(share, account.balance, remaining)
            account.balance -= withdrawn
            remaining -= withdrawn

            realized_capital_gains = 0.0
            taxable_capital_gains = 0.0
            if account.account_type is AccountType.NON_REGISTERED and opening_balance > 0 and withdrawn > 0:
                acb_ratio = account.cost_basis / opening_balance
                acb_reduction = min(account.cost_basis, withdrawn * acb_ratio)
                account.cost_basis -= acb_reduction

                raw_gain = withdrawn - acb_reduction
                realized_capital_gains = raw_gain
                taxable_capital_gains = raw_gain * capital_gains_inclusion_rate

            if account.id in withdrawals:
                withdrawals[account.id] = Withdrawal(
                    account_id=account.id,
                    account_type=account.account_type,
                    amount_withdrawn=withdrawals[account.id].amount_withdrawn + withdrawn,
                    realized_capital_gains=withdrawals[account.id].realized_capital_gains + realized_capital_gains,
                    taxable_capital_gains=withdrawals[account.id].taxable_capital_gains + taxable_capital_gains,
                )
            else:
                withdrawals[account.id] = Withdrawal(
                    account_id=account.id,
                    account_type=account.account_type,
                    amount_withdrawn=withdrawn,
                    realized_capital_gains=realized_capital_gains,
                    taxable_capital_gains=taxable_capital_gains,
                )

            if account.balance > 0:
                still_eligible.append(account)

        if len(still_eligible) == len(eligible):
            # No account was capped — we're done with this tier
            break
        eligible = still_eligible

    return remaining
