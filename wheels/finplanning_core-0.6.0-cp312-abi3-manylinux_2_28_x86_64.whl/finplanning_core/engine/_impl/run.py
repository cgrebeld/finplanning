import argparse

from finplanning_core.services._impl.export import (
    header_labels_for_plan,
    projection_to_json,
    rows_for_tabular_output,
    write_xlsx,
)
from finplanning_core.services._impl.planning import PlanningService


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a cash-flow projection from a YAML plan file.")
    parser.add_argument("plan_path", help="Path to a plan YAML file")
    parser.add_argument("start_year", type=int, help="Projection start year")
    parser.add_argument("end_year", type=int, help="Projection end year")
    parser.add_argument(
        "--scenario-id",
        default=None,
        help="Scenario id to run (defaults to plan base scenario)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print full projection result as JSON",
    )
    parser.add_argument(
        "--xlsx",
        metavar="PATH",
        default=None,
        help="Write yearly projection rows and balance chart to an Excel workbook",
    )
    args = parser.parse_args()

    service = PlanningService.from_yaml(args.plan_path)
    result = service.run_projection(
        scenario_id=args.scenario_id,
        start_year=args.start_year,
        end_year=args.end_year,
    )

    selected_formats = int(args.json) + int(args.xlsx is not None)
    if selected_formats > 1:
        parser.error("Use only one of --json or --xlsx.")

    if args.json:
        print(projection_to_json(result))
        return

    if args.xlsx is not None:
        account_ids = [account.id for account in service.plan.accounts]
        rows = rows_for_tabular_output(result, account_ids)
        if not rows:
            parser.error("No yearly rows available to write.")
        field_names = list(rows[0].keys())
        labels, balance_series = header_labels_for_plan(field_names, service.plan)
        person1_name = service.plan.household.person1.name
        write_xlsx(
            rows,
            args.xlsx,
            header_labels=labels,
            chart_series=balance_series,
            chart_x_field="person1_age",
            chart_x_label=f"{person1_name} Age",
        )
        print(f"Wrote Excel workbook to {args.xlsx}")
        return

    print(f"Scenario: {result.scenario_id}")
    print(f"Years projected: {len(result.years)}")
    print(f"Final net worth: {result.final_net_worth}")
    print(f"Depletion age: {result.depletion_age}")
    if result.years:
        print(f"First year ({result.years[0].year}) net worth: {result.years[0].total_net_worth}")
        print(f"Last year ({result.years[-1].year}) net worth: {result.years[-1].total_net_worth}")


if __name__ == "__main__":
    main()
