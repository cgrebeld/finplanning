from dataclasses import dataclass
from pathlib import Path

import yaml

from finplanning_core.data import tax_data_dir


@dataclass(frozen=True, slots=True)
class TaxBracket:
    threshold: float
    rate: float


@dataclass(frozen=True, slots=True)
class CppParameters:
    max_pensionable_earnings: float
    basic_exemption: float
    contribution_rate: float
    max_benefit_at_65: float
    early_reduction_per_year: float
    deferral_increase_per_year: float


@dataclass(frozen=True, slots=True)
class OasParameters:
    max_benefit: float
    clawback_threshold: float
    full_clawback_threshold: float
    clawback_rate: float
    deferral_increase_per_year: float


@dataclass(frozen=True, slots=True)
class RrifParameters:
    conversion_age: int
    prescribed_factors: dict[int, float]


@dataclass(frozen=True, slots=True)
class FederalTaxTable:
    tax_year: int
    jurisdiction: str
    brackets: list[TaxBracket]
    basic_personal_amount: float
    age_amount: float
    age_amount_threshold: float
    eligible_dividend_gross_up_rate: float
    eligible_dividend_tax_credit_rate: float
    cpp: CppParameters
    oas: OasParameters
    rrif: RrifParameters
    tfsa_annual_limit: float


@dataclass(frozen=True, slots=True)
class ProvincialTaxTable:
    tax_year: int
    jurisdiction: str
    brackets: list[TaxBracket]
    basic_personal_amount: float
    eligible_dividend_tax_credit_rate: float


@dataclass(frozen=True, slots=True)
class TaxTables:
    federal: FederalTaxTable
    provincial: ProvincialTaxTable


@dataclass(frozen=True, slots=True)
class TaxProjectionSettings:
    bracket_indexation: float = 0.02
    credit_indexation: float = 0.02
    cpp_indexation: float = 0.02
    oas_indexation: float = 0.02
    oas_threshold_indexation: float = 0.02


def _to_float(value: object) -> float:
    return float(str(value))


def _to_int(value: object) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        return int(value)
    raise ValueError(f"Invalid integer value in tax table: {value!r}")


def _projection_settings(value: dict[str, object] | None) -> TaxProjectionSettings:
    if value is None:
        return TaxProjectionSettings()
    return TaxProjectionSettings(
        bracket_indexation=_to_float(value.get("bracket_indexation", 0.02)),
        credit_indexation=_to_float(value.get("credit_indexation", 0.02)),
        cpp_indexation=_to_float(value.get("cpp_indexation", 0.02)),
        oas_indexation=_to_float(value.get("oas_indexation", 0.02)),
        oas_threshold_indexation=_to_float(value.get("oas_threshold_indexation", 0.02)),
    )


def _parse_brackets(raw: object) -> list[TaxBracket]:
    if not isinstance(raw, list):
        raise ValueError("Invalid tax table: brackets must be a list.")
    brackets: list[TaxBracket] = []
    for entry in raw:
        if not isinstance(entry, dict):
            raise ValueError("Invalid tax table: each bracket must be a mapping.")
        brackets.append(
            TaxBracket(
                threshold=_to_float(entry["threshold"]),
                rate=_to_float(entry["rate"]),
            )
        )
    return brackets


def _load_yaml(path: Path) -> dict[str, object]:
    if not path.exists():
        raise FileNotFoundError(f"Tax data file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle) or {}
    if not isinstance(loaded, dict):
        raise ValueError(f"Invalid tax data file: expected mapping at root in {path}")
    return loaded


def _round_to_unit(value: float) -> float:
    return round(value)


def _round_to_500(value: float) -> float:
    return round(value / 500) * 500


def _project_value(base: float, years: int, rate: float) -> float:
    projected = base * ((1.0 + rate) ** years)
    return _round_to_unit(projected)


def _parse_rrif_params(raw: object) -> RrifParameters:
    if not isinstance(raw, dict):
        raise ValueError("Invalid federal tax table: rrif must be a mapping.")
    factors_raw = raw.get("prescribed_factors", {})
    if not isinstance(factors_raw, dict):
        raise ValueError("Invalid federal tax table: rrif.prescribed_factors must be a mapping.")
    prescribed_factors = {_to_int(age): _to_float(rate) for age, rate in factors_raw.items()}
    return RrifParameters(
        conversion_age=_to_int(raw["conversion_age"]),
        prescribed_factors=prescribed_factors,
    )


def _parse_federal_table(raw: dict[str, object]) -> FederalTaxTable:
    federal_cpp = raw["cpp"]
    if not isinstance(federal_cpp, dict):
        raise ValueError("Invalid federal tax table: cpp must be a mapping.")
    federal_oas = raw["oas"]
    if not isinstance(federal_oas, dict):
        raise ValueError("Invalid federal tax table: oas must be a mapping.")
    raw_rrif = raw.get("rrif")
    if raw_rrif is not None:
        rrif = _parse_rrif_params(raw_rrif)
    else:
        rrif = RrifParameters(conversion_age=71, prescribed_factors={})

    return FederalTaxTable(
        tax_year=_to_int(raw["tax_year"]),
        jurisdiction=str(raw["jurisdiction"]),
        brackets=_parse_brackets(raw["brackets"]),
        basic_personal_amount=_to_float(raw["basic_personal_amount"]),
        age_amount=_to_float(raw["age_amount"]),
        age_amount_threshold=_to_float(raw["age_amount_threshold"]),
        eligible_dividend_gross_up_rate=_to_float(raw.get("eligible_dividend_gross_up_rate", "0.38")),
        eligible_dividend_tax_credit_rate=_to_float(raw.get("eligible_dividend_tax_credit_rate", "0.150198")),
        cpp=CppParameters(
            max_pensionable_earnings=_to_float(federal_cpp["max_pensionable_earnings"]),
            basic_exemption=_to_float(federal_cpp["basic_exemption"]),
            contribution_rate=_to_float(federal_cpp["contribution_rate"]),
            max_benefit_at_65=_to_float(federal_cpp["max_benefit_at_65"]),
            early_reduction_per_year=_to_float(federal_cpp["early_reduction_per_year"]),
            deferral_increase_per_year=_to_float(federal_cpp["deferral_increase_per_year"]),
        ),
        oas=OasParameters(
            max_benefit=_to_float(federal_oas["max_benefit"]),
            clawback_threshold=_to_float(federal_oas["clawback_threshold"]),
            full_clawback_threshold=_to_float(federal_oas["full_clawback_threshold"]),
            clawback_rate=_to_float(federal_oas["clawback_rate"]),
            deferral_increase_per_year=_to_float(federal_oas["deferral_increase_per_year"]),
        ),
        rrif=rrif,
        tfsa_annual_limit=_to_float(raw.get("tfsa_annual_limit", "7000")),
    )


def _parse_provincial_table(raw: dict[str, object]) -> ProvincialTaxTable:
    return ProvincialTaxTable(
        tax_year=_to_int(raw["tax_year"]),
        jurisdiction=str(raw["jurisdiction"]),
        brackets=_parse_brackets(raw["brackets"]),
        basic_personal_amount=_to_float(raw["basic_personal_amount"]),
        eligible_dividend_tax_credit_rate=_to_float(raw.get("eligible_dividend_tax_credit_rate", "0.12")),
    )


def _project_federal_table(
    base: FederalTaxTable,
    target_year: int,
    settings: TaxProjectionSettings,
) -> FederalTaxTable:
    years = target_year - base.tax_year
    projected_brackets: list[TaxBracket] = []
    for index, bracket in enumerate(base.brackets):
        if index == 0:
            projected_brackets.append(bracket)
            continue
        projected_brackets.append(
            TaxBracket(
                threshold=_project_value(bracket.threshold, years, settings.bracket_indexation),
                rate=bracket.rate,
            )
        )

    return FederalTaxTable(
        tax_year=target_year,
        jurisdiction=base.jurisdiction,
        brackets=projected_brackets,
        basic_personal_amount=_project_value(
            base.basic_personal_amount,
            years,
            settings.credit_indexation,
        ),
        age_amount=_project_value(base.age_amount, years, settings.credit_indexation),
        age_amount_threshold=_project_value(
            base.age_amount_threshold,
            years,
            settings.credit_indexation,
        ),
        eligible_dividend_gross_up_rate=base.eligible_dividend_gross_up_rate,
        eligible_dividend_tax_credit_rate=base.eligible_dividend_tax_credit_rate,
        cpp=CppParameters(
            max_pensionable_earnings=_project_value(
                base.cpp.max_pensionable_earnings,
                years,
                settings.cpp_indexation,
            ),
            basic_exemption=_project_value(
                base.cpp.basic_exemption,
                years,
                settings.cpp_indexation,
            ),
            contribution_rate=base.cpp.contribution_rate,
            max_benefit_at_65=_project_value(
                base.cpp.max_benefit_at_65,
                years,
                settings.cpp_indexation,
            ),
            early_reduction_per_year=base.cpp.early_reduction_per_year,
            deferral_increase_per_year=base.cpp.deferral_increase_per_year,
        ),
        oas=OasParameters(
            max_benefit=_project_value(base.oas.max_benefit, years, settings.oas_indexation),
            clawback_threshold=_project_value(
                base.oas.clawback_threshold,
                years,
                settings.oas_threshold_indexation,
            ),
            full_clawback_threshold=_project_value(
                base.oas.full_clawback_threshold,
                years,
                settings.oas_threshold_indexation,
            ),
            clawback_rate=base.oas.clawback_rate,
            deferral_increase_per_year=base.oas.deferral_increase_per_year,
        ),
        rrif=base.rrif,
        tfsa_annual_limit=_round_to_500(base.tfsa_annual_limit * ((1.0 + settings.bracket_indexation) ** years)),
    )


def _project_provincial_table(
    base: ProvincialTaxTable,
    target_year: int,
    settings: TaxProjectionSettings,
) -> ProvincialTaxTable:
    years = target_year - base.tax_year
    projected_brackets: list[TaxBracket] = []
    for index, bracket in enumerate(base.brackets):
        if index == 0:
            projected_brackets.append(bracket)
            continue
        projected_brackets.append(
            TaxBracket(
                threshold=_project_value(bracket.threshold, years, settings.bracket_indexation),
                rate=bracket.rate,
            )
        )
    return ProvincialTaxTable(
        tax_year=target_year,
        jurisdiction=base.jurisdiction,
        brackets=projected_brackets,
        basic_personal_amount=_project_value(
            base.basic_personal_amount,
            years,
            settings.credit_indexation,
        ),
        eligible_dividend_tax_credit_rate=base.eligible_dividend_tax_credit_rate,
    )


def _latest_available_year(data_dir: str, suffix: str, max_year: int) -> int | None:
    directory = Path(data_dir)
    if not directory.exists():
        return None
    found: list[int] = []
    for path in directory.glob(f"*_{suffix}.yaml"):
        stem = path.stem
        year_text = stem.removesuffix(f"_{suffix}")
        try:
            year = int(year_text)
        except ValueError:
            continue
        if year <= max_year:
            found.append(year)
    return max(found) if found else None


def _dict_to_hashable(d: dict[str, object] | None) -> tuple[tuple[str, object], ...] | None:
    if d is None:
        return None
    return tuple(sorted(d.items()))


# Cache keyed on (tax_year, province, data_dir, hashable_assumptions).
# The actual dict is reconstructed inside from the hashable key.
_tax_table_cache: dict[tuple[int, str, str, tuple[tuple[str, object], ...] | None], TaxTables] = {}


def load_tax_tables(
    tax_year: int,
    province: str,
    *,
    data_dir: str = "",
    projection_assumptions: dict[str, object] | None = None,
) -> TaxTables:
    if not data_dir:
        data_dir = tax_data_dir()
    hashable_key = (tax_year, province.upper(), data_dir, _dict_to_hashable(projection_assumptions))
    cached = _tax_table_cache.get(hashable_key)
    if cached is not None:
        return cached
    result = _load_tax_tables_uncached(
        tax_year, province, data_dir=data_dir, projection_assumptions=projection_assumptions
    )
    _tax_table_cache[hashable_key] = result
    return result


def _load_tax_tables_uncached(
    tax_year: int,
    province: str,
    *,
    data_dir: str = "",
    projection_assumptions: dict[str, object] | None = None,
) -> TaxTables:
    if not data_dir:
        data_dir = tax_data_dir()
    normalized_province = province.upper()
    settings = _projection_settings(projection_assumptions)
    federal_path = Path(data_dir) / f"{tax_year}_federal.yaml"
    provincial_path = Path(data_dir) / f"{tax_year}_{normalized_province.lower()}.yaml"

    if federal_path.exists():
        federal = _parse_federal_table(_load_yaml(federal_path))
    else:
        base_year = _latest_available_year(data_dir, "federal", tax_year)
        if base_year is None:
            raise FileNotFoundError(f"No base federal tax table found for projection to year {tax_year}")
        base_federal = _parse_federal_table(_load_yaml(Path(data_dir) / f"{base_year}_federal.yaml"))
        federal = _project_federal_table(base_federal, tax_year, settings)

    if provincial_path.exists():
        provincial = _parse_provincial_table(_load_yaml(provincial_path))
    else:
        province_suffix = normalized_province.lower()
        base_year = _latest_available_year(data_dir, province_suffix, tax_year)
        if base_year is None:
            raise FileNotFoundError(
                f"No base provincial tax table found for {normalized_province} projection to year {tax_year}"
            )
        base_provincial = _parse_provincial_table(_load_yaml(Path(data_dir) / f"{base_year}_{province_suffix}.yaml"))
        provincial = _project_provincial_table(base_provincial, tax_year, settings)

    if federal.tax_year != tax_year:
        raise ValueError(f"Federal tax table year mismatch: expected {tax_year}, got {federal.tax_year}")
    if provincial.tax_year != tax_year:
        raise ValueError(f"Provincial tax table year mismatch: expected {tax_year}, got {provincial.tax_year}")
    if normalized_province != provincial.jurisdiction.upper():
        raise ValueError(
            f"Provincial jurisdiction mismatch: expected {normalized_province}, got {provincial.jurisdiction}"
        )

    return TaxTables(federal=federal, provincial=provincial)
