from finplanning_core.tax._impl.loader import load_tax_tables


def calculate_cpp_benefit(
    start_age: int,
    contribution_years: int,
    average_earnings: float,
    tax_year: int,
    province: str = "BC",
    projection_assumptions: dict[str, object] | None = None,
) -> float:
    """Calculate annual CPP benefit using tax-table parameters."""
    tables = load_tax_tables(tax_year=tax_year, province=province, projection_assumptions=projection_assumptions)
    cpp = tables.federal.cpp

    earnings_factor = min(1.0, average_earnings / cpp.max_pensionable_earnings)
    contribution_factor = min(1.0, contribution_years / 39.0)
    base = cpp.max_benefit_at_65 * earnings_factor * contribution_factor

    if start_age < 65:
        years_early = float(65 - start_age)
        factor = 1.0 - (cpp.early_reduction_per_year * years_early)
    else:
        years_deferred = float(min(start_age, 70) - 65)
        factor = 1.0 + (cpp.deferral_increase_per_year * years_deferred)
    return max(base * factor, 0.0)


def calculate_oas_benefit(
    start_age: int,
    net_income: float,
    tax_year: int,
    province: str = "BC",
    projection_assumptions: dict[str, object] | None = None,
) -> tuple[float, float]:
    """Return (gross annual OAS, clawback) for the tax year."""
    tables = load_tax_tables(tax_year=tax_year, province=province, projection_assumptions=projection_assumptions)
    oas = tables.federal.oas

    years_deferred = float(max(0, min(start_age, 70) - 65))
    gross = oas.max_benefit * (1.0 + (oas.deferral_increase_per_year * years_deferred))

    if net_income <= oas.clawback_threshold:
        return gross, 0.0

    clawback = (net_income - oas.clawback_threshold) * oas.clawback_rate
    if net_income >= oas.full_clawback_threshold:
        clawback = gross
    clawback = min(clawback, gross)
    return gross, clawback
