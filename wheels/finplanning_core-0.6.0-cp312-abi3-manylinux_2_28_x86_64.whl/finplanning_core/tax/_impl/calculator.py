from dataclasses import dataclass

from finplanning_core.data import tax_data_dir
from finplanning_core.tax._impl.loader import TaxBracket, TaxTables, load_tax_tables


@dataclass(frozen=True, slots=True)
class TaxResult:
    federal_tax: float
    provincial_tax: float
    total_tax: float
    marginal_tax_rate: float
    average_rate: float


def _round_money(value: float) -> float:
    return round(value, 2)


def _progressive_tax(taxable_income: float, brackets: list[TaxBracket]) -> float:
    tax = 0.0
    for index, bracket in enumerate(brackets):
        next_threshold = brackets[index + 1].threshold if index + 1 < len(brackets) else None
        if taxable_income <= bracket.threshold:
            break
        taxable_at_rate = taxable_income - bracket.threshold
        if next_threshold is not None:
            taxable_at_rate = min(taxable_at_rate, next_threshold - bracket.threshold)
        if taxable_at_rate > 0:
            tax += taxable_at_rate * bracket.rate
    return tax


def _marginal_rate(
    taxable_income: float,
    federal_brackets: list[TaxBracket],
    provincial_brackets: list[TaxBracket],
) -> float:
    if taxable_income <= 0:
        return 0.0
    federal_rate = next(bracket.rate for bracket in reversed(federal_brackets) if taxable_income >= bracket.threshold)
    provincial_rate = next(
        bracket.rate for bracket in reversed(provincial_brackets) if taxable_income >= bracket.threshold
    )
    return federal_rate + provincial_rate


class TaxCalculator:
    def __init__(self, *, data_dir: str = "", projection_assumptions: dict[str, object] | None = None) -> None:
        self._data_dir = data_dir or tax_data_dir()
        self._projection_assumptions = projection_assumptions

    def calculate_tax(
        self,
        taxable_income: float,
        tax_year: int,
        province: str,
        *,
        taxpayer_age: int | None = None,
        eligible_dividends: float = 0.0,
    ) -> TaxResult:
        income = max(taxable_income, 0.0)
        tables: TaxTables = load_tax_tables(
            tax_year=tax_year,
            province=province,
            data_dir=self._data_dir,
            projection_assumptions=self._projection_assumptions,
        )

        # Dividend gross-up: add the gross-up portion to taxable income.
        divs = max(eligible_dividends, 0.0)
        grossed_up_dividends = 0.0
        if divs > 0:
            gross_up = divs * tables.federal.eligible_dividend_gross_up_rate
            income += gross_up
            grossed_up_dividends = divs + gross_up

        federal_base = _progressive_tax(income, tables.federal.brackets)
        provincial_base = _progressive_tax(income, tables.provincial.brackets)

        federal_credit = tables.federal.basic_personal_amount * tables.federal.brackets[0].rate
        provincial_credit = tables.provincial.basic_personal_amount * tables.provincial.brackets[0].rate

        if taxpayer_age is not None and taxpayer_age >= 65:
            age_amount = tables.federal.age_amount
            threshold = tables.federal.age_amount_threshold
            if income > threshold:
                age_amount = max(age_amount - (income - threshold) * 0.15, 0.0)
            federal_credit += age_amount * tables.federal.brackets[0].rate

        if grossed_up_dividends > 0:
            federal_credit += grossed_up_dividends * tables.federal.eligible_dividend_tax_credit_rate
            provincial_credit += grossed_up_dividends * tables.provincial.eligible_dividend_tax_credit_rate

        federal_tax = max(federal_base - federal_credit, 0.0)
        provincial_tax = max(provincial_base - provincial_credit, 0.0)
        total_tax = federal_tax + provincial_tax
        marginal_tax_rate = _marginal_rate(income, tables.federal.brackets, tables.provincial.brackets)
        average_rate = 0.0 if income == 0 else total_tax / income

        return TaxResult(
            federal_tax=_round_money(federal_tax),
            provincial_tax=_round_money(provincial_tax),
            total_tax=_round_money(total_tax),
            marginal_tax_rate=marginal_tax_rate,
            average_rate=average_rate,
        )
