"""Benchmark and profile Monte Carlo runtime hotspots.

Usage example:
    .venv/bin/python -m finplanning_core.tools.monte_carlo_benchmark \
        --plan examples/john-and-jane.yaml \
        --iterations 500 \
        --return-method parametric \
        --repeat 3 \
        --workers 1 \
        --profile
"""

import argparse
import cProfile
import logging
import os
import pstats
import time
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, median
from typing import Literal

from finplanning_core.risk._impl.monte_carlo import MonteCarloConfig
from finplanning_core.services._impl.planning import PlanningService

ReturnMethod = Literal["historical", "parametric"]
KernelKind = Literal["rust"]
FidelityKind = Literal["fast", "full"]
SortKey = Literal["cumulative", "tottime"]


@dataclass(frozen=True)
class BenchmarkSummary:
    runs: int
    min_seconds: float
    max_seconds: float
    mean_seconds: float
    median_seconds: float
    p95_seconds: float


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m finplanning_core.tools.monte_carlo_benchmark", add_help=True)
    parser.add_argument("--plan", required=True, help="Path to plan YAML file.")
    parser.add_argument("--scenario-id", default=None, help="Scenario ID (defaults to plan base scenario).")
    parser.add_argument("--start-year", type=int, default=None, help="Projection start year.")
    parser.add_argument("--end-year", type=int, default=None, help="Projection end year.")
    parser.add_argument("--iterations", type=int, default=500, help="Monte Carlo iterations.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility.")
    parser.add_argument("--repeat", type=int, default=3, help="How many benchmark runs to execute.")
    parser.add_argument(
        "--return-method",
        choices=["historical", "parametric"],
        default="historical",
        help="Return generation method.",
    )
    parser.add_argument("--kernel", choices=["rust"], default="rust", help="Monte Carlo kernel.")
    parser.add_argument("--fidelity", choices=["full"], default="full", help="Kernel fidelity mode.")
    parser.add_argument("--workers", type=int, default=1, help="Worker count (1 = sequential).")
    parser.add_argument("--sample-path-count", type=int, default=50, help="Sample path count for charting.")
    parser.add_argument("--block-size", type=int, default=5, help="Historical bootstrap block size.")
    parser.add_argument("--df", type=int, default=5, help="Parametric Student's-t degrees of freedom.")
    parser.add_argument("--equity-std", type=float, default=0.16, help="Parametric equity std deviation.")
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Collect cProfile data for the first run and print top hotspots.",
    )
    parser.add_argument(
        "--profile-out",
        default="mc_profile.prof",
        help="Path to write .prof output when --profile is enabled.",
    )
    parser.add_argument(
        "--profile-sort",
        choices=["cumulative", "tottime"],
        default="cumulative",
        help="Sort key for top profile rows.",
    )
    parser.add_argument("--top", type=int, default=30, help="Number of top rows to print from profile stats.")
    parser.add_argument(
        "--timing-breakdown",
        action="store_true",
        help="Emit detailed engine/native timing breakdown logs (for Rust kernel analysis).",
    )
    return parser


def _percentile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        return 0.0
    idx = int(round((len(sorted_values) - 1) * q))
    idx = max(0, min(idx, len(sorted_values) - 1))
    return sorted_values[idx]


def summarize_durations(durations: list[float]) -> BenchmarkSummary:
    if not durations:
        raise ValueError("durations must not be empty")

    ordered = sorted(durations)
    return BenchmarkSummary(
        runs=len(ordered),
        min_seconds=ordered[0],
        max_seconds=ordered[-1],
        mean_seconds=mean(ordered),
        median_seconds=median(ordered),
        p95_seconds=_percentile(ordered, 0.95),
    )


def _print_summary(summary: BenchmarkSummary) -> None:
    print("\nTiming Summary")
    print(f"  runs:   {summary.runs}")
    print(f"  min:    {summary.min_seconds:.3f}s")
    print(f"  max:    {summary.max_seconds:.3f}s")
    print(f"  mean:   {summary.mean_seconds:.3f}s")
    print(f"  median: {summary.median_seconds:.3f}s")
    print(f"  p95:    {summary.p95_seconds:.3f}s")


def _run_single(
    service: PlanningService,
    *,
    scenario_id: str | None,
    start_year: int | None,
    end_year: int | None,
    config: MonteCarloConfig,
) -> tuple[float, float]:
    start = time.perf_counter()
    result = service.run_monte_carlo(
        scenario_id=scenario_id,
        start_year=start_year,
        end_year=end_year,
        config=config,
    )
    elapsed = time.perf_counter() - start
    return elapsed, result.depletion_probability


def _run_profiled(
    service: PlanningService,
    *,
    scenario_id: str | None,
    start_year: int | None,
    end_year: int | None,
    config: MonteCarloConfig,
    profile_out: str,
    sort_key: SortKey,
    top_n: int,
) -> tuple[float, float]:
    profiler = cProfile.Profile()
    profiler.enable()
    elapsed, depletion_probability = _run_single(
        service,
        scenario_id=scenario_id,
        start_year=start_year,
        end_year=end_year,
        config=config,
    )
    profiler.disable()

    out_path = Path(profile_out)
    profiler.dump_stats(str(out_path))

    print(f"\nProfile saved to {out_path}")
    print(f"Top {top_n} functions by {sort_key}:")
    stats = pstats.Stats(profiler).sort_stats(sort_key)
    stats.print_stats(top_n)

    return elapsed, depletion_probability


def main() -> None:
    args = _build_parser().parse_args()
    if args.timing_breakdown:
        os.environ["FINPLAN_MC_TIMING"] = "1"
        logging.basicConfig(level=logging.INFO, format="%(levelname)s:%(name)s:%(message)s")

    service = PlanningService.from_yaml(args.plan)
    config = MonteCarloConfig(
        n_iterations=args.iterations,
        seed=args.seed,
        n_workers=args.workers,
        sample_path_count=args.sample_path_count,
        return_method=args.return_method,
        block_size=args.block_size,
        df=args.df,
        equity_std=args.equity_std,
        kernel=args.kernel,
        fidelity=args.fidelity,
    )

    print("Monte Carlo Benchmark")
    print(f"  plan: {args.plan}")
    print(f"  iterations: {args.iterations}")
    print(f"  return_method: {args.return_method}")
    print(f"  kernel: {args.kernel}")
    print(f"  fidelity: {args.fidelity}")
    print(f"  workers: {args.workers}")
    print(f"  repeat: {args.repeat}")

    durations: list[float] = []
    latest_dep_prob = 0.0

    for i in range(args.repeat):
        if i == 0 and args.profile:
            elapsed, latest_dep_prob = _run_profiled(
                service,
                scenario_id=args.scenario_id,
                start_year=args.start_year,
                end_year=args.end_year,
                config=config,
                profile_out=args.profile_out,
                sort_key=args.profile_sort,
                top_n=args.top,
            )
        else:
            elapsed, latest_dep_prob = _run_single(
                service,
                scenario_id=args.scenario_id,
                start_year=args.start_year,
                end_year=args.end_year,
                config=config,
            )

        durations.append(elapsed)
        print(f"run {i + 1}/{args.repeat}: {elapsed:.3f}s (depletion_probability={latest_dep_prob:.2%})")

    summary = summarize_durations(durations)
    _print_summary(summary)


if __name__ == "__main__":
    main()
