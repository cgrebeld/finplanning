"""JSON tool definitions for LLM consumption.

Generates JSON Schema from Pydantic input models and resolves ``$ref``
pointers so the output is self-contained.
"""

from typing import Any

from pydantic import BaseModel

from finplanning_core.tools._impl.schemas import (
    AddScenarioInput,
    CompareInput,
    CreatePlanVariantInput,
    LoadPlanInput,
    MonteCarloInput,
    ProjectionDetailInput,
    RunProjectionInput,
)


def _resolve_refs(schema: dict[str, Any], defs: dict[str, Any]) -> dict[str, Any]:
    """Recursively resolve ``$ref`` references in a JSON schema."""
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]
        resolved = defs.get(ref_name, {})
        return _resolve_refs(dict(resolved), defs)

    result: dict[str, Any] = {}
    for key, value in schema.items():
        if key == "$defs":
            continue
        if isinstance(value, dict):
            result[key] = _resolve_refs(value, defs)
        elif isinstance(value, list):
            result[key] = [_resolve_refs(item, defs) if isinstance(item, dict) else item for item in value]
        else:
            result[key] = value
    return result


def _make_tool_def(
    name: str,
    description: str,
    input_model: type[BaseModel],
) -> dict[str, Any]:
    """Build a tool definition dict from a Pydantic model."""
    schema = input_model.model_json_schema()
    defs = schema.pop("$defs", {})
    resolved = _resolve_refs(schema, defs)
    resolved.pop("title", None)
    return {
        "name": name,
        "description": description,
        "parameters": resolved,
    }


TOOL_DEFINITIONS: list[dict[str, Any]] = [
    _make_tool_def(
        name="load_plan",
        description=(
            "Load a Canadian retirement plan from YAML and return a structured summary "
            "including persons, accounts, income sources, expenses, scenarios, and assumptions. "
            "Call this first to understand the plan before running projections."
        ),
        input_model=LoadPlanInput,
    ),
    _make_tool_def(
        name="run_projection",
        description=(
            "Run a year-by-year retirement projection for a given scenario and return key metrics "
            "(final net worth, depletion age, sustainable spending, spending gap) plus a condensed "
            "yearly summary (10 fields per year). Use this to analyze a single scenario."
        ),
        input_model=RunProjectionInput,
    ),
    _make_tool_def(
        name="compare_scenarios",
        description=(
            "Compare multiple scenarios side-by-side. Returns per-scenario metrics and delta "
            "analysis showing the impact of each scenario relative to the base case. Use this "
            "to evaluate which scenario produces better outcomes."
        ),
        input_model=CompareInput,
    ),
    _make_tool_def(
        name="add_scenario",
        description=(
            "Add a new scenario to an existing plan by cloning a base scenario and applying "
            "overrides. Overrides use dot-path notation (e.g. 'assumptions.returns.equity_return' "
            "or 'expenses.essential.annual_amount'). Returns the updated plan YAML. "
            "LIMITATION: can only modify existing items. For adding new accounts/income/expenses, "
            "use create_plan_variant instead."
        ),
        input_model=AddScenarioInput,
    ),
    _make_tool_def(
        name="create_plan_variant",
        description=(
            "Create a new plan by applying structured modifications to an existing plan. "
            "Supports add/modify/remove for accounts, income, expenses, one-time events, and "
            "recurring expenses, plus deep-merge for assumptions. Returns the complete modified "
            "plan YAML. Use this when you need to ADD new items (e.g. a new income source for "
            "a spousal loan, a new account). The output can be saved and loaded in the "
            "Streamlit UI for visualization."
        ),
        input_model=CreatePlanVariantInput,
    ),
    _make_tool_def(
        name="run_monte_carlo",
        description=(
            "Run a Monte Carlo stress test with 100-10000 iterations to assess the probability "
            "of portfolio depletion. Returns depletion probability, net worth percentiles "
            "(p10-p90), and a human-readable risk summary. May take 10-60 seconds."
        ),
        input_model=MonteCarloInput,
    ),
    _make_tool_def(
        name="get_projection_detail",
        description=(
            "Get detailed year-by-year projection data for specific years. Returns all 65+ "
            "fields per year (or a filtered subset). Use this when you need granular data "
            "for specific years after reviewing the condensed summary from run_projection."
        ),
        input_model=ProjectionDetailInput,
    ),
]
