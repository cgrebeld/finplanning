"""Generate a deterministic year-by-year parity trace for Python vs Rust MC kernels.

Usage:
    .venv/bin/python -m finplanning_core.tools._impl.monte_carlo_parity_trace \
        --plan tests/testdata/sample-plan.yaml \
        --scenario-id base \
        --start-year 2026 \
        --end-year 2067 \
        --return-method historical \
        --seed 42
"""

from __future__ import annotations

import argparse
import importlib
import json
from datetime import date
from pathlib import Path
from typing import Any, Literal

import numpy as np

from finplanning_core.engine._impl.engine import CashFlowEngine
from finplanning_core.loader._impl.user_data import load_user_data
from finplanning_core.models._impl.assumptions import ReturnAssumptions
from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.risk._impl.historical import generate_returns_bootstrap
from finplanning_core.risk._impl.native_types import build_native_plan_payload
from finplanning_core.risk._impl.returns import generate_returns
from finplanning_core.tax._impl.loader import TaxTables, load_tax_tables

ReturnMethod = Literal["historical", "parametric"]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m finplanning_core.tools._impl.monte_carlo_parity_trace",
        add_help=True,
    )
    parser.add_argument("--plan", required=True, help="Path to plan YAML.")
    parser.add_argument("--scenario-id", default=None, help="Scenario ID (default = base scenario).")
    parser.add_argument("--start-year", type=int, default=None, help="Projection start year.")
    parser.add_argument("--end-year", type=int, default=None, help="Projection end year.")
    parser.add_argument("--return-method", choices=["historical", "parametric"], default="historical")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--block-size", type=int, default=5, help="Historical bootstrap block size.")
    parser.add_argument("--df", type=int, default=5, help="Student-t degrees of freedom for parametric method.")
    parser.add_argument("--equity-std", type=float, default=0.16)
    parser.add_argument("--equity-mean", type=float, default=None)
    parser.add_argument("--abs-tol", type=float, default=1e-6)
    parser.add_argument(
        "--output-json",
        default=None,
        help="Optional path to write full trace+diff JSON payload.",
    )
    return parser


def _default_start_year() -> int:
    return date.today().year


def _default_end_year(plan: HouseholdPlan) -> int:
    max_age = max(person.life_expectancy_age for person in plan.persons)
    youngest_birth_year = max(person.birth_date.year for person in plan.persons)
    return int(youngest_birth_year + max_age)


def _build_return_matrices(
    *,
    n_years: int,
    return_method: ReturnMethod,
    seed: int | None,
    block_size: int,
    equity_mean: float,
    equity_std: float,
    df: int,
    base_returns: ReturnAssumptions,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None]:
    if return_method == "historical":
        bootstrap = generate_returns_bootstrap(
            n_years=n_years,
            n_simulations=1,
            block_size=block_size,
            seed=seed,
        )
        return bootstrap["equity"], bootstrap["fixed_income"], bootstrap["cash"]

    eq = generate_returns(
        n_years=n_years,
        n_simulations=1,
        mean=equity_mean,
        std=equity_std,
        df=df,
        seed=seed,
    )
    fi = np.full((1, n_years), base_returns.fixed_income_return, dtype=np.float64)
    cash = np.full((1, n_years), base_returns.cash_return, dtype=np.float64)
    return eq, fi, cash


def _python_trace_rows(
    *,
    plan_file: str,
    scenario_id: str | None,
    start_year: int,
    end_year: int,
    return_matrix: np.ndarray,
    fixed_income_matrix: np.ndarray | None,
    cash_matrix: np.ndarray | None,
    base_returns: ReturnAssumptions,
) -> list[dict[str, float]]:
    plan = load_user_data(plan_file)
    engine = CashFlowEngine(plan)
    return_overrides: dict[int, ReturnAssumptions] = {}
    for y_idx, year in enumerate(range(start_year, end_year + 1)):
        eq = float(return_matrix[0, y_idx])
        fi = (
            float(fixed_income_matrix[0, y_idx])
            if fixed_income_matrix is not None
            else base_returns.fixed_income_return
        )
        cash = float(cash_matrix[0, y_idx]) if cash_matrix is not None else base_returns.cash_return
        return_overrides[year] = ReturnAssumptions(
            equity=eq,
            fixed_income=fi,
            cash=cash,
        )

    target_scenario = scenario_id or plan.base_scenario_id
    province = plan.household.province.value
    tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
    tax_tables_by_year: dict[int, TaxTables] = {
        year: load_tax_tables(year, province, projection_assumptions=tax_projection)
        for year in range(start_year, end_year + 1)
    }
    projection = engine.run_projection(
        scenario_id=target_scenario,
        start_year=start_year,
        end_year=end_year,
        return_overrides=return_overrides,
        include_spending_analysis=False,
        tax_tables_by_year=tax_tables_by_year,
    )
    rows: list[dict[str, float]] = []
    for trace_row in projection.years:
        rows.append(
            {
                "year": float(trace_row.year),
                "total_income": float(trace_row.total_income),
                "total_tax": float(trace_row.total_tax),
                "oas_income": float(trace_row.oas_income),
                "oas_clawback": float(trace_row.oas_clawback),
                "total_withdrawals": float(trace_row.total_withdrawals),
                "taxable_capital_gains": float(trace_row.taxable_capital_gains),
                "cash_flow_gap": float(trace_row.cash_flow_gap),
                "net_worth": float(trace_row.total_net_worth),
            }
        )
    return rows


def _load_native_module() -> Any:
    return importlib.import_module("finplanning_core_native")


def _rust_trace_rows(
    *,
    plan_file: str,
    scenario_id: str | None,
    start_year: int,
    end_year: int,
    return_matrix: np.ndarray,
    fixed_income_matrix: np.ndarray | None,
    cash_matrix: np.ndarray | None,
    base_returns: ReturnAssumptions,
) -> list[dict[str, float]]:
    module = _load_native_module()
    plan = load_user_data(plan_file)
    province = plan.household.province.value
    tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
    tax_tables_by_year: dict[int, TaxTables] = {
        year: load_tax_tables(year, province, projection_assumptions=tax_projection)
        for year in range(start_year, end_year + 1)
    }
    plan_payload = build_native_plan_payload(plan, start_year, end_year, tax_tables_by_year)
    response = module.simulate_batch(
        {
            "plan": plan_payload,
            "scenario_id": scenario_id or plan.base_scenario_id,
            "start_year": start_year,
            "end_year": end_year,
            "n_iterations": 1,
            "sample_indices": [],
            "fidelity": "full",
            "return_matrix": return_matrix.tolist(),
            "fixed_income_matrix": fixed_income_matrix.tolist() if fixed_income_matrix is not None else None,
            "cash_matrix": cash_matrix.tolist() if cash_matrix is not None else None,
            "base_returns": base_returns.model_dump(mode="python"),
            "return_debug_trace": True,
        }
    )
    raw_rows = response.get("debug_trace_rows")
    if not isinstance(raw_rows, list) or not raw_rows:
        raise RuntimeError("Native debug trace not returned. Ensure native module supports return_debug_trace.")
    iter_rows = raw_rows[0]
    return [{str(k): float(v) for k, v in row.items()} for row in iter_rows]


def diff_trace_rows(
    python_rows: list[dict[str, float]],
    rust_rows: list[dict[str, float]],
    *,
    abs_tol: float,
) -> dict[str, Any]:
    python_keyset: set[str] = set()
    rust_keyset: set[str] = set()
    for row in python_rows:
        python_keyset.update(k for k in row if k != "year")
    for row in rust_rows:
        rust_keyset.update(k for k in row if k != "year")
    keys = sorted(python_keyset.intersection(rust_keyset))

    first_divergence_year: int | None = None
    keys_with_differences: set[str] = set()
    max_abs: dict[str, float] = {k: 0.0 for k in keys}
    per_year: list[dict[str, Any]] = []

    max_len = max(len(python_rows), len(rust_rows))
    for idx in range(max_len):
        py_row = python_rows[idx] if idx < len(python_rows) else None
        rs_row = rust_rows[idx] if idx < len(rust_rows) else None
        year = int((py_row or rs_row or {}).get("year", 0.0))
        row_diff: dict[str, float] = {}
        if py_row is None or rs_row is None:
            if first_divergence_year is None:
                first_divergence_year = year
            per_year.append({"year": year, "missing_python": py_row is None, "missing_rust": rs_row is None})
            continue
        for key in keys:
            py_value = float(py_row.get(key, 0.0))
            rs_value = float(rs_row.get(key, 0.0))
            delta = rs_value - py_value
            abs_delta = abs(delta)
            max_abs[key] = max(max_abs[key], abs_delta)
            if abs_delta > abs_tol:
                row_diff[key] = delta
                keys_with_differences.add(key)
                if first_divergence_year is None:
                    first_divergence_year = year
        if row_diff:
            per_year.append({"year": year, "differences": row_diff})

    return {
        "row_count_python": len(python_rows),
        "row_count_rust": len(rust_rows),
        "first_divergence_year": first_divergence_year,
        "keys_with_differences": sorted(keys_with_differences),
        "max_abs_differences": max_abs,
        "per_year_differences": per_year,
    }


def main() -> None:
    args = _build_parser().parse_args()
    plan = load_user_data(args.plan)
    start_year = args.start_year or _default_start_year()
    end_year = args.end_year or _default_end_year(plan)
    n_years = end_year - start_year + 1
    base_returns = plan.assumptions.returns
    equity_mean = args.equity_mean if args.equity_mean is not None else base_returns.equity_return

    return_matrix, fixed_income_matrix, cash_matrix = _build_return_matrices(
        n_years=n_years,
        return_method=args.return_method,
        seed=args.seed,
        block_size=args.block_size,
        equity_mean=equity_mean,
        equity_std=args.equity_std,
        df=args.df,
        base_returns=base_returns,
    )

    python_rows = _python_trace_rows(
        plan_file=args.plan,
        scenario_id=args.scenario_id,
        start_year=start_year,
        end_year=end_year,
        return_matrix=return_matrix,
        fixed_income_matrix=fixed_income_matrix,
        cash_matrix=cash_matrix,
        base_returns=base_returns,
    )
    rust_rows = _rust_trace_rows(
        plan_file=args.plan,
        scenario_id=args.scenario_id,
        start_year=start_year,
        end_year=end_year,
        return_matrix=return_matrix,
        fixed_income_matrix=fixed_income_matrix,
        cash_matrix=cash_matrix,
        base_returns=base_returns,
    )
    diff = diff_trace_rows(python_rows, rust_rows, abs_tol=args.abs_tol)

    print("Monte Carlo Parity Trace")
    print(f"  plan: {args.plan}")
    print(f"  scenario: {args.scenario_id or plan.base_scenario_id}")
    print(f"  years: {start_year}-{end_year}")
    print(f"  first_divergence_year: {diff['first_divergence_year']}")
    print(f"  keys_with_differences: {', '.join(diff['keys_with_differences']) or '<none>'}")

    payload = {"python_rows": python_rows, "rust_rows": rust_rows, "diff": diff}
    if args.output_json:
        out_path = Path(args.output_json)
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"  wrote: {out_path}")
    else:
        print(json.dumps(diff, indent=2))


if __name__ == "__main__":
    main()
