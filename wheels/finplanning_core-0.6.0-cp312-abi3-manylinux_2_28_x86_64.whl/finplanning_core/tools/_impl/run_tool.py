"""CLI wrapper for LLM tool dispatch.

Backwards-compatible usage:
    ./finplan-tool <tool_name> '<json_arguments>'
    ./finplan-tool <tool_name> -

Convenience options (avoid embedding large YAML in JSON strings):
    ./finplan-tool load_plan --plan-file tests/testdata/sample-plan.yaml
    ./finplan-tool run_projection --plan-file tests/testdata/sample-plan.yaml --set scenario_id=base
    ./finplan-tool add_scenario --plan-file tests/testdata/sample-plan.yaml \\
        --set base_scenario_id=base \\
        --set new_scenario_name=Test \\
        --set overrides.income.john-salary.end_date=2030
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from finplanning_core.tools import dispatch_tool_call


def _read_text(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    return Path(path).expanduser().read_text(encoding="utf-8")


def _load_json_object(raw: str) -> dict[str, Any]:
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("JSON arguments must be an object (mapping).")
    return parsed


def _parse_set_kv(raw: str) -> tuple[str, Any]:
    if "=" not in raw:
        raise ValueError(f"Invalid --set value {raw!r}; expected KEY=VALUE.")
    key, value_raw = raw.split("=", 1)
    key = key.strip()
    value_raw = value_raw.strip()
    if not key:
        raise ValueError(f"Invalid --set value {raw!r}; missing KEY.")

    # Parse JSON scalars/objects/arrays when possible (true/false/null/123/1.2/["x"]/{...}).
    # Fall back to raw string for common values like years (2026).
    try:
        value: Any = json.loads(value_raw)
    except json.JSONDecodeError:
        value = value_raw

    return key, value


def _set_by_dot_path(target: dict[str, Any], dot_path: str, value: Any) -> None:
    # Special case: allow `--set overrides.<dot.path>=...` to populate the *add_scenario*
    # overrides dict, whose keys are themselves dot-path strings.
    if dot_path.startswith("overrides."):
        override_key = dot_path.removeprefix("overrides.")
        overrides = target.setdefault("overrides", {})
        if not isinstance(overrides, dict):
            raise ValueError("Cannot apply overrides.* because 'overrides' is not an object.")
        overrides[override_key] = value
        return

    parts = dot_path.split(".")
    cursor: dict[str, Any] = target
    for part in parts[:-1]:
        existing = cursor.get(part)
        if not isinstance(existing, dict):
            cursor[part] = {}
        cursor = cursor[part]
    cursor[parts[-1]] = value


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m finplanning_core.tools.run_tool", add_help=True)
    parser.add_argument("tool_name", help="Tool name to invoke (e.g. load_plan, run_projection).")
    parser.add_argument(
        "json_args",
        nargs="?",
        default=None,
        help="JSON object string for arguments, or '-' to read JSON from stdin (legacy).",
    )
    parser.add_argument(
        "--plan-file",
        help="Path to a plan YAML file; its content is injected as the 'plan_yaml' argument.",
    )
    parser.add_argument(
        "--args-file",
        help="Path to a JSON file containing an argument object (or '-' to read from stdin).",
    )
    parser.add_argument(
        "--json",
        dest="json_overrides",
        help="JSON object string to merge into arguments (overrides values from --args-file/positional).",
    )
    parser.add_argument(
        "--set",
        action="append",
        default=[],
        help="Set KEY=VALUE in arguments; KEY supports dot paths (repeatable).",
    )
    return parser


def main() -> None:
    try:
        parser = _build_parser()
        args = parser.parse_args()

        arguments: dict[str, Any] = {}

        if args.args_file:
            arguments.update(_load_json_object(_read_text(args.args_file)))

        if args.json_args is not None:
            raw = _read_text("-") if args.json_args == "-" else args.json_args
            arguments.update(_load_json_object(raw))

        if args.json_overrides:
            arguments.update(_load_json_object(args.json_overrides))

        if args.plan_file:
            arguments["plan_yaml"] = _read_text(args.plan_file)

        for raw_set in args.set:
            key, value = _parse_set_kv(raw_set)
            _set_by_dot_path(arguments, key, value)

        result = dispatch_tool_call(args.tool_name, arguments)
        print(json.dumps(result, indent=2))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"error": str(exc)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
