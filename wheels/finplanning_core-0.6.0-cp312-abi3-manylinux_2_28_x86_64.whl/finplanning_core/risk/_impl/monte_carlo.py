"""Monte Carlo simulation engine for retirement plan stress testing."""

import logging
import os
import time
from collections.abc import Callable
from typing import Literal

import numpy as np
from numpy.typing import NDArray
from pydantic import BaseModel, Field

from finplanning_core.engine._impl.projection import ProjectionResult
from finplanning_core.models._impl.assumptions import ReturnAssumptions
from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.risk._impl.historical import generate_returns_bootstrap
from finplanning_core.risk._impl.native_kernel import run_native_batch
from finplanning_core.risk._impl.returns import generate_returns

logger = logging.getLogger(__name__)


def _default_worker_count() -> int:
    cpu_count = os.cpu_count() or 1
    return max(cpu_count - 1, 1)


class MonteCarloConfig(BaseModel):
    """Configuration for a Monte Carlo simulation run."""

    n_iterations: int = 5000
    seed: int | None = None
    df: int = 5
    equity_mean: float | None = None  # None = use plan's equity_return
    equity_std: float = 0.16
    sample_path_count: int = 50
    n_workers: int = Field(default_factory=_default_worker_count)  # default: cpu_count - 1 (min 1)
    return_method: Literal["parametric", "historical"] = "historical"
    block_size: int = 5
    kernel: Literal["rust"] = "rust"
    fidelity: Literal["full"] = "full"


class MonteCarloResult(BaseModel):
    """Results of a Monte Carlo simulation."""

    scenario_id: str
    n_iterations: int
    seed: int | None
    depletion_probability: float
    percentiles: dict[int, float]  # keys: 10, 25, 50, 75, 90
    median_depletion_age: int | None
    sample_paths: list[ProjectionResult]
    net_worth_percentiles_by_year: dict[int, list[float]] = Field(default_factory=dict)
    projection_years: list[int] = Field(default_factory=list)
    person1_ages: list[int] = Field(default_factory=list)
    return_method: str = "parametric"


class MonteCarloEngine:
    """Run probabilistic projections using fat-tailed random returns."""

    def __init__(self, plan: HouseholdPlan) -> None:
        self._plan = plan

    def run_simulation(
        self,
        scenario_id: str,
        start_year: int,
        end_year: int,
        config: MonteCarloConfig | None = None,
        progress_callback: Callable[[float], object] | None = None,
    ) -> MonteCarloResult:
        cfg = config or MonteCarloConfig()
        collect_timing = os.getenv("FINPLAN_MC_TIMING") == "1"
        t_total = time.perf_counter()
        n_years = end_year - start_year + 1
        if cfg.fidelity != "full":
            raise ValueError("Rust kernel supports only fidelity='full'.")

        fixed_income_matrix: NDArray[np.float64] | None = None
        cash_matrix: NDArray[np.float64] | None = None

        t0 = time.perf_counter()
        if cfg.return_method == "historical":
            bootstrap = generate_returns_bootstrap(
                n_years=n_years,
                n_simulations=cfg.n_iterations,
                block_size=cfg.block_size,
                seed=cfg.seed,
            )
            return_matrix = bootstrap["equity"]
            fixed_income_matrix = bootstrap["fixed_income"]
            cash_matrix = bootstrap["cash"]
        else:
            equity_mean = (
                cfg.equity_mean if cfg.equity_mean is not None else self._plan.assumptions.returns.equity_return
            )
            equity_std = cfg.equity_std
            return_matrix = generate_returns(
                n_years=n_years,
                n_simulations=cfg.n_iterations,
                mean=equity_mean,
                std=equity_std,
                df=cfg.df,
                seed=cfg.seed,
            )
        return_generation_s = time.perf_counter() - t0

        base_returns = self._plan.assumptions.returns

        # Decide which iterations to keep as sample paths (evenly spaced)
        sample_count = min(cfg.sample_path_count, cfg.n_iterations)
        if sample_count <= 0:
            sample_indices: set[int] = set()
        elif sample_count == 1:
            sample_indices = {0}
        else:
            sample_indices = {int(round(i * (cfg.n_iterations - 1) / (sample_count - 1))) for i in range(sample_count)}

        n_workers = cfg.n_workers if cfg.n_workers > 0 else os.cpu_count() or 1

        t0 = time.perf_counter()
        final_net_worths, depletion_ages, sample_paths, all_yearly_path_net_worths = self._run_native(
            scenario_id,
            start_year,
            end_year,
            return_matrix,
            base_returns,
            cfg.n_iterations,
            sample_indices,
            progress_callback,
            n_workers=n_workers,
            fixed_income_matrix=fixed_income_matrix,
            cash_matrix=cash_matrix,
            fidelity=cfg.fidelity,
        )
        simulation_kernel_s = time.perf_counter() - t0

        # Compute statistics
        nw_array = np.array(final_net_worths)
        percentile_keys = [10, 25, 50, 75, 90]
        percentile_values = np.percentile(nw_array, percentile_keys)
        percentiles = {k: float(v) for k, v in zip(percentile_keys, percentile_values, strict=True)}

        yearly_nw_array = np.array(all_yearly_path_net_worths)
        yearly_percentiles: dict[int, list[float]] = {}
        for percentile in percentile_keys:
            values = np.percentile(yearly_nw_array, percentile, axis=0)
            yearly_percentiles[percentile] = [float(v) for v in values]

        n_depleted = sum(1 for age in depletion_ages if age is not None)
        depletion_probability = n_depleted / cfg.n_iterations

        actual_depletion_ages = [age for age in depletion_ages if age is not None]
        median_depletion_age = int(np.median(actual_depletion_ages)) if actual_depletion_ages else None

        projection_years = list(range(start_year, end_year + 1))
        person1_birth_year = self._plan.household.person1.birth_date.year
        person1_ages = [year - person1_birth_year for year in projection_years]

        result = MonteCarloResult(
            scenario_id=scenario_id,
            n_iterations=cfg.n_iterations,
            seed=cfg.seed,
            depletion_probability=depletion_probability,
            percentiles=percentiles,
            median_depletion_age=median_depletion_age,
            sample_paths=sample_paths,
            net_worth_percentiles_by_year=yearly_percentiles,
            projection_years=projection_years,
            person1_ages=person1_ages,
            return_method=cfg.return_method,
        )
        if collect_timing:
            total_s = time.perf_counter() - t_total
            logger.info(
                "MC_TIMING engine return_generation_s=%.6f simulation_kernel_s=%.6f "
                "stats_build_s=%.6f total_s=%.6f kernel=%s workers=%d iterations=%d",
                return_generation_s,
                simulation_kernel_s,
                max(total_s - return_generation_s - simulation_kernel_s, 0.0),
                total_s,
                "rust",
                n_workers,
                cfg.n_iterations,
            )
        return result

    def _run_native(
        self,
        scenario_id: str,
        start_year: int,
        end_year: int,
        return_matrix: NDArray[np.float64],
        base_returns: ReturnAssumptions,
        n_iterations: int,
        sample_indices: set[int],
        progress_callback: Callable[[float], object] | None,
        *,
        n_workers: int,
        fixed_income_matrix: NDArray[np.float64] | None,
        cash_matrix: NDArray[np.float64] | None,
        fidelity: str,
    ) -> tuple[list[float], list[int | None], list[ProjectionResult], list[list[float]]]:
        net_worths, dep_ages, indexed_paths, indexed_all_path_net_worths = run_native_batch(
            plan=self._plan,
            scenario_id=scenario_id,
            start_year=start_year,
            end_year=end_year,
            return_matrix=return_matrix,
            base_returns=base_returns,
            n_iterations=n_iterations,
            sample_indices=sample_indices,
            fixed_income_matrix=fixed_income_matrix,
            cash_matrix=cash_matrix,
            n_threads=n_workers,
            fidelity=fidelity,
        )
        if progress_callback is not None:
            progress_callback(1.0)
        indexed_paths.sort(key=lambda t: t[0])
        paths = [path for _, path in indexed_paths]
        indexed_all_path_net_worths.sort(key=lambda t: t[0])
        all_path_net_worths = [row for _, row in indexed_all_path_net_worths]
        return net_worths, dep_ages, paths, all_path_net_worths
