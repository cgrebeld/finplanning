"""Circular block bootstrap from historical US market returns (1928-2024)."""

import csv
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
from numpy.typing import NDArray

from finplanning_core.data import market_data_dir

ASSET_EQUITY = 0
ASSET_FIXED_INCOME = 1
ASSET_CASH = 2

_DEFAULT_DATA_PATH = str(Path(market_data_dir()) / "us_annual_returns.csv")


@lru_cache(maxsize=1)
def load_historical_returns(data_path: str | None = None) -> NDArray[np.float64]:
    """Load CSV -> array of shape (n_years, 3) [equity, fixed_income, cash]."""
    path = data_path or _DEFAULT_DATA_PATH
    rows: list[list[float]] = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append([float(row["equity"]), float(row["fixed_income"]), float(row["cash"])])
    return np.array(rows, dtype=np.float64)


def generate_returns_bootstrap(
    n_years: int,
    n_simulations: int,
    block_size: int = 5,
    seed: int | None = None,
    data_path: str | None = None,
) -> dict[str, NDArray[np.float64]]:
    """Circular block bootstrap from historical data.

    Returns {"equity": ..., "fixed_income": ..., "cash": ...},
    each array shape (n_simulations, n_years).
    """
    history = load_historical_returns(data_path)
    h = len(history)

    rng = np.random.default_rng(seed)
    n_blocks = math.ceil(n_years / block_size)

    # Sample random start indices in [0, h)
    starts = rng.integers(0, h, size=(n_simulations, n_blocks))

    # Expand to full indices using circular wrapping
    offsets = np.arange(block_size)  # (block_size,)
    # starts[:, :, None] + offsets[None, None, :] -> (n_simulations, n_blocks, block_size)
    full_indices = (starts[:, :, np.newaxis] + offsets[np.newaxis, np.newaxis, :]) % h
    # Reshape to (n_simulations, n_blocks * block_size), trim to n_years
    full_indices = full_indices.reshape(n_simulations, -1)[:, :n_years]

    # Fancy-index into history -> (n_simulations, n_years, 3)
    sampled = history[full_indices]

    return {
        "equity": sampled[:, :, ASSET_EQUITY],
        "fixed_income": sampled[:, :, ASSET_FIXED_INCOME],
        "cash": sampled[:, :, ASSET_CASH],
    }
