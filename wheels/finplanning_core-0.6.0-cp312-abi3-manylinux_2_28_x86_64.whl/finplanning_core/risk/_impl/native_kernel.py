from __future__ import annotations

import importlib
import logging
import os
import time
from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray

from finplanning_core.engine._impl.projection import ProjectionResult, YearlyProjection
from finplanning_core.models._impl.assumptions import ReturnAssumptions
from finplanning_core.models._impl.plan import HouseholdPlan
from finplanning_core.risk._impl.native_types import build_native_plan_payload
from finplanning_core.tax._impl.loader import TaxTables, load_tax_tables

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class NativeProjectionSummary:
    final_net_worth: float
    depletion_age: int | None
    yearly_net_worths: list[float]


def _load_native_module() -> Any:
    try:
        return importlib.import_module("finplanning_core_native")
    except ImportError as exc:  # pragma: no cover - exercised through fallback flow
        raise RuntimeError("finplanning_core_native module is not available") from exc


def run_native_batch(
    *,
    plan: HouseholdPlan,
    scenario_id: str,
    start_year: int,
    end_year: int,
    return_matrix: NDArray[np.float64],
    base_returns: ReturnAssumptions,
    n_iterations: int,
    sample_indices: set[int],
    n_threads: int = 1,
    fidelity: str,
    fixed_income_matrix: NDArray[np.float64] | None = None,
    cash_matrix: NDArray[np.float64] | None = None,
) -> tuple[list[float], list[int | None], list[tuple[int, ProjectionResult]], list[tuple[int, list[float]]]]:
    collect_timing = os.getenv("FINPLAN_MC_TIMING") == "1"
    t_total = time.perf_counter()
    t0 = time.perf_counter()
    module = _load_native_module()
    module_load_s = time.perf_counter() - t0
    tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
    province = plan.household.province.value
    t0 = time.perf_counter()
    tax_tables_by_year: dict[int, TaxTables] = {
        year: load_tax_tables(year, province, projection_assumptions=tax_projection)
        for year in range(start_year, end_year + 1)
    }
    tax_tables_load_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    plan_payload = build_native_plan_payload(plan, start_year, end_year, tax_tables_by_year)
    plan_payload_build_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    return_matrix_payload = return_matrix.tolist()
    fixed_income_matrix_payload = fixed_income_matrix.tolist() if fixed_income_matrix is not None else None
    cash_matrix_payload = cash_matrix.tolist() if cash_matrix is not None else None
    matrix_to_list_s = time.perf_counter() - t0
    t0 = time.perf_counter()
    response = module.simulate_batch(
        {
            "plan": plan_payload,
            "scenario_id": scenario_id,
            "start_year": start_year,
            "end_year": end_year,
            "n_iterations": n_iterations,
            "n_threads": n_threads,
            "sample_indices": sorted(sample_indices),
            "fidelity": fidelity,
            "return_matrix": return_matrix_payload,
            "fixed_income_matrix": fixed_income_matrix_payload,
            "cash_matrix": cash_matrix_payload,
            "base_returns": base_returns.model_dump(mode="python"),
            "return_timing": collect_timing,
        }
    )
    native_call_s = time.perf_counter() - t0

    t0 = time.perf_counter()
    final_net_worths = [float(value) for value in response["final_net_worths"]]
    depletion_ages = [None if value is None else int(value) for value in response["depletion_ages"]]
    yearly_net_worths = response.get("yearly_net_worths", [])
    indexed_rows: list[tuple[int, list[float]]] = [
        (idx, [float(v) for v in row]) for idx, row in enumerate(yearly_net_worths)
    ]
    response_parse_s = time.perf_counter() - t0
    total_bridge_s = time.perf_counter() - t_total
    if collect_timing:
        rust_timing = response.get("timings", {})
        logger.info(
            "MC_TIMING native_bridge "
            "module_load_s=%.6f tax_tables_load_s=%.6f plan_payload_build_s=%.6f "
            "matrix_to_list_s=%.6f native_call_s=%.6f response_parse_s=%.6f total_bridge_s=%.6f "
            "rust_parse_s=%s rust_compute_s=%s rust_result_build_s=%s rust_total_s=%s",
            module_load_s,
            tax_tables_load_s,
            plan_payload_build_s,
            matrix_to_list_s,
            native_call_s,
            response_parse_s,
            total_bridge_s,
            rust_timing.get("parse_payload_s"),
            rust_timing.get("compute_s"),
            rust_timing.get("result_build_s"),
            rust_timing.get("total_s"),
        )
    person1_birth_year = plan.household.person1.birth_date.year
    person2_birth_year = plan.household.person2.birth_date.year if plan.household.person2 is not None else None
    indexed_paths: list[tuple[int, ProjectionResult]] = []
    for idx in sorted(sample_indices):
        if idx < 0 or idx >= len(indexed_rows):
            continue
        yearly_values = indexed_rows[idx][1]
        years: list[YearlyProjection] = []
        for offset, net_worth in enumerate(yearly_values):
            year = start_year + offset
            years.append(
                YearlyProjection(
                    year=year,
                    person1_age=year - person1_birth_year,
                    person2_age=(year - person2_birth_year) if person2_birth_year is not None else None,
                    total_net_worth=net_worth,
                )
            )
        indexed_paths.append(
            (
                idx,
                ProjectionResult(
                    scenario_id=scenario_id,
                    years=years,
                    final_net_worth=yearly_values[-1] if yearly_values else 0.0,
                    depletion_age=depletion_ages[idx] if idx < len(depletion_ages) else None,
                ),
            )
        )
    return final_net_worths, depletion_ages, indexed_paths, indexed_rows


def run_native_projection_summary(
    *,
    plan: HouseholdPlan,
    scenario_id: str,
    start_year: int,
    end_year: int,
) -> NativeProjectionSummary:
    """Run a deterministic native projection path and return summary metrics."""
    projection = run_native_projection(
        plan=plan,
        scenario_id=scenario_id,
        start_year=start_year,
        end_year=end_year,
    )
    return NativeProjectionSummary(
        final_net_worth=projection.final_net_worth,
        depletion_age=projection.depletion_age,
        yearly_net_worths=[year.total_net_worth for year in projection.years],
    )


def run_native_projection(
    *,
    plan: HouseholdPlan,
    scenario_id: str,
    start_year: int,
    end_year: int,
    expense_delta: float | None = None,
    tax_tables_by_year: dict[int, TaxTables] | None = None,
) -> ProjectionResult:
    """Run deterministic projection in native code and return service-facing output."""
    n_years = max(end_year - start_year + 1, 0)
    if n_years == 0:
        return ProjectionResult(
            scenario_id=scenario_id,
            years=[],
            final_net_worth=0.0,
            depletion_age=None,
        )
    module = _load_native_module()
    base_returns = plan.assumptions.returns
    tax_projection = plan.assumptions.tax_projection.model_dump(mode="python")
    province = plan.household.province.value
    resolved_tax_tables_by_year = tax_tables_by_year or {
        year: load_tax_tables(year, province, projection_assumptions=tax_projection)
        for year in range(start_year, end_year + 1)
    }
    plan_payload = build_native_plan_payload(plan, start_year, end_year, resolved_tax_tables_by_year)
    response = module.simulate_projection(
        {
            "plan": plan_payload,
            "scenario_id": scenario_id,
            "start_year": start_year,
            "end_year": end_year,
            "n_threads": 1,
            "fidelity": "full",
            "base_returns": base_returns.model_dump(mode="python"),
            "expense_delta": expense_delta,
            "return_timing": os.getenv("FINPLAN_MC_TIMING") == "1",
        }
    )
    yearly_net_worths = [float(v) for v in response.get("yearly_net_worths", [])]
    debug_rows: list[dict[str, Any]] = response.get("debug_trace_rows", [])
    person1_birth_year = plan.household.person1.birth_date.year
    person2_birth_year = plan.household.person2.birth_date.year if plan.household.person2 is not None else None
    years: list[YearlyProjection] = []
    for offset, net_worth in enumerate(yearly_net_worths):
        year = start_year + offset
        row = debug_rows[offset] if offset < len(debug_rows) else {}
        account_balances = _extract_prefixed_map(row, "account_balance::")
        account_returns = _extract_prefixed_map(row, "account_return::")
        account_net_deposits = _extract_prefixed_map(row, "account_net_deposit::")
        years.append(
            YearlyProjection(
                year=year,
                person1_age=year - person1_birth_year,
                person2_age=(year - person2_birth_year) if person2_birth_year is not None else None,
                employment_income=float(row.get("employment_income", 0.0)),
                pension_income=float(row.get("pension_income", 0.0)),
                cpp_income=float(row.get("cpp_income", 0.0)),
                total_income=float(row.get("total_income", 0.0)),
                investment_income=float(row.get("investment_income", 0.0)),
                portfolio_dividend_income=float(row.get("portfolio_dividend_income", 0.0)),
                portfolio_interest_income=float(row.get("portfolio_interest_income", 0.0)),
                portfolio_unrealized_growth=float(row.get("portfolio_unrealized_growth", 0.0)),
                rebalancing_realized_capital_gains=float(row.get("rebalancing_realized_capital_gains", 0.0)),
                rebalancing_taxable_capital_gains=float(row.get("rebalancing_taxable_capital_gains", 0.0)),
                rebalancing_realized_capital_losses=float(row.get("rebalancing_realized_capital_losses", 0.0)),
                rebalancing_taxable_capital_losses=float(row.get("rebalancing_taxable_capital_losses", 0.0)),
                realized_capital_gains=float(row.get("realized_capital_gains", 0.0)),
                realized_capital_losses=float(row.get("realized_capital_losses", 0.0)),
                oas_income=float(row.get("oas_income", 0.0)),
                oas_clawback=float(row.get("oas_clawback", 0.0)),
                other_income=float(row.get("other_income", 0.0)),
                federal_tax=float(row.get("federal_tax", 0.0)),
                provincial_tax=float(row.get("provincial_tax", 0.0)),
                total_tax=float(row.get("total_tax", 0.0)),
                net_income=float(row.get("net_income", 0.0)),
                total_expenses=float(row.get("total_expenses", 0.0)),
                taxable_capital_gains=float(row.get("taxable_capital_gains", 0.0)),
                taxable_capital_losses=float(row.get("taxable_capital_losses", 0.0)),
                taxable_capital_loss_carryforward=float(row.get("taxable_capital_loss_carryforward", 0.0)),
                cash_flow_gap=float(row.get("cash_flow_gap", 0.0)),
                withdrawal_non_reg=float(row.get("withdrawal_non_reg", 0.0)),
                withdrawal_rrsp_rrif=float(row.get("withdrawal_rrsp_rrif", 0.0)),
                withdrawal_tfsa=float(row.get("withdrawal_tfsa", 0.0)),
                total_withdrawals=float(row.get("total_withdrawals", 0.0)),
                total_non_reg=float(row.get("total_non_reg", 0.0)),
                total_rrsp_rrif=float(row.get("total_rrsp_rrif", 0.0)),
                total_tfsa=float(row.get("total_tfsa", 0.0)),
                total_net_worth=net_worth,
                account_balances=account_balances,
                account_returns=account_returns,
                account_net_deposits=account_net_deposits,
                one_time_income=float(row.get("one_time_income", 0.0)),
                one_time_expense=float(row.get("one_time_expense", 0.0)),
                recurring_expense=float(row.get("recurring_expense", 0.0)),
            )
        )
    final_net_worth = float(response.get("final_net_worth", years[-1].total_net_worth if years else 0.0))
    depletion_age_raw = response.get("depletion_age")
    warnings = _minimum_capgain_warnings(plan=plan, years=years)
    return ProjectionResult(
        scenario_id=scenario_id,
        years=years,
        final_net_worth=final_net_worth,
        depletion_age=None if depletion_age_raw is None else int(depletion_age_raw),
        warnings=warnings,
    )


def _extract_prefixed_map(row: dict[str, Any], prefix: str) -> dict[str, float]:
    out: dict[str, float] = {}
    for key, value in row.items():
        if isinstance(key, str) and key.startswith(prefix):
            out[key[len(prefix) :]] = float(value)
    return out


def _minimum_capgain_warnings(*, plan: HouseholdPlan, years: list[YearlyProjection]) -> list[str]:
    """Approximate warning parity for minimum-capgain events in native projection mode."""
    warnings: list[str] = []
    rows_by_year = {row.year: row for row in years}
    has_non_reg = any(account.account_type.value == "NON_REGISTERED" for account in plan.accounts)
    for event in plan.one_time_events:
        if event.event_type != "minimum-capgain":
            continue
        if event.year is None:
            continue
        active_years = [y for y in range(event.year, event.year + event.repeat_for_years + 1) if y in rows_by_year]
        for year in active_years:
            realized = rows_by_year[year].realized_capital_gains
            if not has_non_reg:
                warnings.append(
                    f"minimum-capgain target {event.amount:.2f} exceeds available non-registered gains in {year}"
                )
                continue
            if realized + 1e-6 < event.amount:
                warnings.append(f"minimum-capgain target {event.amount:.2f} exceeds available gains in {year}")
    return warnings
