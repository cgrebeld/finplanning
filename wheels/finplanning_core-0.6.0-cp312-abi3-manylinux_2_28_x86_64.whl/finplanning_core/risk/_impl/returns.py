"""Fat-tailed return generator using Student's t-distribution."""

import math

import numpy as np
from numpy.typing import NDArray


def generate_returns(
    n_years: int,
    n_simulations: int,
    mean: float = 0.06,
    std: float = 0.16,
    df: int = 5,
    seed: int | None = None,
) -> NDArray[np.float64]:
    """Generate random return paths using a fat-tailed distribution.

    Uses Student's t-distribution with ``df`` degrees of freedom.
    The raw samples are normalised to unit variance, then scaled to match
    the target ``mean`` and ``std``.

    Args:
        n_years: Number of projection years per path.
        n_simulations: Number of independent simulation paths.
        mean: Target annualised mean return (e.g. 0.06 for 6%).
        std: Target annualised standard deviation (e.g. 0.16 for 16%).
        df: Degrees of freedom for the t-distribution.  Lower values
            produce heavier tails.  ``df=5`` gives excess kurtosis ~6,
            matching empirical equity return distributions.
        seed: Optional RNG seed for reproducibility.

    Returns:
        Array of shape ``(n_simulations, n_years)`` with simulated
        annual returns.
    """
    rng = np.random.default_rng(seed)
    raw = rng.standard_t(df, size=(n_simulations, n_years))
    # Normalise to unit variance: Var(t_df) = df/(df-2) for df > 2
    raw = raw / math.sqrt(df / (df - 2))
    # Scale to target mean and std
    return raw * std + mean
