"""Public engine API."""

from finplanning_core.engine._impl.inflation import inflate
from finplanning_core.engine._impl.projection import ProjectionResult, YearlyProjection

__all__ = ["ProjectionResult", "YearlyProjection", "inflate"]
