from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent


def tax_data_dir() -> str:
    return str(DATA_DIR / "tax")


def market_data_dir() -> str:
    return str(DATA_DIR / "market")
